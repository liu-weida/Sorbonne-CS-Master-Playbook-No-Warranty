name := "cassandra-spark"
version := "1.0"
scalaVersion := "2.12.15"

// Spark and Cassandra dependencies
libraryDependencies ++= Seq(
  "org.apache.spark" %% "spark-core" % "3.3.0" % "provided",
  "com.datastax.spark" %% "spark-cassandra-connector" % "3.2.0",
  "org.scala-lang" % "scala-library" % "2.12.15"
)

// Merge strategy for assembly
assemblyMergeStrategy in assembly := {
  case PathList("META-INF", xs @ _*) => MergeStrategy.discard
  case x => MergeStrategy.first
}

// Main class for the application
mainClass in (Compile, packageBin) := Some("cassandra.TableCopy")
