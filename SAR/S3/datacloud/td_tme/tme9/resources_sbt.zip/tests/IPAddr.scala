package datacloud.hbase.tests

class IPAddr {
  
}