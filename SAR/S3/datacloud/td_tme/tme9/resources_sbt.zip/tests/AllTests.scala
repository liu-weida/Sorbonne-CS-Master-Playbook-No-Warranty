package datacloud.hbase.tests

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(classOf[Suite])
@SuiteClasses(Array(
	classOf[datacloud.hbase.tests.HbaseClientCreateDeleteTest],
	// classOf[datacloud.hbase.tests.HbaseClientReadWriteTest],
	// classOf[datacloud.hbase.tests.LastfmFillingTest],
	// classOf[datacloud.hbase.tests.NbVenteParCategorieTest],
	// classOf[datacloud.hbase.tests.DenormaliseTest]
))
class AllTests {
  
}
