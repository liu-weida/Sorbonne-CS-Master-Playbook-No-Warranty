name := "datacloud"
version := "1.0.0"
scalaVersion := "2.12.17"

// HBase and Hadoop dependencies
libraryDependencies ++= Seq(
  "org.apache.hbase" % "hbase-client" % "2.4.12",
  "org.apache.hbase" % "hbase-common" % "2.4.12",
  "org.apache.hadoop" % "hadoop-common" % "3.2.4",
  "org.apache.hadoop" % "hadoop-hdfs" % "3.2.4",
  
  // Testing dependencies
  "junit" % "junit" % "4.13.2" % Test,
  "com.github.sbt" % "junit-interface" % "0.13.3" % Test,
  "org.scalatest" %% "scalatest" % "3.2.15" % Test
)

// Compiler options
scalacOptions ++= Seq(
  "-deprecation",
  "-feature",
  "-unchecked"
)

// Test options
Test / parallelExecution := false
Test / logBuffered := false
