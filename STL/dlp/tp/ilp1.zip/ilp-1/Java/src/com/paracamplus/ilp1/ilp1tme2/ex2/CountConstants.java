package com.paracamplus.ilp1.ilp1tme2.ex2;

import com.paracamplus.ilp1.interfaces.*;

public class CountConstants implements IASTvisitor<Integer, Integer, Exception>{

    @Override
    public Integer visit(IASTboolean iast, Integer integer) throws Exception {
        return 1;
    }

    @Override
    public Integer visit(IASTfloat iast, Integer integer) throws Exception {
        return 1;
    }

    @Override
    public Integer visit(IASTinteger iast, Integer integer) throws Exception {
        return 1;
    }

    @Override
    public Integer visit(IASTstring iast, Integer integer) throws Exception {
        return 1;
    }

    @Override
    public Integer visit(IASTvariable iast, Integer integer) throws Exception {
        return 0;
    }

    @Override
    public Integer visit(IASTalternative iast, Integer integer) throws Exception {
        integer += iast.getCondition().accept(this,integer);
        integer += iast.getConsequence().accept(this,integer);

        if (iast.isTernary()){
            integer += iast.getAlternant().accept(this,integer);
        }

        return integer;
    }

    @Override
    public Integer visit(IASTbinaryOperation iast, Integer integer) throws Exception {
        integer += iast.getLeftOperand().accept(this,integer);
        integer += iast.getRightOperand().accept(this,integer);
        return integer;
    }

    @Override
    public Integer visit(IASTblock iast, Integer integer) throws Exception {
       IASTblock.IASTbinding[] bindings = iast.getBindings();
        for (IASTblock.IASTbinding binding : bindings){
            integer += binding.getInitialisation().accept(this,integer);
        }

        integer += iast.getBody().accept(this,integer);

        return integer;
    }

    @Override
    public Integer visit(IASTinvocation iast, Integer integer) throws Exception {
        IASTexpression[] invocations = iast.getArguments();
        for (IASTexpression invocation :invocations){
            integer += iast.getFunction().accept(this,integer);
        }
        return integer;
    }

    @Override
    public Integer visit(IASTsequence iast, Integer integer) throws Exception {
        IASTexpression[] sequences = iast.getExpressions();
        for (IASTexpression sequence : sequences){
            integer += sequence.accept(this,integer);
        }
        return integer;
    }


    @Override
    public Integer visit(IASTunaryOperation iast, Integer integer) throws Exception {
        integer += iast.getOperand().accept(this,integer);
        return integer;
    }

    public Integer visit(IASTprogram iast, Integer integer) throws Exception{
        return iast.getBody().accept(this,integer);
    }
}
