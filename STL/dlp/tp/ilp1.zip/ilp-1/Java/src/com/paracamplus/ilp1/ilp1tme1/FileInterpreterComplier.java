package com.paracamplus.ilp1.ilp1tme1;

import java.io.File;
import java.io.IOException;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.test.CompilerTest;
import com.paracamplus.ilp1.parser.ParseException;

public class FileInterpreterComplier extends CompilerTest{

	public FileInterpreterComplier(File file) {
		super(file);
		this.file = file;
	}

	public static void main(String[] args)
	{
		File newfile = new File(args[0]);
		FileInterpreterComplier p = new FileInterpreterComplier(newfile);
		try {
			p.processFile();
		} catch (CompilationException e) {
			
			e.printStackTrace();
		} catch (ParseException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
}
