package com.paracamplus.ilp1.ilp1tme3.interpreter.primitive;
import java.util.Vector;

import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.primitive.UnaryPrimitive;

public class VectorLength extends UnaryPrimitive{

	public VectorLength() {
		super("vectorLength");
		// TODO Auto-generated constructor stub
	}

	@Override
	public Object apply(Object vecteur) throws EvaluationException {
		// TODO Auto-generated method stub
		if(vecteur instanceof Vector<?>) {
			return ((Vector<?>) vecteur).size();
		}
		throw new EvaluationException("Argument Fault: vecteur");
	}

}
