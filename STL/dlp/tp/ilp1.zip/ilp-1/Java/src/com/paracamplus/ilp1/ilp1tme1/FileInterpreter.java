package com.paracamplus.ilp1.ilp1tme1;

import java.io.File;
import java.io.IOException;

import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.test.InterpreterRunner;
import com.paracamplus.ilp1.interpreter.test.InterpreterTest;
import com.paracamplus.ilp1.parser.ParseException;

public class FileInterpreter extends InterpreterTest {
	public FileInterpreter(File file) {
		super(file);
		this.file = file;
	}

	public static void main(String[] args) throws EvaluationException, ParseException, IOException	
	{
	
		File newfile = new File(args[0]);
		FileInterpreter p = new FileInterpreter(newfile);
		p.processFile();
    	
	}

}
