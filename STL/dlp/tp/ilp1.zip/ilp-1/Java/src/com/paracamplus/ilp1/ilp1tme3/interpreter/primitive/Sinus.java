package com.paracamplus.ilp1.ilp1tme3.interpreter.primitive;

import java.math.BigInteger;

import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.primitive.UnaryPrimitive;

public class Sinus extends UnaryPrimitive {

	public Sinus() {
		super("sinus");
		// TODO Auto-generated constructor stub
	}

	@Override
	public Object apply(Object radian) throws EvaluationException {
		// TODO Auto-generated method stub
		
		if(radian instanceof Double) {
			return Math.sin((Double)radian);
		}else if(radian instanceof Integer) {
			return Math.sin((Integer)radian);
		}else if(radian instanceof BigInteger) {
			return Math.sin(((BigInteger)radian).doubleValue());
		}
		else throw new EvaluationException("argument Fault: radian ");
	}

}
