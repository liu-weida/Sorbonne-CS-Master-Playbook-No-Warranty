package com.paracamplus.ilp1.ilp1tme1.test;

import com.paracamplus.ilp1.ast.ASTboolean;
import com.paracamplus.ilp1.ast.ASTinteger;
import com.paracamplus.ilp1.ast.ASTstring;
import com.paracamplus.ilp1.ilp1tme1.sequence.ASTsequence;
import com.paracamplus.ilp1.ilp1tme1.sequence.IASTsequence;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ASTsequenceTest {
    IASTexpression[] expr = {
            new ASTinteger("90"),
            new ASTstring("oui"),
            new ASTboolean("true")
    };
    IASTsequence seq = new ASTsequence(expr);

    @Test
    public void testGetAllButLastInstructions() {
        try {
            IASTexpression[] result = seq.getAllButLastInstructions();
            assertEquals(result.length, expr.length - 1);
            assertTrue(result[result.length - 1] instanceof ASTstring);

            for (int i = 0; i < result.length; i++) {
                assertEquals(result[i], expr[i]);
            }

        } catch (EvaluationException e) {
            e.printStackTrace();
        }
    }
}
