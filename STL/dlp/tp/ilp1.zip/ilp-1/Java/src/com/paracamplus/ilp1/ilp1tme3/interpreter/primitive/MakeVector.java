package com.paracamplus.ilp1.ilp1tme3.interpreter.primitive;

import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.primitive.Primitive;

import java.math.BigInteger;
import java.util.Vector;

public class MakeVector extends Primitive{

	public MakeVector() {
		super("makeVector");
		// TODO Auto-generated constructor stub
	}


	@Override
	public int getArity() {
		// TODO Auto-generated method stub
		return 2;
	}


	@Override
	public Object apply(Object size, Object value) throws EvaluationException {
		// TODO Auto-generated method stub
		if(size instanceof BigInteger) {
			int length = ((BigInteger) size).intValue();
			Vector<Object> vecteur = new Vector<>();
			vecteur.setSize(length);
			for(int index = 0; index < length; index++) {
				vecteur.set(index,value);
			}
			return vecteur;
		}
		else throw new EvaluationException("arguments fault: size/value");
	}


}



