package com.paracamplus.ilp1.ilp1tme3.interpreter.primitive;
import java.math.BigInteger;
import java.util.Vector;

import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.primitive.Primitive;


public class VectorGet extends  Primitive{

	public VectorGet() {
		super("vectorGet");
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getArity() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public Object apply(Object vecteur, Object indexObj) throws EvaluationException {
		// TODO Auto-generated method stub
		if(vecteur instanceof Vector<?> && indexObj instanceof BigInteger) {
			int index = ((BigInteger)indexObj).intValue();
			return ((Vector<?>) vecteur).get(index);			
		}
		else throw new EvaluationException("Arguments fault: vecteur/indexObj");
		
	}
	
	

}
