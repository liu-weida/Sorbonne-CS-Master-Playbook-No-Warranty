package com.paracamplus.ilp1.ilp1tme2.ex2;

import antlr4.ILPMLgrammar1Parser;
import com.paracamplus.ilp1.interfaces.IASTfactory;

public class ILPMLListener extends com.paracamplus.ilp1.parser.ilpml.ILPMLListener {
    public ILPMLListener(IASTfactory factory) {
        super(factory);
    }

    int nbConstante = 0;

    @Override
    public void exitConstFloat(ILPMLgrammar1Parser.ConstFloatContext ctx) {
        super.exitConstFloat(ctx);
        nbConstante++;
    }

    @Override
    public void	exitConstInteger(ILPMLgrammar1Parser.ConstIntegerContext ctx) {
        super.exitConstInteger(ctx);
        nbConstante++;
    }

    @Override
    public void exitConstTrue(ILPMLgrammar1Parser.ConstTrueContext ctx) {
        super.exitConstTrue(ctx);
        nbConstante++;
    }

    @Override
    public void exitConstFalse(ILPMLgrammar1Parser.ConstFalseContext ctx) {
        super.exitConstFalse(ctx);
        nbConstante++;
    }

    @Override
    public void exitConstString(ILPMLgrammar1Parser.ConstStringContext ctx) {
        super.exitConstString(ctx);
        nbConstante++;
    }

    public int getNbConstante() {
        return nbConstante;
    }
}
