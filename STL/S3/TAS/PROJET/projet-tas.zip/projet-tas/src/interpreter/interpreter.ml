open Abstract_syntax_tree
open Abstract_syntax_printer
open Domain

(* pour le débogage *)
let trace = ref false

(* déroulement de boucle *)
let loop_unrolling = ref 0
(* retardement du renforcement *)
let widen_delay = ref 0

(* affichage des erreurs *)
let error ext s =
  Format.printf "%s: ERROR: %s@\n" (string_of_extent ext) s

let fatal_error ext s =
  Format.printf "%s: FATAL ERROR: %s@\n" (string_of_extent ext) s;
  exit 1

(* signature de l'interpréteur *)
(* *************************** *)

(* un interpréteur exporte une seule fonction, qui effectue tout le travail *)
module type INTERPRETER =
sig
  (* analyse d'un programme, à partir de son arbre syntaxique abstrait *)
  val eval_prog: prog -> unit
end

(* interpréteur *)
(* ************ *)

(* l'interpréteur est paramétré par le choix d'un domaine D
   de signature Domain.DOMAIN
 *)

module Interprete(D : DOMAIN) =
(struct

  (* élément abstrait représentant un ensemble d'environnements ;
     fourni par le domaine abstrait
   *)
  type t = D.t

  (* fonction utilitaire pour réduire la complexité de l'évaluation des expressions booléennes ;
     elle gère les opérateurs booléens &&, ||, ! en interne, par induction
     sur la syntaxe, et appelle la fonction D.compare du domaine
     pour gérer la partie arithmétique

     si r=true, conserve les états pouvant satisfaire l'expression ;
     si r=false, conserve les états pouvant infirmer l'expression
   *)
  let filter (a:t) (e:bool_expr ext) (r:bool) : t =

    (* exploration récursive de l'expression *)
    let rec doit a (e,_) r = match e with
    (* partie booléenne, traitée récursivement *)
    | AST_bool_unary (AST_NOT, e) ->
        doit a e (not r)
    | AST_bool_binary (AST_AND, e1, e2) ->
        (if r then D.meet else D.join) (doit a e1 r) (doit a e2 r)
    | AST_bool_binary (AST_OR, e1, e2) ->
        (if r then D.join else D.meet) (doit a e1 r) (doit a e2 r)
    | AST_bool_const b ->
        if b = r then a else D.bottom ()

    (* partie comparaison arithmétique, gérée par D *)
    | AST_compare (cmp, (e1,_), (e2,_)) ->
        (* fonction utilitaire pour inverser la comparaison, lorsque r=false *)
        let inv = function
        | AST_EQUAL         -> AST_NOT_EQUAL
        | AST_NOT_EQUAL     -> AST_EQUAL
        | AST_LESS          -> AST_GREATER_EQUAL
        | AST_LESS_EQUAL    -> AST_GREATER
        | AST_GREATER       -> AST_LESS_EQUAL
        | AST_GREATER_EQUAL -> AST_LESS
        in
        let cmp = if r then cmp else inv cmp in
        D.compare a e1 cmp e2

    in
    doit a e r

  (* interprète une instruction, par induction sur la syntaxe *)
  let rec eval_stat (a:t) ((s,ext):stat ext) : t =
    let r = match s with

    | AST_block (decl,inst) ->
        (* ajout des variables locales *)
        let a =
          List.fold_left
            (fun a ((_,v),_) -> D.add_var a v)
            a decl
        in
        (* interprétation récursive du bloc *)
        let a = List.fold_left eval_stat a inst in
        (* suppression des variables locales *)
        List.fold_left
          (fun a ((_,v),_) -> D.del_var a v)
          a decl

    | AST_assign ((i,_),(e,_)) ->
        (* l'affectation est déléguée au domaine *)
        D.assign a i e

    | AST_if (e,s1,Some s2) ->
        (* calcul des deux branches *)
        let t = eval_stat (filter a e true ) s1 in
        let f = eval_stat (filter a e false) s2 in
        (* puis jointure *)
        D.join t f

    | AST_if (e,s1,None) ->
        (* calcul des deux branches *)
        let t = eval_stat (filter a e true ) s1 in
        let f = filter a e false in
        (* puis jointure *)
        D.join t f

    | AST_while (e,s) ->
      let rec unroll (n:int) (a:t) : t =
      if n = 0 then 
        let rec fix (f:t->t)(x:t)(d:int):t=
          let fx = f x in
          if D.subset fx x then fx
          else if d > 0 then begin
            let new_d = d - 1 in
            fix f fx new_d
          end else
          fix f (D.widen x fx) d
        in
        let f x = D.join a (eval_stat (filter x e true) s) in
        let inv = fix f a !widen_delay in
        filter inv e false
      else
        let body = eval_stat (filter a e true) s in
        let new_a = unroll (n-1) body in
        D.join new_a (filter a e false)
      in
      unroll !loop_unrolling a
        
    | AST_assert e ->
        let passing_state = filter a e true in
          let failing_state = filter a e false in
            if not (D.is_bottom failing_state) then (
              error ext "assertion failure"
            );
        passing_state

    | AST_print l ->
        (* afficher l'environnement abstrait courant *)
        let l' = List.map fst l in
        Format.printf "%s: %a@\n"
          (string_of_extent ext) (fun fmt v -> D.print fmt a v) l';
        (* ensuite, renvoyer l'élément original inchangé *)
        a

    | AST_PRINT_ALL ->
        (* afficher l'environnement abstrait courant pour toutes les variables *)
        Format.printf "%s: %a@\n"
          (string_of_extent ext) D.print_all a;
        (* ensuite, renvoyer l'élément original inchangé *)
        a

    | AST_HALT ->
        (* après halt, il n'y a plus d'environnements *)
        D.bottom ()

    in

    (* traçage, utile pour le débogage *)
    if !trace then
      Format.printf "stat trace: %s: %a@\n"
        (string_of_extent ext) D.print_all r;
    r

  (* point d'entrée de l'analyse du programme *)
  let eval_prog (l:prog) : unit =
    (* analyser simplement chaque instruction du programme *)
    let _ = List.fold_left eval_stat (D.init()) l in
    (* rien d'utile à retourner *)
    Format.printf "analysis ended@\n";
    ()

end : INTERPRETER)
