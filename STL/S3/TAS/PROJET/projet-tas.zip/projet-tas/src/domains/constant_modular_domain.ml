(*
  constant_modular_domain.ml
  Domaine des constantes en 32-bit machine.
*)

open Abstract_syntax_tree
open Value_domain

let two32 = Z.pow (Z.of_int 2) 32
let half = Z.pow (Z.of_int 2) 31

(* Normalise un entier pour qu'il soit interprété comme un entier signé sur 32 bits *)
let normalize x =
  let r = Z.erem x two32 in
  let r = if Z.sign r < 0 then Z.add r two32 else r in
  if Z.geq r half then Z.sub r two32 else r

module Constants_modular = struct

  (* Le type du domaine des constantes :
     - Cst représente une constante
     - BOT représente le bas (ensemble vide)
     - TOP représente le dessus (toutes les valeurs possibles)
  *)
  type t =
    | Cst of Z.t
    | BOT
    | TOP

  let top = TOP
  let bottom = BOT

  (* Injection d'une constante dans le domaine, avec normalisation *)
  let const c = Cst (normalize c)

  (* Création d'un élément aléatoire entre x et y :
     si x = y, la constante est injectée ;
     si x < y, on retourne TOP (imprécision) ;
     sinon, on retourne BOT (intervalle invalide)
  *)
  let rand x y =
    if Z.equal x y then Cst (normalize x)
    else if Z.lt x y then TOP
    else BOT

  (* Applique une fonction unaire f à une valeur du domaine *)
  let lift1 f x =
    match x with
    | BOT -> BOT
    | TOP -> TOP
    | Cst a -> Cst (normalize (f a))
  
  (* Applique une fonction binaire f à deux valeurs du domaine *)
  let lift2 f x y =
    match x, y with
    | BOT, _ | _, BOT -> BOT
    | TOP, _ | _, TOP -> TOP
    | Cst a, Cst b -> Cst (normalize (f a b))

  (* Opération unaire de négation *)
  let neg = lift1 Z.neg
  (* Opération binaire d'addition *)
  let add = lift2 Z.add
  (* Opération binaire de soustraction *)
  let sub = lift2 Z.sub

  (* Opération de multiplication :
     Si l'un des opérandes est BOT, on retourne BOT.
     Si les deux sont des constantes, on multiplie et on normalise.
     Si une constante est zéro, on retourne zéro, sinon TOP.
  *)
  let mul x y =
    match x, y with
    | BOT, _ | _, BOT -> BOT
    | Cst a, Cst b -> Cst (normalize (Z.mul a b))
    | Cst a, TOP ->
        if Z.equal a Z.zero then Cst Z.zero else TOP
    | TOP, Cst b ->
        if Z.equal b Z.zero then Cst Z.zero else TOP
    | TOP, TOP -> TOP

  (* Opération de division ;
     si le diviseur est zéro (constante zéro), on retourne BOT ;
     sinon, on applique lift2 pour effectuer la division *)
  let div a b =
    if b = Cst Z.zero then BOT
    else lift2 Z.div a b

  (* Opération de join (union) du domaine *)
  let join a b = match a, b with
    | BOT, x | x, BOT -> x
    | Cst x, Cst y when Z.equal x y -> a
    | _ -> TOP

  (* Opération de meet (intersection) du domaine *)
  let meet a b = match a, b with
    | TOP, x | x, TOP -> x
    | Cst x, Cst y when Z.equal x y -> a
    | _ -> BOT

  let widen = join

  (* Opération de comparaison pour AST_EQUAL.
     Retourne (a, b) si les constantes sont égales, sinon (BOT, BOT)
  *)
  let eq a b = match a, b with
    | BOT, _ | _, BOT -> BOT, BOT
    | Cst x, Cst y ->
        if Z.equal x y then a, b else BOT, BOT
    | Cst x, TOP -> a, Cst x
    | TOP, Cst y -> Cst y, b
    | _ -> a, b

  (* Opération de comparaison pour AST_NOT_EQUAL.
     Retourne (a, b) si les constantes sont différentes, sinon (BOT, BOT)
  *)
  let neq a b = match a, b with
    | BOT, _ | _, BOT -> BOT, BOT
    | Cst x, Cst y ->
        if not (Z.equal x y) then a, b else BOT, BOT
    | Cst _, TOP -> a, TOP
    | TOP, Cst _ -> TOP, b
    | _ -> a, b

  (* Opération de comparaison pour AST_GREATER_EQUAL.
     Retourne (a, b) si a >= b, sinon (BOT, BOT)
  *)
  let geq a b = match a, b with
    | BOT, _ | _, BOT -> BOT, BOT
    | Cst x, Cst y ->
        if Z.geq x y then a, b else BOT, BOT
    | _ -> a, b

  (* Opération de comparaison pour AST_GREATER.
     Retourne (a, b) si a > b, sinon (BOT, BOT)
  *)
  let gt a b = match a, b with
    | BOT, _ | _, BOT -> BOT, BOT
    | Cst x, Cst y ->
        if Z.gt x y then a, b else BOT, BOT
    | _ -> a, b

  (* Relation d'inclusion dans le domaine des constantes *)
  let subset a b = match a, b with
    | BOT, _ | _, TOP -> true
    | Cst x, Cst y -> Z.equal x y
    | _ -> false

  let is_bottom a = a = BOT

  (* Affichage d'un élément du domaine des constantes *)
  let print fmt x =
    match x with
    | BOT -> Format.fprintf fmt "⊥"
    | TOP -> Format.fprintf fmt "⊤"
    | Cst x -> Format.fprintf fmt "{%s}" (Z.to_string x)

  (* Opération unaire sur le domaine *)
  let unary x op = match op with
    | AST_UNARY_PLUS -> x
    | AST_UNARY_MINUS -> neg x

  (* Opération binaire sur le domaine *)
  let binary x y op = match op with
    | AST_PLUS -> add x y
    | AST_MINUS -> sub x y
    | AST_MULTIPLY -> mul x y
    | AST_DIVIDE -> div x y

  (* Opération de comparaison sur le domaine *)
  let compare x y op =
    match op with
    | AST_EQUAL -> eq x y
    | AST_NOT_EQUAL -> neq x y
    | AST_GREATER_EQUAL -> geq x y
    | AST_GREATER -> gt x y
    | AST_LESS_EQUAL -> let y', x' = geq y x in x', y'
    | AST_LESS -> let y', x' = gt y x in x', y'

  (* Opération rétrograde unaire : renvoie l'intersection de x et r (ou l'intersection de x et -r) *)
  let bwd_unary x op r =
    match op with
    | AST_UNARY_PLUS -> meet x r
    | AST_UNARY_MINUS -> meet x (neg r)

  (* Opération rétrograde binaire : effectue un raffinement sur les deux opérandes *)
  let bwd_binary x y op r =
    match op with
    | AST_PLUS -> meet x (sub r y), meet y (sub r x)
    | AST_MINUS -> meet x (add y r), meet y (sub x r)
    | AST_MULTIPLY ->
        let contains_zero o = subset (const Z.zero) o in
        (if contains_zero y && contains_zero r then x else meet x (div r y)),
        (if contains_zero x && contains_zero r then y else meet y (div r x))
    | AST_DIVIDE ->
        let contains_zero o = subset (const Z.zero) o in
        (if contains_zero y && contains_zero r then x else meet x (mul r y)),
        (if contains_zero x && contains_zero r then y else meet y (div x r))
end
