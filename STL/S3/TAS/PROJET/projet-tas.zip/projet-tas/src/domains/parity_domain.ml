open Abstract_syntax_tree

module Parity = struct

  (* Définition du type de parité.
     Le domaine possède quatre éléments :
     - Even : nombre pair
     - Odd  : nombre impair
     - Top  : inconnu (peut être pair ou impair)
     - Bot  : ensemble vide (impossible)
  *)
  type t = Even | Odd | Top | Bot

  (* Élément supérieur du domaine *)
  let top = Top
  (* Élément inférieur du domaine *)
  let bottom = Bot
  (* Vérifie si l'élément est Bot *)
  let is_bottom x = (x = Bot)

  (* Conversion d'une constante entière en parité.
     Si le reste modulo 2 est zéro, la valeur est Even, sinon Odd.
  *)
  let const z =
    if Z.equal (Z.rem z (Z.of_int 2)) Z.zero then Even else Odd

  (* Définition d'un intervalle de valeurs en fonction d'une borne basse et haute.
     Si l'intervalle est invalide (borne basse > borne haute), renvoie Bot.
     Si les bornes sont égales, renvoie la parité de cette constante.
     Sinon, on renvoie Top.
  *)
  let rand l h =
    if Z.gt l h then Bot
    else if Z.equal l h then const l
    else Top

  (* Relation d'inclusion sur le domaine de parité *)
  let subset x y =
    match x,y with
    | Bot, _ -> true
    | _, Top -> true
    | Even, Even -> true
    | Odd, Odd -> true
    | _ -> (x = y)

  (* Opération de jointure (union) sur le domaine de parité *)
  let join x y = match x,y with
    | Bot, a
    | a, Bot -> a
    | Even, Even -> Even
    | Odd, Odd -> Odd
    | _ -> Top

  (* Opération de rencontre (intersection) sur le domaine de parité *)
  let meet x y = match x,y with
    | Top, a
    | a, Top -> a
    | Bot, _
    | _, Bot -> Bot
    | Even, Even -> Even
    | Odd, Odd -> Odd
    | _ -> Bot

  (* Fonction d'affinement (imprécision) pour l'affichage de la parité *)
  let print fmt x =
    match x with
    | Bot -> Format.fprintf fmt "⊥"
    | Top -> Format.fprintf fmt "⊤"
    | Even -> Format.fprintf fmt "even"
    | Odd -> Format.fprintf fmt "odd"

  (* Opération unaire sur le domaine de parité.
     Pour l'instant, l'opération unaire ne modifie pas la parité.
  *)
  let unary x (_op : int_unary_op) = match x with
    | Bot -> Bot
    | _ -> x

  (* Opération binaire sur le domaine de parité.
     Les opérateurs considérés sont AST_PLUS, AST_MINUS, AST_MULTIPLY et AST_DIVIDE.
     La division renvoie Top car la parité peut être imprécise.
  *)
  let binary x y op = match x,y,op with
    | Bot, _, _ | _, Bot, _ -> Bot
    | Top, _, _ | _, Top, _ -> Top
    | Even, Even, (AST_PLUS|AST_MINUS) -> Even
    | Even, Odd,  (AST_PLUS|AST_MINUS) -> Odd
    | Odd,  Even, (AST_PLUS|AST_MINUS) -> Odd
    | Odd,  Odd,  (AST_PLUS|AST_MINUS) -> Even
    | Even, _, AST_MULTIPLY -> Even
    | _, Even, AST_MULTIPLY -> Even
    | Odd, Odd, AST_MULTIPLY -> Odd
    | _, _, AST_DIVIDE -> Top

  (* L'opération de widening est identique à la jointure *)
  let widen = join

  (* Opération de comparaison sur le domaine de parité.
     Pour les comparaisons d'égalité, on affine en fonction des valeurs.
     Pour les autres comparaisons, on ne fait pas d'affinement précis.
  *)
  let compare x y op = match x,y,op with
    | Bot, _, _ | _, Bot, _ -> (Bot, Bot)
    | _,_, (AST_LESS|AST_LESS_EQUAL|AST_GREATER|AST_GREATER_EQUAL) ->
      if x = Bot || y = Bot then (Bot, Bot) else (x, y)
    | _,_, AST_EQUAL ->
      begin match x, y with
      | Even, Even -> (Even, Even)
      | Odd, Odd -> (Odd, Odd)
      | Even, Top -> (Even, Top)
      | Odd, Top  -> (Odd, Top)
      | Top, Even -> (Top, Even)
      | Top, Odd  -> (Top, Odd)
      | Top, Top  -> (Top, Top)
      | _ -> (Bot, Bot)
      end
    | _,_, AST_NOT_EQUAL ->
      (x, y) (* Pas d'affinement pour la différence *)

  (* Opération rétrograde unaire (backward unary) : 
     Affine l'intervalle en effectuant une rencontre avec le résultat *)
  let bwd_unary x _ r = meet x r

  (* Opération rétrograde binaire (backward binary) : 
     Retourne simplement les opérandes inchangées *)
  let bwd_binary x y _ _ = (x, y)


  (* ----------- 4 nouvelles fonctions ----------- *)

  (* Conserve uniquement la partie "Even" de la parité *)
  let keep_even x =
    match x with
    | Bot -> Bot
    | Even -> Even
    | Odd -> Bot
    | Top -> Even   (* Top représente Even ∪ Odd, on ne garde que Even *)

  (* Conserve uniquement la partie "Odd" de la parité *)
  let keep_odd x =
    match x with
    | Bot -> Bot
    | Even -> Bot
    | Odd -> Odd
    | Top -> Odd

  (* Vérifie si l'élément représente uniquement des valeurs paires *)
  let is_all_even x =
    match x with
    | Even -> true
    | _ -> false

  (* Vérifie si l'élément représente uniquement des valeurs impaires *)
  let is_all_odd x =
    match x with
    | Odd -> true
    | _ -> false
  
end
