(*
  interval_modular_domain.ml
  Domaine des intervalles en 32-bit machine.
*)

module Intervals_modular = struct

  (* Définition des bornes *)
  type bound =
    | MINF           (* Moins l'infini *)
    | PINF           (* Plus l'infini *)
    | Int of Z.t     (* Une valeur entière *)
  
  (* Définition des intervalles *)
  type t =
    | Interval of bound * bound   (* Un intervalle défini par deux bornes *)
    | BOT                         (* Intervalle vide *)
  
  (* Intervalle universel *)
  let top = Interval (MINF, PINF)
  (* Intervalle vide *)
  let bottom = BOT

  (* Constantes pour la normalisation *)
  let two32 = Z.pow (Z.of_int 2) 32
  let half = Z.pow (Z.of_int 2) 31

  (* Normalise un entier pour le représenter en 32-bit signé *)
  let normalize x =
    let r = Z.erem x two32 in
    let r = if Z.sign r < 0 then Z.add r two32 else r in
    if Z.geq r half then Z.sub r two32 else r

  (* Injection d'une constante dans le domaine des intervalles *)
  let const (z: Z.t) : t =
    Interval (Int (normalize z), Int (normalize z))

  (* Création d'un intervalle à partir de deux bornes.
     Si la borne inférieure est inférieure ou égale à la borne supérieure, on crée l'intervalle ;
     sinon, l'intervalle est vide (BOT).
  *)
  let rand (a: Z.t) (b: Z.t) : t =
    if Z.leq a b then
      Interval (Int (normalize a), Int (normalize b))
    else
      BOT

  (* Négation d'une borne *)
  let bound_neg a =
    match a with
    | MINF -> PINF
    | PINF -> MINF
    | Int i -> Int (Z.neg i)

  (* Addition de deux bornes *)
  let bound_add a b =
    match a, b with
    | MINF, PINF | PINF, MINF -> invalid_arg "bound add"
    | PINF, _ | _, PINF -> PINF
    | MINF, _ | _, MINF -> MINF
    | Int i, Int j -> Int (Z.add i j)

  (* Soustraction de deux bornes *)
  let bound_sub a b = bound_add a (bound_neg b)

  (* Multiplication de deux bornes *)
  let bound_mul a b =
    match a, b with
    | MINF, PINF | PINF, MINF -> invalid_arg "bound mul"
    | Int o, _ when Z.equal o Z.zero -> Int Z.zero
    | _, Int o when Z.equal o Z.zero -> Int Z.zero
    | MINF, Int i | Int i, MINF -> if Z.lt i Z.zero then PINF else MINF
    | PINF, Int i | Int i, PINF -> if Z.lt i Z.zero then MINF else PINF
    | Int i, Int j -> Int (Z.mul i j)
    | _ -> invalid_arg "bound mul"

  (* Division de deux bornes *)
  let bound_div a b =
    match a, b with
    | MINF, PINF | PINF, MINF -> invalid_arg "bound div"
    | Int o, _ when Z.equal o Z.zero -> Int Z.zero
    | MINF, Int i -> if Z.lt i Z.zero then PINF else MINF
    | Int _, MINF -> Int Z.zero
    | Int _, PINF -> Int Z.zero
    | PINF, Int i -> if Z.lt i Z.zero then MINF else PINF
    | Int i, Int j -> Int (Z.div i j)
    | _ -> invalid_arg "bound_div"

  (* Renvoie la borne maximum parmi deux bornes *)
  let bound_max a b =
    match a, b with
    | MINF, MINF | PINF, PINF -> a
    | MINF, _ | _, PINF -> b
    | PINF, _ | _, MINF -> a
    | Int i, Int j -> Int (Z.max i j)

  (* Renvoie la borne minimum parmi deux bornes *)
  let bound_min a b =
    match a, b with
    | MINF, MINF | PINF, PINF -> a
    | MINF, _ | _, PINF -> a
    | PINF, _ | _, MINF -> b
    | Int i, Int j -> Int (Z.min i j)

  (* Teste l'égalité entre deux bornes *)
  let bound_eq a b =
    match a, b with
    | MINF, MINF | PINF, PINF -> true
    | Int i, Int j -> Z.equal i j
    | _ -> false

  (* Teste si une borne est strictement supérieure à une autre *)
  let bound_gt a b =
    match a, b with
    | PINF, _ | _, MINF -> true
    | Int i, Int j -> Z.gt i j
    | _ -> false

  (* Teste si une borne est supérieure ou égale à une autre *)
  let bound_geq a b =
    match a, b with
    | PINF, _ | _, MINF -> true
    | Int i, Int j -> Z.geq i j
    | _ -> false

  (* Jointure (union) de deux intervalles *)
  let join x y =
    match x, y with
    | Interval(a1, b1), Interval(a2, b2) ->
        let min_bound = bound_min a1 a2 in
        let max_bound = bound_max b1 b2 in
        Interval(min_bound, max_bound)
    | BOT, _ | _, BOT -> BOT

  (* Rencontre (intersection) de deux intervalles *)
  let meet x y =
    match x, y with
    | BOT, _ | _, BOT -> BOT
    | Interval(a1, b1), Interval(a2, b2) ->
        let min_bound = bound_max a1 a2 in
        let max_bound = bound_min b1 b2 in
        if bound_geq max_bound min_bound then Interval(min_bound, max_bound) else BOT

  (* Teste si l'intervalle x est inclus dans l'intervalle y *)
  let subset x y =
    match x, y with
    | BOT, _ | _, Interval(MINF, PINF) -> true
    | _, BOT -> false
    | Interval(MINF, PINF), _ -> false
    | Interval(Int a1, Int b1), Interval(Int a2, Int b2) ->
        Z.geq a1 a2 && Z.leq b1 b2
    | Interval(_, Int b1), Interval(MINF, Int b2) -> Z.leq b1 b2
    | Interval(Int a1, _), Interval(Int a2, PINF) -> Z.geq a1 a2
    | _ -> false

  (* Teste si x est l'élément bottom *)
  let is_bottom x = (x = BOT)

  (* Affichage d'un intervalle *)
  let print fmt x =
    match x with
    | BOT -> Format.fprintf fmt "⊥"
    | Interval(a, b) ->
        (match a, b with
         | MINF, PINF -> Format.fprintf fmt "[-∞;+∞]"
         | MINF, Int b -> Format.fprintf fmt "[-∞;%s]" (Z.to_string b)
         | Int a, PINF -> Format.fprintf fmt "[%s;+∞]" (Z.to_string a)
         | Int a, Int b -> Format.fprintf fmt "[%s;%s]" (Z.to_string a) (Z.to_string b)
         | _, _ -> raise (Invalid_argument "not valid bounds"))
end
