(*
  concrete_modular_domain.ml
  Analyse concrète en utilisant des entiers 32-bit signés.
*)

open Abstract_syntax_tree
open Domain

module Concrete_modular = struct

  (* Module Env : Une table de hachage associant des chaînes à des entiers *)
  module Env = Mapext.Make(String)
  (* Un environnement est une fonction associant chaque variable à une valeur entière *)
  type env = Z.t Env.t
  (* Ensemble d'environnements *)
  module EnvSet =
    Set.Make(struct
        type t = env
        let compare = Env.compare Z.compare
      end)
  (* Un élément du domaine concret est un ensemble d'environnements *)
  type t = EnvSet.t

  (* Ensemble d'entiers, utilisé en interne pour représenter les valeurs *)
  module ValSet = Set.Make(struct
      type t = Z.t
      let compare = Z.compare
    end)

  (* 2^32, utilisé pour la normalisation des entiers *)
  let two32 = Z.pow (Z.of_int 2) 32
  (* 2^31, moitié de 2^32 *)
  let half = Z.pow (Z.of_int 2) 31

  (* Normalise un entier x pour qu'il soit interprété comme un entier 32-bit signé.
     On calcule x mod 2^32, puis on ajuste en soustrayant 2^32 si nécessaire.
  *)
  let normalize x =
    let r = Z.erem x two32 in
    let r = if Z.sign r < 0 then Z.add r two32 else r in
    if Z.geq r half then Z.sub r two32 else r

  (* Applique une fonction f à chaque élément d'un ensemble d'entiers, en normalisant le résultat *)
  let int_map f s =
    ValSet.fold (fun x acc -> ValSet.add (normalize (f x)) acc) s ValSet.empty

  (* Applique une fonction binaire f à chaque paire d'éléments provenant de s1 et s2, avec normalisation *)
  let int2_map f s1 s2 =
    ValSet.fold (fun x1 acc ->
        ValSet.fold (fun x2 acc -> ValSet.add (normalize (f x1 x2)) acc) s2 acc)
      s1 ValSet.empty

  (* Évaluation d'une expression entière dans un environnement m.
     Renvoie un ensemble de valeurs possibles (non déterminisme).
  *)
  let rec eval_expr e m =
    match e with
    | AST_int_unary (op,(e1,_)) ->
        let s1 = eval_expr e1 m in
        int_map (match op with
                 | AST_UNARY_PLUS -> fun x -> x
                 | AST_UNARY_MINUS -> Z.neg) s1
    | AST_int_binary (op,(e1,_),(e2,_)) ->
        let s1 = eval_expr e1 m and s2 = eval_expr e2 m in
        let s2 = if op = AST_DIVIDE then ValSet.remove Z.zero s2 else s2 in
        int2_map (match op with
                  | AST_PLUS -> Z.add
                  | AST_MINUS -> Z.sub
                  | AST_MULTIPLY -> Z.mul
                  | AST_DIVIDE -> Z.div) s1 s2
    | AST_identifier (v,_) ->
        ValSet.singleton (Env.find v m)
    | AST_int_const (s,_) ->
        ValSet.singleton (normalize (Z.of_string s))
    | AST_rand ((l1,_),(l2,_)) ->
        let l1 = normalize (Z.of_string l1)
        and l2 = normalize (Z.of_string l2) in
        let rec acc cur set =
          if Z.gt cur l2 then set
          else acc (Z.succ cur) (ValSet.add cur set)
        in
        acc l1 ValSet.empty

  (* Évaluation d'une comparaison entre deux expressions entières dans l'environnement m.
     Renvoie true si la comparaison peut être satisfaite pour au moins une paire de valeurs.
  *)
  let eval_compare e1 op e2 m =
    let f = match op with
      | AST_EQUAL -> Z.equal
      | AST_NOT_EQUAL -> (fun x y -> not (Z.equal x y))
      | AST_LESS -> Z.lt
      | AST_LESS_EQUAL -> Z.leq
      | AST_GREATER -> Z.gt
      | AST_GREATER_EQUAL -> Z.geq
    in
    let s1 = eval_expr e1 m and s2 = eval_expr e2 m in
    ValSet.fold (fun v1 acc ->
        ValSet.fold (fun v2 acc -> acc || (f v1 v2)) s2 acc) s1 false

  (* Environnement initial, vide *)
  let init () = EnvSet.singleton Env.empty
  (* Bottom du domaine concret *)
  let bottom () = EnvSet.empty

  (* Applique une fonction f à chaque environnement de l'ensemble m *)
  let env_set_map f m =
    EnvSet.fold (fun x acc -> EnvSet.add (f x) acc) m EnvSet.empty

  (* Ajoute une variable v dans chaque environnement avec la valeur zéro normalisée *)
  let add_var m v =
    env_set_map (Env.add v (normalize Z.zero)) m

  (* Supprime la variable v de chaque environnement *)
  let del_var m v =
    env_set_map (Env.remove v) m

  (* Affectation : pour chaque environnement, évalue l'expression e et met à jour la variable var
     pour chacune des valeurs possibles.
  *)
  let assign m var e =
    EnvSet.fold (fun env acc ->
        let s = eval_expr e env in
        ValSet.fold (fun v acc -> EnvSet.add (Env.add var v env) acc) s acc)
      m EnvSet.empty

  (* Filtre les environnements de m pour ne conserver que ceux qui satisfont la comparaison e1 op e2 *)
  let compare m e1 op e2 =
    EnvSet.filter (fun env -> eval_compare e1 op e2 env) m

  (* Opération de join (union) sur les ensembles d'environnements *)
  let join m1 m2 = EnvSet.union m1 m2
  (* L'opération widen est définie comme join dans ce domaine concret *)
  let widen = join
  (* Opération de meet (intersection) sur les ensembles d'environnements *)
  let meet m1 m2 = EnvSet.inter m1 m2
  (* Vérifie si m1 est inclus dans m2 *)
  let subset m1 m2 = EnvSet.subset m1 m2
  (* Vérifie si l'ensemble d'environnements est vide *)
  let is_bottom m = EnvSet.is_empty m

  (* Affichage d'un ensemble d'environnements pour les variables spécifiées *)
  let print fmt m vars =
    Format.fprintf fmt "{ ";
    EnvSet.iter (fun env ->
        Format.fprintf fmt "[";
        List.iter (fun var ->
            let v = Env.find var env in
            Format.fprintf fmt "%s=%s;" var (Z.to_string v))
          vars;
        Format.fprintf fmt "]; ") m;
    Format.fprintf fmt "}"

  (* Affichage de tous les environnements *)
  let print_all fmt m =
    Format.fprintf fmt "{ ";
    EnvSet.iter (fun env ->
        Format.fprintf fmt "[";
        Env.iter (fun var v ->
            Format.fprintf fmt "%s=%s;" var (Z.to_string v)) env;
        Format.fprintf fmt "]; ") m;
    Format.fprintf fmt "}"
end
