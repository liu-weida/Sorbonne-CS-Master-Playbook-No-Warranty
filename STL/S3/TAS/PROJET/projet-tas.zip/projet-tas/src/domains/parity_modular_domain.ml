(*
  parity_modular_domain.ml
  Domaine de parité en 32-bit machine, déduit de la valeur normalisée.
*)

open Abstract_syntax_tree

module Parity_modular = struct

  (* Définition du type de parité.
     - Even : nombre pair
     - Odd  : nombre impair
     - Top  : inconnu (peut être pair ou impair)
     - Bot  : élément impossible (ensemble vide)
  *)
  type t = Even | Odd | Top | Bot

  (* Élément supérieur du domaine *)
  let top = Top
  (* Élément inférieur du domaine *)
  let bottom = Bot
  (* Teste si un élément est bottom *)
  let is_bottom x = (x = Bot)

  (* Constantes pour la normalisation en 32-bit *)
  let two32 = Z.pow (Z.of_int 2) 32
  let half = Z.pow (Z.of_int 2) 31

  (* Normalisation d'un entier pour le domaine 32-bit signé *)
  let normalize x =
    let r = Z.erem x two32 in
    let r = if Z.sign r < 0 then Z.add r two32 else r in
    if Z.geq r half then Z.sub r two32 else r

  (* Injection d'une constante dans le domaine de parité.
     On considère que si la valeur normalisée est paire, alors c'est Even, sinon Odd.
  *)
  let const z =
    if Z.equal (Z.rem (normalize z) (Z.of_int 2)) Z.zero then Even else Odd

  (* Génère un élément aléatoire entre deux bornes.
     - Si l'extrémité inférieure est supérieure à la borne supérieure, renvoie Bot.
     - Si les deux bornes sont égales, on renvoie la parité de cette valeur.
     - Sinon, on renvoie Top (imprécis).
  *)
  let rand l h =
    if Z.gt l h then Bot
    else if Z.equal l h then const l
    else Top

  (* Détermine si x est inclus dans y dans le domaine de parité *)
  let subset x y =
    match x, y with
    | Bot, _ -> true
    | _, Top -> true
    | Even, Even -> true
    | Odd, Odd -> true
    | _ -> (x = y)

  (* Opération de jointure (union) dans le domaine de parité *)
  let join x y = match x, y with
    | Bot, a | a, Bot -> a
    | Even, Even -> Even
    | Odd, Odd -> Odd
    | _ -> Top

  (* Opération de rencontre (intersection) dans le domaine de parité *)
  let meet x y = match x, y with
    | Top, a | a, Top -> a
    | Bot, _ | _, Bot -> Bot
    | Even, Even -> Even
    | Odd, Odd -> Odd
    | _ -> Bot

  (* L'opération de widening est définie comme join *)
  let widen = join

  (* Opération de comparaison pour AST_EQUAL, AST_NOT_EQUAL, etc. *)
  let compare x y op =
    match x, y, op with
    | Bot, _, _ | _, Bot, _ -> (Bot, Bot)
    | _, _, (AST_LESS | AST_LESS_EQUAL | AST_GREATER | AST_GREATER_EQUAL) ->
        if x = Bot || y = Bot then (Bot, Bot) else (x, y)
    | _, _, AST_EQUAL ->
        (match x, y with
         | Even, Even -> (Even, Even)
         | Odd, Odd -> (Odd, Odd)
         | Even, Top -> (Even, Top)
         | Odd, Top -> (Odd, Top)
         | Top, Even -> (Top, Even)
         | Top, Odd -> (Top, Odd)
         | Top, Top -> (Top, Top)
         | _ -> (Bot, Bot))
    | _, _, AST_NOT_EQUAL ->
        (x, y)
  
  (* Opération rétrograde unaire : renvoie l'intersection de x et r *)
  let bwd_unary x _ r = meet x r
  (* Opération rétrograde binaire : ne raffine pas les opérandes *)
  let bwd_binary x y _ _ = (x, y)

  (* Fonctions de raffinement spécifiques pour conserver la parité paire *)
  let keep_even x =
    match x with
    | Bot -> Bot
    | Even -> Even
    | Odd -> Bot
    | Top -> Even   (* Top représente Even ∪ Odd, on ne conserve que Even *)

  (* Fonctions de raffinement spécifiques pour conserver la parité impaire *)
  let keep_odd x =
    match x with
    | Bot -> Bot
    | Even -> Bot
    | Odd -> Odd
    | Top -> Odd

  (* Vérifie si l'élément représente uniquement des valeurs paires *)
  let is_all_even x =
    match x with
    | Even -> true
    | _ -> false

  (* Vérifie si l'élément représente uniquement des valeurs impaires *)
  let is_all_odd x =
    match x with
    | Odd -> true
    | _ -> false
end
