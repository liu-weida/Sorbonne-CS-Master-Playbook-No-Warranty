(*
  Cours "Typage et Analyse Statique" - Master STL
  Sorbonne Université
  Antoine Miné 2015-2022
*)

(*
   Lifts a value domain (abstracting sets of integers)
   into a non-relational domain (abstracting sets of maps,
   from variables to integers).
 *)

 open Abstract_syntax_tree
 open Abstract_syntax_printer
 open Value_domain
 
 let non_relational_debug = ref false
 
 let debugstr = "-- DEBUG: "
 
 (* -------------------------------------------------------------------------- *)
 (* Part 1: a debugging wrapper that also satisfies VALUE_DOMAIN              *)
 (* -------------------------------------------------------------------------- *)
 
 module DebugValue(V : VALUE_DOMAIN) = struct
 
   type t = V.t
 
   let debug_int_unary_op op i o =
     if !non_relational_debug then
       Format.printf "%s%s %a ~> %a@."
         debugstr op V.print i V.print o
 
   let debug_int_binary_int_op op i1 i2 o =
     if !non_relational_debug then
       Format.printf "%s%a %s %a ~> %a@."
         debugstr V.print i1 op V.print i2 V.print o
 
   let debug_int_binary_int_int_op op i1 i2 o1 o2 =
     if !non_relational_debug then
       Format.printf "%s%a %s %a ~> %a, %a@."
         debugstr V.print i1 op V.print i2 V.print o1 V.print o2
 
   let top = V.top
   let bottom = V.bottom
   let print = V.print
 
   let unary v op =
     let rep = V.unary v op in
     debug_int_unary_op (string_of_int_unary_op op) v rep;
     rep
 
   let binary v1 v2 op =
     let rep = V.binary v1 v2 op in
     debug_int_binary_int_op (string_of_int_binary_op op) v1 v2 rep;
     rep
 
   let const z =
     let rep = V.const z in
     if !non_relational_debug then
       Format.printf "%sconst %a ~> %a@."
         debugstr Z.pp_print z V.print rep;
     rep
 
   let rand z1 z2 =
     let rep = V.rand z1 z2 in
     if !non_relational_debug then
       Format.printf "%srand %a %a ~> %a@."
         debugstr Z.pp_print z1 Z.pp_print z2 V.print rep;
     rep
 
   let join v1 v2 =
     let rep = V.join v1 v2 in
     debug_int_binary_int_op "⊔" v1 v2 rep;
     rep
 
   let meet v1 v2 =
     let rep = V.meet v1 v2 in
     debug_int_binary_int_op "⊓" v1 v2 rep;
     rep
 
   let widen v1 v2 =
     let rep = V.widen v1 v2 in
     debug_int_binary_int_op "▿" v1 v2 rep;
     rep
 
   let subset v1 v2 =
     let rep = V.subset v1 v2 in
     if !non_relational_debug then
       Format.printf "%s%a ⊏ %a ~> %b@."
         debugstr V.print v1 V.print v2 rep;
     rep
 
   let is_bottom v =
     let rep = V.is_bottom v in
     if !non_relational_debug then
       Format.printf "%sis_bottom %a ~> %b@."
         debugstr V.print v rep;
     rep
 
   let compare v1 v2 cmp_op =
     let (r1,r2) = V.compare v1 v2 cmp_op in
     debug_int_binary_int_int_op (string_of_compare_op cmp_op) v1 v2 r1 r2;
     (r1, r2)
 
   let bwd_unary v op v' =
     let rep = V.bwd_unary v op v' in
     if !non_relational_debug then
       Format.printf
         "%s%s %a (bwd from %a) ~> %a@."
         debugstr (string_of_int_unary_op op)
         V.print v V.print v' V.print rep;
     rep
 
   let bwd_binary v1 v2 op v' =
     let (r1,r2) = V.bwd_binary v1 v2 op v' in
     if !non_relational_debug then
       Format.printf
         "%s%a %s %a (bwd from %a) ~> %a, %a@."
         debugstr
         V.print v1 (string_of_int_binary_op op)
         V.print v2 V.print v' V.print r1 V.print r2;
     (r1,r2)
 
 
 end 

 (* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ 
    This is crucial if we declared : VALUE_DOMAIN. We must provide is_singleton.
 *)
 
 
 (* -------------------------------------------------------------------------- *)
 (* Part 2: non-relational domain parameterized by a value domain V           *)
 (* -------------------------------------------------------------------------- *)
 
 module NonRelational(V : VALUE_DOMAIN) = struct
 
   (* We'll wrap V with DebugValue to get debugging. *)
   module DV = DebugValue(V)
 
   (* a map from variables (strings) to DV.t *)
   module VarMap = Mapext.Make(String)
 
   type env = DV.t VarMap.t
 
   type t = Val of env | BOT
 
   exception Empty
 
   (* an annotated AST for integer expressions *)
   type atree =
     | A_unary of int_unary_op * atree * DV.t
     | A_binary of int_binary_op * atree * DV.t * atree * DV.t
     | A_var of var * DV.t
     | A_cst of DV.t
 
   (* ------------------------------------------------------------------------ *)
   (*  Expression evaluation with constant folding & special multiply-0 logic *)
   (* ------------------------------------------------------------------------ *)
 
   let rec eval (m:env) (e:int_expr) : atree * DV.t =
     match e with
 
     | AST_int_unary (op,(e1,_)) ->
       let a1,v1 = eval m e1 in
       (A_unary(op,a1,v1), DV.unary v1 op)
 
     | AST_int_binary (op,(e1,_),(e2,_)) ->
       begin
         match op with
         | AST_MULTIPLY ->
           (match e1,e2 with
 
            (* (1) 乘以0 => 结果=0 => even & [0;0] *)
            | AST_int_const("0",_), _
            | _, AST_int_const("0",_) ->
              let v_zero = DV.const Z.zero in
              (A_cst v_zero, v_zero)
 
            (* (2) 如果左右皆是常量 => 常量折叠 => 结果是 const(z1*z2) *)
            | AST_int_const(s1,_), AST_int_const(s2,_) ->
              let z1 = Z.of_string s1 in
              let z2 = Z.of_string s2 in
              let z  = Z.mul z1 z2 in
              let v  = DV.const z in
              (A_cst v, v)
 
            (* (3) 其它情况 => 常规抽象运算 *)
            | _ ->
              let a1,v1 = eval m e1 in
              let a2,v2 = eval m e2 in
              let v = DV.binary v1 v2 AST_MULTIPLY in
              (A_binary(AST_MULTIPLY,a1,v1,a2,v2), v)
           )
 
         | AST_DIVIDE ->
           (match e1,e2 with
            (* 若左右皆是常量 => const folding *)
            | AST_int_const(s1,_), AST_int_const(s2,_) ->
              let z1 = Z.of_string s1 in
              let z2 = Z.of_string s2 in
              if Z.equal z2 Z.zero then
                let vb = DV.bottom in
                (A_cst vb, vb)
              else
                let z  = Z.div z1 z2 in
                let v  = DV.const z in
                (A_cst v, v)
            | _ ->
              (* 常规处理 *)
              let a1,v1 = eval m e1 in
              let a2,v2 = eval m e2 in
              let v = DV.binary v1 v2 AST_DIVIDE in
              (A_binary(AST_DIVIDE,a1,v1,a2,v2), v)
           )
 
         | AST_PLUS | AST_MINUS ->
           (match e1,e2 with
            (* 若都是常量 => constant folding *)
            | AST_int_const(s1,_), AST_int_const(s2,_) ->
              let z1 = Z.of_string s1 in
              let z2 = Z.of_string s2 in
              let z =
                match op with
                | AST_PLUS -> Z.add z1 z2
                | AST_MINUS-> Z.sub z1 z2
                | _ -> assert false
              in
              let v = DV.const z in
              (A_cst v, v)
            | _ ->
              (* 常规 *)
              let a1,v1 = eval m e1 in
              let a2,v2 = eval m e2 in
              let v = DV.binary v1 v2 op in
              (A_binary(op,a1,v1,a2,v2), v)
           )
       end
 
     | AST_identifier(var,_) ->
       let vv = VarMap.find var m in
       (A_var(var,vv), vv)
 
     | AST_int_const (c,_) ->
       let z = Z.of_string c in
       let vv = DV.const z in
       (A_cst vv, vv)
 
     | AST_rand ((c1,_),(c2,_)) ->
       let z1 = Z.of_string c1 in
       let z2 = Z.of_string c2 in
       let vv = DV.rand z1 z2 in
       (A_cst vv, vv)
 
 
   (* backward refinement over an annotated AST *)
   let rec refine (m:env) (a:atree) (r:DV.t) : env =
     match a with
     | A_unary (op,a1,v1) ->
       let w1 = DV.bwd_unary v1 op r in
       refine m a1 w1
 
     | A_binary (op,a1,v1,a2,v2) ->
       let w1,w2 = DV.bwd_binary v1 v2 op r in
       let m2 = refine m a1 w1 in
       refine m2 a2 w2
 
     | A_var (var,v) ->
       let w = DV.meet v r in
       if DV.is_bottom w then raise Empty;
       VarMap.add var w m
 
     | A_cst v ->
       if DV.is_bottom (DV.meet v r) then raise Empty;
       m
 
   let apply_compare (m:env) (e1:int_expr) (op:compare_op) (e2:int_expr) : env =
     let a1,v1 = eval m e1 in
     let a2,v2 = eval m e2 in
     let w1,w2 = DV.compare v1 v2 op in
     refine (refine m a1 w1) a2 w2
 
   (* ------------------------------------------------------------------------ *)
   (*  Implementation of the DOMAIN interface                                  *)
   (* ------------------------------------------------------------------------ *)
 
   let init () = Val (VarMap.empty)
 
   let bottom () = BOT
 
   let add_var a var = match a with
     | BOT -> BOT
     | Val m ->
       Val (VarMap.add var (DV.const Z.zero) m)
 
   let del_var a var = match a with
     | BOT -> BOT
     | Val m ->
       Val (VarMap.remove var m)
 
   let assign a var e = match a with
     | BOT -> BOT
     | Val m ->
       let _,v = eval m e in
       if DV.is_bottom v then BOT
       else Val (VarMap.add var v m)
 
   let compare a e1 op e2 = match a with
     | BOT -> BOT
     | Val m ->
       (try Val(apply_compare m e1 op e2) with Empty -> BOT)
 
   let join a b = match a,b with
     | BOT, x | x, BOT -> x
     | Val m1, Val m2 ->
       Val (VarMap.map2z (fun _ x y -> DV.join x y) m1 m2)
 
   let meet a b = match a,b with
     | BOT,x | x,BOT -> x
     | Val m1, Val m2 ->
       (try
          Val (VarMap.map2z
                 (fun _ vx vy ->
                   let w = DV.meet vx vy in
                   if DV.is_bottom w then raise Empty;
                   w
                 ) m1 m2)
        with Empty -> BOT)
 
   let widen a b = match a,b with
     | BOT,x | x,BOT -> x
     | Val m1, Val m2 ->
       Val (VarMap.map2z (fun _ vx vy -> DV.widen vx vy) m1 m2)
 
   let subset a b = match a,b with
     | BOT,_ -> true
     | _,BOT -> false
     | Val m1, Val m2 ->
       VarMap.for_all2z (fun _ x y -> DV.subset x y) m1 m2
 
   let is_bottom x = (x = BOT)
 
   let print fmt a vars =
     match a with
     | BOT -> Format.fprintf fmt "⊥"
     | Val m ->
       Format.fprintf fmt "[";
       let first = ref true in
       List.iter
         (fun var ->
            let vv = VarMap.find var m in
            if !first then first := false else Format.fprintf fmt ",";
            Format.fprintf fmt " %s in %a" var DV.print vv
         )
         vars;
       Format.fprintf fmt " ]"
 
   let print_all fmt a =
     match a with
     | BOT -> Format.fprintf fmt "⊥"
     | Val m ->
       Format.fprintf fmt "[";
       let first = ref true in
       VarMap.iter
         (fun var vv ->
            if !first then first := false else Format.fprintf fmt ",";
            Format.fprintf fmt " %s in %a" var DV.print vv
         )
         m;
       Format.fprintf fmt " ]"
 
 end
 