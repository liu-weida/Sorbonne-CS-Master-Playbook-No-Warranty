open Abstract_syntax_tree

module Intervals = struct

  (* Définition des bornes pour les intervalles *)
  type bound = 
    | MINF                (* Moins l'infini *)
    | PINF                (* Plus l'infini *)
    | Int of Z.t          (* Une valeur entière *)
  
  (* Définition des intervalles *)
  type t = 
    | Interval of bound * bound  (* Un intervalle défini par deux bornes *)
    | BOT                        (* Intervalle vide *)
  
  (* Intervalle universel qui couvre toutes les valeurs *)  
  let top = Interval (MINF, PINF)

  (* Intervalle vide *)
  let bottom = BOT

  (* Intervalle contenant une seule valeur *)
  let const (z : Z.t) : t =
    Interval (Int z, Int z)

  (* Intervalle entre deux valeurs, ou vide si les bornes sont incorrectes *)   
  let rand (a : Z.t) (b : Z.t) : t =
    if Z.leq a b then
      Interval (Int a, Int b)
    else
      BOT

  (* Opérations sur les bornes *)
  (* *********************** *)

  (* Négation d'une borne *)
  let bound_neg (a:bound) : bound = match a with
    | MINF -> PINF
    | PINF -> MINF
    | Int i -> Int(Z.neg i)

  (* Addition de deux bornes *)
  let bound_add (a:bound) (b:bound) : bound = match a,b with
    | MINF, PINF | PINF, MINF ->  invalid_arg "bound add"
    | PINF, _    | _, PINF    ->  PINF
    | MINF, _    | _, MINF    ->  MINF
    | Int i, Int j            ->  Int(Z.add i j)

  (* Soustraction de deux bornes *)
  let bound_sub (a:bound) (b:bound) : bound = bound_add a (bound_neg b)

  (* Multiplication de deux bornes *)
  let bound_mul (a:bound) (b:bound) : bound = match a,b with
    | MINF, PINF | PINF, MINF         ->  invalid_arg "bound mul"
    | Int o, _ when Z.equal o Z.zero  ->  Int Z.zero
    | _, Int o when Z.equal o Z.zero  ->  Int Z.zero
    | MINF, Int i | Int i, MINF       ->  if Z.lt i Z.zero then PINF else MINF
    | PINF, Int i | Int i, PINF       ->  if Z.lt i Z.zero then MINF else PINF
    | Int i, Int j                    ->  Int (Z.mul i j)
    | _, _                            ->  invalid_arg "bound mul"

  (* Division de deux bornes *)
  let bound_div (a:bound) (b:bound) : bound = match a,b with
    | MINF, PINF  | PINF, MINF        ->  invalid_arg "bound div"
    | Int o, _ when Z.equal o Z.zero  ->  Int Z.zero
    | MINF, Int i                     ->  if Z.lt i Z.zero then PINF else MINF
    | Int _, MINF                     ->  Int Z.zero
    | Int _, PINF                     ->  Int Z.zero
    | PINF, Int i                     ->  if Z.lt i Z.zero then MINF else PINF
    | Int i, Int j                    ->  Int(Z.div i j)
    | _, _                            ->  invalid_arg "bound_div"

  (* Renvoie la borne maximum parmi deux bornes *)
  let bound_max (a:bound) (b:bound) : bound = match a,b with
    | MINF, MINF  | PINF, PINF        ->  a
    | MINF, _     | _, PINF           ->  b
    | PINF, _     | _, MINF           ->  a
    | Int i, Int j                    ->  Int (Z.max i j)

  (* Renvoie la borne minimum parmi deux bornes *)
  let bound_min (a:bound) (b:bound) : bound = match a,b with
    | MINF, MINF  | PINF, PINF        ->  a
    | MINF, _     | _, PINF           ->  a
    | PINF, _     | _, MINF           ->  b
    | Int i, Int j                    ->  Int (Z.min i j)
    
  (* Vérifie l'égalité entre deux bornes *)
  let bound_eq (a:bound) (b:bound) : bool = match a,b with
    | MINF, MINF | PINF, PINF         -> true
    | Int i, Int j                    -> Z.equal i j
    | _, _                            -> false

  (* Vérifie si une borne est strictement plus grande qu'une autre *)
  let bound_gt (a:bound) (b:bound) : bool = match a,b with
    | PINF, _ | _, MINF               ->  true
    | Int i, Int j                    ->  Z.gt i j
    | _, _                            -> false

  (* Vérifie si une borne est supérieure ou égale à une autre *)
  let bound_geq (a:bound) (b:bound) : bool = match a,b with
    | PINF, _ | _, MINF               ->  true
    | Int i, Int j                    ->  Z.geq i j
    | _, _                            ->  false

  (* Fonction join pour obtenir un intervalle englobant deux intervalles *)
  let join x y = match x,y with
    | Interval(a1, b1), Interval(a2,b2) ->
      let min_bound = bound_min a1 a2 in
      let max_bound = bound_max b1 b2 in
      Interval(min_bound, max_bound)
    | BOT, _  | _, BOT                  ->  BOT
  
  (* Fonction meet pour obtenir l'intersection de deux intervalles *)
  let meet x y = match x,y with
    | BOT, _  | _, BOT                ->  BOT
    | Interval(a1,b1), Interval(a2,b2) ->  
      let min_bound = bound_max a1 a2 in
      let max_bound = bound_min b1 b2 in 
      if bound_geq max_bound min_bound then Interval(min_bound, max_bound) else BOT

  (* Vérifie si un intervalle est inclus dans un autre *)
  let subset x y = match x,y with
    | BOT, _  | _, Interval(MINF, PINF) ->  true
    | _, BOT                            ->  false
    | Interval(MINF, PINF), _           ->  false
    | Interval(Int a1, Int b1), Interval(Int a2, Int b2)  ->  Z.geq a1 a2 && Z.leq b1 b2
    | Interval(_, Int b1), Interval(MINF, Int b2)         ->  Z.leq b1 b2
    | Interval(Int a1, _), Interval(Int a2, PINF)         ->  Z.geq a1 a2
    | _, _                              -> false

  (* Vérifie si un intervalle est vide *)
  let is_bottom x = 
    x = BOT

  (* Affiche un intervalle *)
  let print fmt x = 
    match x with
    | BOT           ->  Format.fprintf fmt "⊥"
    | Interval (a,b) ->
      match a,b with
      | MINF, PINF    ->  Format.fprintf fmt "[-∞;+∞]"
      | MINF, Int b   ->  Format.fprintf fmt "[-∞;%s]" (Z.to_string b)
      | Int a, PINF   ->  Format.fprintf fmt "[%s;+∞]" (Z.to_string a)
      | Int a, Int b  ->  Format.fprintf fmt "[%s;%s]" (Z.to_string a) (Z.to_string b)
      | _, _          ->  raise (Invalid_argument "not valid bounds")

  (* Fonction unitaire (unary) sur un intervalle *)
  let unary x op = match op with
    | AST_UNARY_PLUS  -> x
    | AST_UNARY_MINUS -> match x with
      | Interval (a,b) ->   Interval(bound_neg b, bound_neg a)
      | _              ->   BOT

  (* Fonction d'addition abstraite *)
  let add x y = match x,y with
    | Interval(a1,b1), Interval(a2,b2)  ->  Interval(bound_add a1 a2, bound_add b1 b2)
    | _, _                              ->  BOT

  (* Fonction de soustraction abstraite *)
  let sub x y = match x,y with
    | Interval(a1,b1), Interval(a2,b2)  ->  Interval(bound_sub a1 b2, bound_sub b1 a2)
    | _, _                              ->  BOT

  (* Fonction de multiplication abstraite *)
  let mul x y = match x,y with
    | Interval(a1,b1), Interval(a2,b2)  ->  
      let d1 = bound_mul a1 b2 in
      let d2 = bound_mul a1 a2 in
      let d3 = bound_mul b1 b2 in
      let d4 = bound_mul b1 a2 in
      Interval( bound_min (bound_min d1 d2) (bound_min d3 d4), bound_max (bound_max d1 d2) (bound_max d3 d4)) 
    | _, _                              ->  BOT

  (* Fonction de division abstraite *)
  let div x y = match x,y with
    | _, Interval(Int a, _) when Z.equal a Z.zero -> BOT
    | _, Interval(_, Int a) when Z.equal a Z.zero -> BOT
    | Interval(a1,b1), Interval(a2,b2)            ->  
      let d1 = bound_div a1 b2 in
      let d2 = bound_div a1 a2 in
      let d3 = bound_div b1 b2 in
      let d4 = bound_div b1 a2 in
      Interval( bound_min (bound_min d1 d2) (bound_min d3 d4), bound_max (bound_max d1 d2) (bound_max d3 d4)) 
    | _, _                                         ->  BOT    

  (* Fonction binaire qui choisit l'opération selon l'opérateur *)
  let binary x y op = match op with
    | AST_PLUS      -> add x y
    | AST_MINUS     -> sub x y
    | AST_MULTIPLY  -> mul x y
    | AST_DIVIDE    -> div x y

  (* Opération d'égalité qui retourne l'intersection des intervalles *)
  let eq a b = match a,b with
    | Interval(_,_),Interval(_,_)   ->  let res = meet a b in res, res
    | _, _                          ->  BOT, BOT

  (* Opération de différence (non égal) *)
  let neq a b = match a,b with
    | BOT, _  | _, BOT                                  ->  a,b
    | Interval(MINF, PINF), _ | _, Interval(MINF,PINF)  ->  a,b
    | Interval(x,y), Interval(z,v)                      ->  
      if (bound_eq x z) && (bound_eq y v) then a,b 
      else Interval(bound_add (bound_min x z) (Int Z.one), bound_max y v), Interval(bound_min x z, bound_min y v)

  (* Opération "supérieur ou égal" qui affine les intervalles *)
  let geq a b = match a,b with
    | BOT, _  | _, BOT                                  ->  BOT, BOT
    | Interval(x1,y1), Interval(x2,y2)                  ->
      if bound_geq y1 x2 then
        let new_a = Interval(bound_max x1 x2, y1) in
        let new_b = Interval(x2, bound_min y1 y2) in
        new_a, new_b
      else
        BOT, BOT

  (* Opération "supérieur strict" qui affine les intervalles *)
  let gt a b = match a,b with
    | BOT, _  | _, BOT                                  ->  BOT,BOT
    | Interval(x1,y1), Interval(x2,y2)                  ->
      if bound_gt y1 x2 then
        let new_a = Interval(bound_max x1 (bound_add x2 (Int Z.one)), y1) in
        let new_b = Interval(x2, bound_min y2 (bound_sub y1 (Int Z.one))) in
        new_a, new_b
      else
        BOT, BOT

  (* Fonction de comparaison qui sélectionne l'opération selon l'opérateur de comparaison *)
  let compare x y op = match op with
    | AST_EQUAL         ->  eq x y
    | AST_NOT_EQUAL     ->  neq x y
    | AST_GREATER_EQUAL ->  geq x y
    | AST_GREATER       ->  gt x y
    | AST_LESS_EQUAL    ->  let y',x' = geq y x in x',y'
    | AST_LESS          ->  let y',x' = gt y x in x',y'

  (* Opération d'élargissement (widen) des intervalles *)
  let widen x y = match x,y with
    | BOT, _    ->  y
    | _, BOT    ->  x
    | Interval(a1,b1), Interval(a2,b2)  ->
      let a = match a1,a2 with
        | MINF, _ | _, MINF   ->  MINF
        | PINF, b | b, PINF   ->  b
        | Int i, Int j        ->  if Z.leq i j then Int i else MINF
      in
      let b = match b1,b2 with
        | MINF, b | b, MINF   ->  b
        | PINF, _ | _, PINF   ->  PINF
        | Int i, Int j        ->  if Z.geq i j then Int j else PINF
      in
      Interval(a,b)

  (* Opération rétrograde sur un opérateur unaire *)
  let bwd_unary x op r = match op with
    | AST_UNARY_PLUS    ->  x
    | AST_UNARY_MINUS   ->  match r with
      | BOT                   ->  BOT
      | Interval (MINF, PINF) ->  Interval(MINF, PINF)
      | Interval (a,b)        ->  Interval(bound_neg b, bound_neg a)
      
  (* Opération rétrograde sur un opérateur binaire *)
  let bwd_binary x y op r = match op with
    | AST_PLUS          ->  meet x (sub r y), meet y (sub r x)
    | AST_MINUS         ->  meet x (add y r), meet y (sub x r)
    | AST_MULTIPLY      ->  
      let contains_zero o = subset (const Z.zero) o in
      (if contains_zero y && contains_zero r then x else meet x (div r y)),
      (if contains_zero x && contains_zero r then y else meet y (div r x))
    | AST_DIVIDE        ->  
      let contains_zero o = subset (const Z.zero) o in
      (if contains_zero y && contains_zero r then x else meet x (mul r y)),
      (if contains_zero x && contains_zero r then y else meet y (div x r))

end
