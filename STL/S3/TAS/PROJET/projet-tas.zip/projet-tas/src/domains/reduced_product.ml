open Value_domain

(* On importe le module d'intervalles. Remarque : Assurez-vous que interval_domain.ml n'expose plus ses constructeurs internes. *)
module I = Interval_domain.Intervals
(* On importe le module de parité *)
module P = Parity_domain.Parity

(* Le module Make paramétré par deux domaines de valeur D1 et D2.
   On contraint D1.t à être le type de parité et D2.t le type d'intervalle.
*)
module Make (D1 : VALUE_DOMAIN with type t = P.t)
            (D2 : VALUE_DOMAIN with type t = I.t) = struct

  (* Le type de l'élément dans le domaine produit est un couple (parité, intervalle) *)
  type t = D1.t * D2.t

  (* Élément inférieur (bottom) et supérieur (top) du domaine produit *)
  let bottom = (D1.bottom, D2.bottom)
  let top    = (D1.top,    D2.top)

  (* Un élément est considéré comme bottom si l'un des deux composants est bottom *)
  let is_bottom (p, i) = D1.is_bottom p || D2.is_bottom i

  (* Injection d'une constante : on applique const sur chaque domaine *)
  let const z = (D1.const z, D2.const z)

  (* Injection d'une valeur aléatoire (intervalle) sur l'intervalle [l, h] *)
  let rand l h = (D1.rand l h, D2.rand l h)

  (* Fonction auxiliaire : ajuste les bornes d'un intervalle pour qu'elles soient des nombres pairs.
     Si une borne est un entier, on la modifie pour qu'elle devienne paire.
     Si, après ajustement, la borne inférieure dépasse la borne supérieure, on considère l'intervalle comme vide.
  *)
  let reduce_interval_even i =
    match i with
    | I.Interval(a, b) ->
        let a' =
          match a with
          | I.MINF -> I.MINF
          | I.Int n ->
              if Z.rem n (Z.of_int 2) = Z.zero then I.Int n
              else I.Int (Z.add n Z.one)
          | I.PINF -> I.PINF
        in
        let b' =
          match b with
          | I.PINF -> I.PINF
          | I.Int n ->
              if Z.rem n (Z.of_int 2) = Z.zero then I.Int n
              else I.Int (Z.sub n Z.one)
          | I.MINF -> I.MINF
        in
        (match a', b' with
         | I.Int n1, I.Int n2 when Z.gt n1 n2 -> D2.bottom
         | _ -> I.Interval(a', b'))
    | I.BOT -> I.BOT

  (* Fonction auxiliaire : ajuste les bornes d'un intervalle pour qu'elles soient des nombres impairs.
     Si une borne est un entier, on la modifie pour qu'elle devienne impaire.
     Si, après ajustement, la borne inférieure dépasse la borne supérieure, on considère l'intervalle comme vide.
  *)
  let reduce_interval_odd i =
    match i with
    | I.Interval(a, b) ->
        let a' =
          match a with
          | I.MINF -> I.MINF
          | I.Int n ->
              if Z.rem n (Z.of_int 2) = Z.zero then I.Int (Z.add n Z.one)
              else I.Int n
          | I.PINF -> I.PINF
        in
        let b' =
          match b with
          | I.PINF -> I.PINF
          | I.Int n ->
              if Z.rem n (Z.of_int 2) = Z.zero then I.Int (Z.sub n Z.one)
              else I.Int n
          | I.MINF -> I.MINF
        in
        (match a', b' with
         | I.Int n1, I.Int n2 when Z.gt n1 n2 -> D2.bottom
         | _ -> I.Interval(a', b'))
    | I.BOT -> I.BOT

  (* Fonction de réduction du domaine produit.
     En fonction de la parité p, on ajuste l'intervalle i :
     - Si p est Even, on réduit i pour ne conserver que les valeurs paires.
     - Si p est Odd, on réduit i pour ne conserver que les valeurs impaires.
     - Sinon, on ne modifie pas i.
  *)
  let reduce (p : D1.t) (i : D2.t) : (D1.t * D2.t) =
    if D1.is_bottom p || D2.is_bottom i then
      (D1.bottom, D2.bottom)
    else
      match p with
      | P.Even -> (p, reduce_interval_even i)
      | P.Odd  -> (p, reduce_interval_odd i)
      | _      -> (p, i)

  (* Opération de join sur le domaine produit :
     on applique join sur chaque composant, puis on réduit le résultat.
  *)
  let join (p1, i1) (p2, i2) =
    let p' = D1.join p1 p2 in
    let i' = D2.join i1 i2 in
    reduce p' i'

  (* Opération de meet sur le domaine produit :
     on applique meet sur chaque composant, puis on réduit le résultat.
  *)
  let meet (p1, i1) (p2, i2) =
    let p' = D1.meet p1 p2 in
    let i' = D2.meet i1 i2 in
    reduce p' i'

  (* Opération de widening sur le domaine produit :
     on applique widen sur chaque composant, puis on réduit le résultat.
  *)
  let widen (p1, i1) (p2, i2) =
    let p' = D1.widen p1 p2 in
    let i' = D2.widen i1 i2 in
    reduce p' i'

  (* Vérification de l'inclusion entre deux éléments du domaine produit *)
  let subset (p1, i1) (p2, i2) =
    D1.subset p1 p2 && D2.subset i1 i2

  (* Affichage d'un élément du domaine produit au format "parité ∧ intervalle" *)
  let print fmt (p, i) =
    Format.fprintf fmt "%a ∧ %a" D1.print p D2.print i

  (* Opération unaire sur le domaine produit :
     on applique l'opération unaire sur chaque composant, puis on réduit le résultat.
  *)
  let unary (p, i) op =
    let p' = D1.unary p op in
    let i' = D2.unary i op in
    reduce p' i'

  (* Opération binaire sur le domaine produit :
     on applique l'opération binaire sur chaque composant, puis on réduit le résultat.
  *)
  let binary (p1, i1) (p2, i2) op =
    let rp = D1.binary p1 p2 op in
    let ri = D2.binary i1 i2 op in
    reduce rp ri

  (* Opération de comparaison sur le domaine produit :
     on compare séparément les composants, puis on réduit chacun des résultats.
  *)
  let compare (p1, i1) (p2, i2) op =
    let (np1, np2) = D1.compare p1 p2 op in
    let (ni1, ni2) = D2.compare i1 i2 op in
    ( reduce np1 ni1,
      reduce np2 ni2 )

  (* Opération rétrograde unaire sur le domaine produit :
     on applique bwd_unary sur chaque composant, puis on réduit le résultat.
  *)
  let bwd_unary (p, i) op (rp, ri) =
    let np = D1.bwd_unary p op rp in
    let ni = D2.bwd_unary i op ri in
    reduce np ni

  (* Opération rétrograde binaire sur le domaine produit :
     on applique bwd_binary sur chaque composant, puis on réduit le résultat.
  *)
  let bwd_binary (p1, i1) (p2, i2) op (r1, r2) =
    let (np1, np2) = D1.bwd_binary p1 p2 op r1 in
    let (ni1, ni2) = D2.bwd_binary i1 i2 op r2 in
    ( reduce np1 ni1,
      reduce np2 ni2 )
end
