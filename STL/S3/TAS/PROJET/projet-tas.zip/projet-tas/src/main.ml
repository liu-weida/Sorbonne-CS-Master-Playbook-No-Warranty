(*
  Cours "Typage et Analyse Statique" - Master STL
  Sorbonne Université
  Antoine Miné 2015-2022
*)



module ConcreteAnalysis =
  Interpreter.Interprete(Concrete_domain.Concrete)

module ConstantAnalysis =
  Interpreter.Interprete
    (Non_relational_domain.NonRelational
       (Constant_domain.Constants))

module IntervalAnalysis =
  Interpreter.Interprete
    (Non_relational_domain.NonRelational
       (Interval_domain.Intervals))  (* Assurez-vous que `Interval_domain` existe et est bien implémenté *)

module ParityIntervalAnalysis =
Interpreter.Interprete
  (Non_relational_domain.NonRelational
    (Reduced_product.Make(Parity_domain.Parity)(Interval_domain.Intervals)))
       
    (* Analyse modulaire (32-bit machine) : on utilise nos nouveaux modules *)
    (* module ModularAnalysis =
    Interpreter.Interprete
      (Non_relational_domain.NonRelational
         (Reduced_product.Make(Parity_modular.Parity_modular)(Intervals_modular)))
   *)


(* parse and print filename *)
let doit filename =
  let prog = File_parser.parse_file filename in
  Abstract_syntax_printer.print_prog Format.std_formatter prog


(* default action: print back the source *)
let eval_prog prog =
  Abstract_syntax_printer.print_prog Format.std_formatter prog

(* entry point *)
let main () =
  let action = ref eval_prog in
  let files = ref [] in
  (* parse arguments *)
  Arg.parse
    (* handle options *)
    [

    "-trace",
     Arg.Set Interpreter.trace,
     "Show the analyzer state after each statement";

     "-nonreldebug",
     Arg.Set Non_relational_domain.non_relational_debug,
     "Turns on debugging information for the non relational lifter";

     "-concrete",
     Arg.Unit (fun () -> action := ConcreteAnalysis.eval_prog),
     "Use the concrete domain";

     "-constant",
     Arg.Unit (fun () -> action := ConstantAnalysis.eval_prog),
     "Use the constant abstract domain";

     "-interval",
     Arg.Unit (fun () -> action := IntervalAnalysis.eval_prog),
     "Use the interval abstract domain";  (* Ajout de l'option pour le domaine d'intervalles *)
     
     (* options supplémentaires à ajouter *)
     (* -delay *)
     "-delay"   , Arg.Set_int  (Interpreter.widen_delay)        ,"";
     (* -unroll *)

     "-unroll"  , Arg.Set_int  (Interpreter.loop_unrolling)     ,"";

      (* -parity-interval *)
     "-parity-interval",
     Arg.Unit (fun () -> action := ParityIntervalAnalysis.eval_prog),
     "Use the reduced product: parity × intervals";

     (* "-modular", Arg.Unit (fun () -> action := ModularAnalysis.eval_prog), "Use modular 32-bit semantics"; *)

    ]
    (* handle filenames *)
    (fun filename -> files := (!files)@[filename])
    "";
  List.iter
    (fun filename ->
      let prog = File_parser.parse_file filename in
      !action prog
    )
    !files

let _ = main ()
