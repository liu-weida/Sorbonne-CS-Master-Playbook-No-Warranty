{
  int x;
  x = 100000;
  x = x * 100000;
  print(x);
}
