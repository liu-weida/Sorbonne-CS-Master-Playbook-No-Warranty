# Projet d'analyseur statique du cours TAS - Rapport de projet

# Haotian XUE 21305395 (Parcours STL)

## 1. Fonctionnalités implémentées

### 1.1 Analyse concrète
- **Description** :  
  L’analyseur concret permet d’exécuter un programme en évaluant les expressions selon leur sémantique mathématique (utilisant des entiers Z de OCaml).
- **Implémentation** :  
  Le module `concrete_domain.ml` a été complété pour gérer les environnements (mappings variable → entier) et effectuer l’évaluation concrète des expressions.  
- **Validation** :  
  Les tests situés dans `tests/01_concrete/` fonctionnent comme attendu.

### 1.2 Support des assertions
- **Description** :  
  L’instruction `assert` a été corrigée pour afficher un message d'erreur `"assertion failure"` si l’assertion échoue, tout en continuant l’analyse.
- **Implémentation** :  
  Dans `interpreter.ml`, la fonction `eval_stat` a été modifiée pour utiliser `error ext "assertion failure"` lors de l’échec d’une assertion.
- **Validation** :  
  Les tests dans `tests/03_concrete_assert/` (décommentés progressivement) confirment le comportement attendu.

### 1.3 Complétion du domaine des constantes
- **Description** :  
  Le domaine des constantes (module `constant_domain.ml`) a été complété pour gérer les opérations arithmétiques et les filtres de comparaison.
- **Implémentation** :  
  Toutes les opérations (addition, soustraction, multiplication, division, etc.) sont implémentées, ainsi que les opérations de filtrage par comparaison.
- **Validation** :  
  Les tests dans `tests/04_constant/` passent correctement.

### 1.4 Domaine des intervalles et analyse des boucles
- **Description** :  
  Le domaine des intervalles (module `interval_domain.ml`) permet de représenter des intervalles avec des bornes qui peuvent être des entiers ou ±∞.  
  Le traitement des boucles est amélioré grâce à l’élargissement (`widen`), et des options de délai (`-delay`) et de déroulement (`-unroll`) ont été intégrées.
- **Implémentation** :  
  Le module `interval_domain.ml` a été implanté avec précision (opérations `join`, `meet`, `widen`, etc.), et `interpreter.ml` utilise ces opérations lors de l’analyse de boucles.
- **Validation** :  
  Les tests dans `tests/10_interval/`, `tests/11_interval_cmp/` et `tests/12_interval_loop/` passent sans erreur.

### 1.5 Produit réduit (parité × intervalles)
- **Description** :  
  Le domaine réduit combine les informations du domaine des intervalles et du domaine des parités afin d’affiner l’analyse.
- **Implémentation** :  
  Le module `reduced_product.ml` a été implémenté pour combiner ces deux domaines et afficher le résultat sous la forme `parité ∧ intervalle` (par exemple, `even ∧ [0;0]` ou `even ∧ [12;12]`).
- **Validation** :  
  Les tests dans `tests/20_reduced/` confirment le bon fonctionnement du produit réduit.

## 2. Organisation du projet

- **Structure** :  
  - Le projet est organisé dans le dossier `src/` avec une répartition claire :  
    - `src/domains/` contient les différents domaines (concrets, constantes, intervalles, parité, produit réduit, etc.) ainsi que les modules d'extension pour la sémantique machine modulaires.
    - `src/frontend/` contient le lexer, le parser et les utilitaires d'analyse.
    - `src/interpreter/` contient l'interpréteur (`interpreter.ml`).
    - Le point d'entrée est `src/main.ml`.
- **Build** :  
  - Le fichier `src/dune` utilise `(include_subdirs unqualified)` pour inclure automatiquement tous les modules.
  - Dans `src/domains/`, un fichier `dune` avec `(include_subdirs no)` a été ajouté pour éviter tout conflit de configuration.

## 3. Extension au choix : Analyse des entiers machine modulaires

### 3.1 Objectif
Adapter la sémantique du langage afin que le type `int` corresponde à des entiers 32-bit signés, en opposition aux entiers mathématiques parfaits.  
Pour cela, chaque opération arithmétique est suivie d'une normalisation via une fonction `normalize` qui ramène le résultat dans l'intervalle \([-2^{31}, 2^{31}-1]\).

### 3.2 Implémentation
- **Nouveaux modules** :  
  Les modules suivants ont été ajoutés dans `src/domains/` :
  - `concrete_modular_domain.ml`
  - `constant_modular_domain.ml`
  - `interval_modular_domain.ml` (le module définit un sous-module `Intervals_modular`)
  - `parity_modular_domain.ml` (définit le module `Parity_modular`)
  
  Chaque module implémente l'interface `VALUE_DOMAIN` et intègre la normalisation via la fonction `normalize`.
  
- **Intégration dans main.ml** :  
  Un nouveau mode d’analyse est accessible avec l’option `-modular`.  
  Dans `src/main.ml`, la nouvelle analyse modulaire est instanciée comme suit :
  
  ```ocaml
  module ModularAnalysis =
    Interpreter.Interprete
      (Non_relational_domain.NonRelational
         (Reduced_product.Make(Parity_modular_domain)(Interval_modular_domain.Intervals_modular)))

Lorsque l'option -modular est spécifiée, l'analyseur utilise la sémantique des entiers machine modulaires.

### 3.3 Tests de l'extension

Des tests spécifiques ont été ajoutés dans le répertoire `tests/30_extension/` pour illustrer le comportement en mode 32-bit machine (entiers modulaires) :

- **0100_modular_overflow.c**  
  *Contenu* :
  ```c
  {
    int x;
    x = 2147483647;  // 2^31 - 1
    x = x + 1;
    print(x);
  }

Attendu :
L'analyseur doit afficher que x vaut -2147483648, par exemple :

tests/30_extension/0100_modular_overflow.c:...: [ x in even ∧ [-2147483648;-2147483648] ]
analysis ended



- **0101_modular_underflow.c**  
  *Contenu* :
  ```c
    {
        int x;
        x = -2147483648; // -2^31
        x = x - 1;
        print(x);
    }


Attendu :
Le résultat doit être 2147483647, par exemple :

tests/30_extension/0101_modular_underflow.c:...: [ x in odd ∧ [2147483647;2147483647] ]
analysis ended


- **0102_modular_multiplication.c**  
  *Contenu* :
  ```c
   {
        int x;
        x = 100000;
        x = x * 100000;
        print(x);
    }



Calcul :
100000 * 100000 = 10000000000
10000000000 mod 2^32 = 1410065408

Attendu :
L'affichage doit indiquer que x vaut 1410065408, par exemple :

tests/30_extension/0102_modular_multiplication.c:...: [ x in even ∧ [1410065408;1410065408] ]
analysis ended


## 4. Difficultés rencontrées

Des problèmes d'intégration des modules ont été rencontrés lors de l'ajout des extensions modulaires. En particulier, des incompatibilités de types et des difficultés à faire correspondre les modules avec la signature VALUE_DOMAIN ont nécessité des ajustements, notamment dans le fichier main.ml où il a fallu utiliser la bonne référence (par exemple, Reduced_product.Make(Parity_modular_domain)(Interval_modular_domain.Intervals_modular)) pour instancier le produit réduit en mode modulaire. Par ailleurs, la configuration de Dune a nécessité d'être adaptée (en utilisant (include_subdirs unqualified) dans src/dune et (include_subdirs no) dans src/domains/dune) afin de permettre une compilation cohérente de tous les modules.

## 5. Conclusion

L'analyseur couvre désormais l'analyse concrète, l'analyse des constantes, des intervalles (avec élargissement et options de délai/unroll) et le produit réduit (parité × intervalles). J'ai choisi d'implanter l'extension des entiers machine modulaires. Pour ce faire, de nouveaux modules ont été ajoutés dans le dossier src/domains/ (concrete_modular_domain.ml, constant_modular_domain.ml, interval_modular_domain.ml, parity_modular_domain.ml), et une option -modular a été intégrée dans main.ml pour activer cette sémantique 32-bit signée. Des tests spécifiques dans tests/30_extension/ montrent le comportement en cas de débordement, de sous-débordement et de multiplication entraînant des dépassements. Bien que les tests de base en mode modulaire soient fonctionnels, l'intégration complète (par exemple, la documentation détaillée et la gestion de tous les cas particuliers) reste à finaliser. Globalement, le projet évolue bien et toutes les fonctionnalités principales attendues sont désormais opérationnelles.

