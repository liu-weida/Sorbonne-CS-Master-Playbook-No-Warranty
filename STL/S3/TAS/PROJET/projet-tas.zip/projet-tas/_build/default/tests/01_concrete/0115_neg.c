{
  int x;
  x = -9;
  print(x);
}
