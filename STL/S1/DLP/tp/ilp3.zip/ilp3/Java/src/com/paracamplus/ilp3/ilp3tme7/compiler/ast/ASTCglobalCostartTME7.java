package com.paracamplus.ilp3.ilp3tme7.compiler.ast;

import com.paracamplus.ilp1.compiler.interfaces.IASTCglobalVariable;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp3.ilp3tme7.ast.ASTcostartTME7;
import com.paracamplus.ilp3.ilp3tme7.compiler.interfaces.IASTCglobalCostartTME7;

public class ASTCglobalCostartTME7 extends ASTcostartTME7
        implements IASTCglobalCostartTME7 {

    public ASTCglobalCostartTME7(IASTCglobalVariable function, IASTexpression[] arguments) {
        super(function, arguments);
    }
}
