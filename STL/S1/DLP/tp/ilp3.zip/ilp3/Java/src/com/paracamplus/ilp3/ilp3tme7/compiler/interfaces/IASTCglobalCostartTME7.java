package com.paracamplus.ilp3.ilp3tme7.compiler.interfaces;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTcostartTME7;

public interface IASTCglobalCostartTME7 extends IASTcostartTME7 {

}
