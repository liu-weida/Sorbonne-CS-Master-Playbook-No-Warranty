package com.paracamplus.ilp3.ilp3tme7.compiler;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.interfaces.IASTClocalVariable;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp3.compiler.interfaces.IASTCprogram;
import com.paracamplus.ilp3.ilp3tme7.compiler.interfaces.IASTCglobalCostartTME7;
import com.paracamplus.ilp3.ilp3tme7.compiler.interfaces.IASTCvisitorTME7;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTcostartTME7;

import java.util.Set;

public class FreeVariableCollectorTME7 extends com.paracamplus.ilp3.compiler.FreeVariableCollector
implements IASTCvisitorTME7<Void, Set<IASTClocalVariable>, CompilationException> {
    public FreeVariableCollectorTME7(IASTCprogram program) {
        super(program);
    }

    @Override
    public Void visit(IASTCglobalCostartTME7 iast, Set<IASTClocalVariable> variables) throws CompilationException {
        iast.getFunction().accept(this, variables);
        for ( IASTexpression arg : iast.getArguments() ) {
            arg.accept(this, variables);
        }
        return null;
    }

    @Override
    public Void visit(IASTcostartTME7 iast, Set<IASTClocalVariable> variables) throws CompilationException {
        return visit((IASTCglobalCostartTME7) iast, variables);
    }
}
