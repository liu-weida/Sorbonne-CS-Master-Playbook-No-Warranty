package com.paracamplus.ilp3.ilp3tme7.parser.ilpml;

import antlr4.ILPMLgrammar3tme7Lexer;
import antlr4.ILPMLgrammar3tme7Parser;
import com.paracamplus.ilp1.parser.ParseException;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTfactoryTME7;
import com.paracamplus.ilp3.interfaces.IASTprogram;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

public class ILPMLParserTME7
extends com.paracamplus.ilp3.parser.ilpml.ILPMLParser {
	
	public ILPMLParserTME7(IASTfactoryTME7 factory) {
		super(factory);
	}
		
	@Override
    public IASTprogram getProgram() throws ParseException {
		try {
			ANTLRInputStream in = new ANTLRInputStream(input.getText());
			// flux de caractères -> analyseur lexical
			ILPMLgrammar3tme7Lexer lexer = new ILPMLgrammar3tme7Lexer(in);
			// analyseur lexical -> flux de tokens
			CommonTokenStream tokens =	new CommonTokenStream(lexer);
			// flux tokens -> analyseur syntaxique
			ILPMLgrammar3tme7Parser parser = new ILPMLgrammar3tme7Parser(tokens);
			// démarage de l'analyse syntaxique
			ILPMLgrammar3tme7Parser.ProgContext tree = parser.prog();
			// parcours de l'arbre syntaxique et appels du Listener
			ParseTreeWalker walker = new ParseTreeWalker();
			ILPMLListenerTME7 extractor = new ILPMLListenerTME7((IASTfactoryTME7)factory);
			walker.walk(extractor, tree);	
			return tree.node;
		} catch (Exception e) {
			throw new ParseException(e);
		}
    }

}
