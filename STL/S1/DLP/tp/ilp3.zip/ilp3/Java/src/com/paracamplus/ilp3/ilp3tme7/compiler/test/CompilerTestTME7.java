/* *****************************************************************
 * ILP9 - Implantation d'un langage de programmation.
 * by Christian.Queinnec@paracamplus.com
 * See http://mooc.paracamplus.com/ilp9
 * GPL version 3
 ***************************************************************** */
package com.paracamplus.ilp3.ilp3tme7.compiler.test;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.GlobalVariableEnvironment;
import com.paracamplus.ilp1.compiler.OperatorEnvironment;
import com.paracamplus.ilp1.compiler.OperatorStuff;
import com.paracamplus.ilp1.compiler.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.compiler.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp1.compiler.optimizer.IdentityOptimizer;
import com.paracamplus.ilp1.compiler.test.CompilerRunner;
import com.paracamplus.ilp1.parser.xml.IXMLParser;
import com.paracamplus.ilp3.ilp3tme7.ast.ASTfactoryTME7;
import com.paracamplus.ilp3.ilp3tme7.compiler.CompilerTME7;
import com.paracamplus.ilp3.ilp3tme7.compiler.GlobalVariableStuffTME7;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTfactoryTME7;
import com.paracamplus.ilp3.ilp3tme7.parser.ilpml.ILPMLParserTME7;
import com.paracamplus.ilp3.parser.xml.XMLParser;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import java.io.File;
import java.util.Collection;

@RunWith(Parameterized.class)
public class CompilerTestTME7 extends com.paracamplus.ilp3.compiler.test.CompilerTest {
    
    protected static String[] samplesDirName = { "SamplesTME7"};
    protected static String pattern = ".*\\.ilpml";
    protected static String scriptCommand = "Java/src/com/paracamplus/ilp3/ilp3tme7/C/compileThenRun.sh +gc";
	protected static String grammarFile = "XMLGrammars/grammar3.rng";
 
   
    public CompilerTestTME7(final File file) {
    	super(file);
    }    

    @Override
    public void configureRunner(CompilerRunner run) throws CompilationException {
    	// configuration du parseur
        IASTfactoryTME7 factory = new ASTfactoryTME7();
        IXMLParser xmlparser = new XMLParser(factory);
        xmlparser.setGrammar(new File(grammarFile));
        run.setXMLParser(xmlparser);
        run.setILPMLParser(new ILPMLParserTME7(factory));

        // configuration du compilateur
        IOperatorEnvironment ioe = new OperatorEnvironment();
        OperatorStuff.fillUnaryOperators(ioe);
        OperatorStuff.fillBinaryOperators(ioe);
        IGlobalVariableEnvironment gve = new GlobalVariableEnvironment();
        GlobalVariableStuffTME7.fillGlobalVariables(gve);
        CompilerTME7 compiler = new CompilerTME7(ioe, gve);
        compiler.setOptimizer(new IdentityOptimizer());
        run.setCompiler(compiler);

        // configuration du script de compilation et exécution
        run.setRuntimeScript(scriptCommand);    	
    }
    
    @Parameters(name = "{0}")
    public static Collection<File[]> data() throws Exception {
    	return CompilerRunner.getFileList(samplesDirName, pattern);
    }    	
}
