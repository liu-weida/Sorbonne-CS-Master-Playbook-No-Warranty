package com.paracamplus.ilp3.ilp3tme7.ast;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp1.interfaces.IASTvariable;
import com.paracamplus.ilp3.ast.ASTfactory;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTcostartTME7;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTfactoryTME7;

public class ASTfactoryTME7 extends ASTfactory implements IASTfactoryTME7 {

	public IASTcostartTME7 newCostart( IASTexpression function, IASTexpression[] arguments) {
		return new ASTcostartTME7 (function,arguments);
	}
	
}
