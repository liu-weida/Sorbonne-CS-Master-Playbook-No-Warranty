package com.paracamplus.ilp3.ilp3tme7.interfaces;

public interface IASTvisitorTME7 <Result, Data, Anomaly extends Throwable>
extends com.paracamplus.ilp3.interfaces.IASTvisitor<Result, Data, Anomaly>{
	Result visit(IASTcostartTME7 iast,Data data ) throws Anomaly;
}
