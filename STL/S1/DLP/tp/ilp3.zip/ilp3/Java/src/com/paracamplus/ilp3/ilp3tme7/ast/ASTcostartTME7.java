package com.paracamplus.ilp3.ilp3tme7.ast;

import com.paracamplus.ilp1.ast.ASTinvocation;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp1.interfaces.IASTvisitor;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTcostartTME7;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTvisitorTME7;

public class ASTcostartTME7 extends ASTinvocation  implements IASTcostartTME7  {


	private final IASTexpression function;
    private final IASTexpression[] arguments;
    
	public ASTcostartTME7(IASTexpression function, IASTexpression[] arguments) {
		super(function, arguments);
		this.function = function;
		this.arguments = arguments;
		// TODO Auto-generated constructor stub
	}
    
	@Override
	public IASTexpression getFunction() {
		// TODO Auto-generated method stub
		return function;
	}
	@Override
	public IASTexpression[] getArguments() {
		// TODO Auto-generated method stub
		return arguments;
	}
	@Override
	public <Result, Data, Anomaly extends Throwable> Result accept(IASTvisitor<Result, Data, Anomaly> visitor,
			Data data) throws Anomaly {
		// TODO Auto-generated method stub
		return ((IASTvisitorTME7<Result, Data, Anomaly>) visitor).visit(this, data);
	}
	
}
