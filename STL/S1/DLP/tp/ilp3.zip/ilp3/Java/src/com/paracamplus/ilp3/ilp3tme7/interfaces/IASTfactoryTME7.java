package com.paracamplus.ilp3.ilp3tme7.interfaces;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp1.interfaces.IASTvariable;
import com.paracamplus.ilp3.interfaces.IASTfactory;

public interface IASTfactoryTME7 extends IASTfactory{

    IASTcostartTME7 newCostart ( IASTexpression function, IASTexpression[] arguments);
	
}
