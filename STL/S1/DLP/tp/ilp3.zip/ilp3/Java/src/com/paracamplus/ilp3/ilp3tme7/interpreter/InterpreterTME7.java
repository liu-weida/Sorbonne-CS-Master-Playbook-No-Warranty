package com.paracamplus.ilp3.ilp3tme7.interpreter;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp1.interpreter.interfaces.*;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTcostartTME7;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTvisitorTME7;

import java.util.ArrayList;
import java.util.List;

public class InterpreterTME7 extends com.paracamplus.ilp3.interpreter.Interpreter
        implements IASTvisitorTME7<Object, ILexicalEnvironment, EvaluationException> {


    public InterpreterTME7(IGlobalVariableEnvironment globalVariableEnvironment, IOperatorEnvironment operatorEnvironment) {
        super(globalVariableEnvironment, operatorEnvironment);
    }

    @Override
    public Object visit(IASTcostartTME7 iast, ILexicalEnvironment iLexicalEnvironment) throws EvaluationException {
        Object function = iast.getFunction().accept(this, iLexicalEnvironment);
        if (function instanceof Invocable) {
            Invocable fun = (Invocable) function;
            List<Object> args = new ArrayList<>();
            for (IASTexpression arg : iast.getArguments()) {
                Object a = arg.accept(this, iLexicalEnvironment);
                args.add(a);
            }
            CoroutineInstance coroutineInstance = new CoroutineInstance(fun, args, this);
            coroutineInstance.start();
            return coroutineInstance;
        }else{
            throw new EvaluationException("costart cannot apply " + function.toString());
        }
    }
}
