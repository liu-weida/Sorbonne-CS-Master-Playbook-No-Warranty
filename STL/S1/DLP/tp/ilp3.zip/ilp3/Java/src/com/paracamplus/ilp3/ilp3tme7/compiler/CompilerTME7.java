package com.paracamplus.ilp3.ilp3tme7.compiler;

import com.paracamplus.ilp1.compiler.AssignDestination;
import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.NoDestination;
import com.paracamplus.ilp1.compiler.interfaces.IASTCglobalVariable;
import com.paracamplus.ilp1.compiler.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.compiler.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp1.interfaces.IASTvariable;
import com.paracamplus.ilp3.compiler.interfaces.IASTCprogram;
import com.paracamplus.ilp3.ilp3tme7.compiler.interfaces.IASTCglobalCostartTME7;
import com.paracamplus.ilp3.ilp3tme7.compiler.interfaces.IASTCvisitorTME7;
import com.paracamplus.ilp3.ilp3tme7.compiler.normalizer.INormalizationFactoryTME7;
import com.paracamplus.ilp3.ilp3tme7.compiler.normalizer.NormalizationFactoryTME7;
import com.paracamplus.ilp3.ilp3tme7.compiler.normalizer.NormalizerTME7;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTcostartTME7;
import com.paracamplus.ilp3.interfaces.IASTprogram;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Set;

public class CompilerTME7 extends com.paracamplus.ilp3.compiler.Compiler
        implements IASTCvisitorTME7<Void, CompilerTME7.Context, CompilationException> {

    public CompilerTME7(IOperatorEnvironment ioe, IGlobalVariableEnvironment igve) {
        super(ioe, igve);
    }

    @Override
    public String compile(IASTprogram program)
            throws CompilationException {

        IASTCprogram newprogram = normalize(program);
        newprogram = (IASTCprogram) optimizer.transform(newprogram);

        GlobalVariableCollectorTME7 gvc = new GlobalVariableCollectorTME7();
        Set<IASTCglobalVariable> gvs = gvc.analyze(newprogram);
        newprogram.setGlobalVariables(gvs);

        FreeVariableCollectorTME7 fvc = new FreeVariableCollectorTME7(newprogram);
        newprogram = fvc.analyze();

        Context context = new Context(NoDestination.NO_DESTINATION);
        StringWriter sw = new StringWriter();
        try {
            out = new BufferedWriter(sw);
            visit(newprogram, context);
            out.flush();
        } catch (IOException exc) {
            throw new CompilationException(exc);
        }
        return sw.toString();
    }

    @Override
    public IASTCprogram normalize(IASTprogram program) throws CompilationException {
        INormalizationFactoryTME7 nf = new NormalizationFactoryTME7();
        NormalizerTME7 normalizer = new NormalizerTME7(nf);
        IASTCprogram newprogram = normalizer.transform(program);
        return newprogram;
    }

    @Override
    public Void visit(IASTCglobalCostartTME7 iast, Context context) throws CompilationException {
        emit("{ \n");
        IASTexpression[] arguments = iast.getArguments();
        IASTvariable[] tmps = new IASTvariable[arguments.length];
        for ( int i=0 ; i<arguments.length ; i++ ) {
            IASTvariable tmp = context.newTemporaryVariable();
            emit("  ILP_Object " + tmp.getMangledName() + "; \n");
            tmps[i] = tmp;
        }
        for ( int i=0 ; i<arguments.length ; i++ ) {
            IASTexpression expression = arguments[i];
            IASTvariable tmp = tmps[i];
            Context c = context.redirect(new AssignDestination(tmp));
            expression.accept(this, c);
        }
        emit(context.destination.compile());
        emit("ILP_costart(");
        emit("(void(*)())ilp__" + ((IASTCglobalVariable)iast.getFunction()).getMangledName());
        emit(", ");
        emit(arguments.length);
        for ( int i=0 ; i<arguments.length ; i++ ) {
            IASTvariable tmp = tmps[i];
            emit(", ");
            emit(tmp.getMangledName());
        }
        emit(");\n}\n");
        return null;

    }

    @Override
    public Void visit(IASTcostartTME7 iast, Context context) throws CompilationException {
        if(iast instanceof IASTCglobalCostartTME7){
            return visit((IASTCglobalCostartTME7)iast, context);
        }
        throw new CompilationException("should not occur");
    }
}
