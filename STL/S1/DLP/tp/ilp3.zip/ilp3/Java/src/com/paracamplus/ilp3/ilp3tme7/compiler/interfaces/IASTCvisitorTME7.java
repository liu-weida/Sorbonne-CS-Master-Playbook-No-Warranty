package com.paracamplus.ilp3.ilp3tme7.compiler.interfaces;


import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTvisitorTME7;

public interface IASTCvisitorTME7<Result, Data, Anomaly extends Throwable>
        extends com.paracamplus.ilp3.compiler.interfaces.IASTCvisitor<Result, Data, Anomaly>,
        IASTvisitorTME7<Result, Data, Anomaly> {
    Result visit(IASTCglobalCostartTME7 iast, Data data) throws Anomaly;
}
