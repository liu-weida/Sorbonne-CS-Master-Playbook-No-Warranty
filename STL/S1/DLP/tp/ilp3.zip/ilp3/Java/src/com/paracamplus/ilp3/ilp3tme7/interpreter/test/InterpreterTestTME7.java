package com.paracamplus.ilp3.ilp3tme7.interpreter.test;

import java.io.File;
import java.io.StringWriter;
import java.util.Collection;

import com.paracamplus.ilp3.ilp3tme7.ast.ASTfactoryTME7;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTfactoryTME7;
import com.paracamplus.ilp3.ilp3tme7.interpreter.GlobalVariableStuffTME7;
import com.paracamplus.ilp3.ilp3tme7.interpreter.InterpreterTME7;
import com.paracamplus.ilp3.ilp3tme7.parser.ilpml.ILPMLParserTME7;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.paracamplus.ilp1.interpreter.GlobalVariableEnvironment;
import com.paracamplus.ilp1.interpreter.OperatorEnvironment;
import com.paracamplus.ilp1.interpreter.OperatorStuff;
import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.interpreter.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp1.interpreter.test.InterpreterRunner;
import com.paracamplus.ilp1.parser.xml.IXMLParser;
//import com.paracamplus.ilp3.ast.ASTfactory;
//import com.paracamplus.ilp3.interfaces.IASTfactory;
//import com.paracamplus.ilp3.interpreter.GlobalVariableStuff;
//import com.paracamplus.ilp3.interpreter.Interpreter;
//import com.paracamplus.ilp3.parser.ilpml.ILPMLParser;
import com.paracamplus.ilp3.parser.xml.XMLParser;

@RunWith(Parameterized.class)
public class InterpreterTestTME7 extends com.paracamplus.ilp3.interpreter.test.InterpreterTest {

    protected static String[] samplesDirName = {"SamplesTME7"};
    protected static String grammarFile = "XMLGrammars/grammar3.rng";

    public InterpreterTestTME7(final File file) {
        super(file);
    }

    public void configureRunner(InterpreterRunner run) throws EvaluationException {
        // configuration du parseur
        IASTfactoryTME7 factory = new ASTfactoryTME7();
        IXMLParser xmlparser = new XMLParser(factory);
        xmlparser.setGrammar(new File(grammarFile));
        run.setXMLParser(xmlparser);
        run.setILPMLParser(new ILPMLParserTME7(factory));

        // configuration de l'interprète
        StringWriter stdout = new StringWriter();
        run.setStdout(stdout);
        IGlobalVariableEnvironment gve = new GlobalVariableEnvironment();
        GlobalVariableStuffTME7.fillGlobalVariables(gve, stdout);
        IOperatorEnvironment oe = new OperatorEnvironment();
        OperatorStuff.fillUnaryOperators(oe);
        OperatorStuff.fillBinaryOperators(oe);
        InterpreterTME7 interpreter = new InterpreterTME7(gve, oe);
        run.setInterpreter(interpreter);
    }

    @Parameters(name = "{0}")
    public static Collection<File[]> data() throws Exception {
        return InterpreterRunner.getFileList(samplesDirName, pattern);
    }

}
