package com.paracamplus.ilp3.ilp3tme7.compiler;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.interfaces.IASTCglobalVariable;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp3.ilp3tme7.compiler.interfaces.IASTCglobalCostartTME7;
import com.paracamplus.ilp3.ilp3tme7.compiler.interfaces.IASTCvisitorTME7;
import com.paracamplus.ilp3.ilp3tme7.interfaces.IASTcostartTME7;

import java.util.Set;

public class GlobalVariableCollectorTME7 extends com.paracamplus.ilp3.compiler.GlobalVariableCollector
    implements IASTCvisitorTME7<Set<IASTCglobalVariable>,
                Set<IASTCglobalVariable>,
                CompilationException> {
    @Override
    public Set<IASTCglobalVariable> visit(IASTCglobalCostartTME7 iast, Set<IASTCglobalVariable> result) throws CompilationException {
        result = iast.getFunction().accept(this,result);
        for ( IASTexpression arg : iast.getArguments() ) {
            result = arg.accept(this, result);
        }
        return result;
    }

    @Override
    public Set<IASTCglobalVariable> visit(IASTcostartTME7 iast, Set<IASTCglobalVariable> result) throws CompilationException {
        return visit((IASTCglobalCostartTME7)iast, result);
    }
}
