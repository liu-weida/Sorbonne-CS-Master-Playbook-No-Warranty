package com.paracamplus.ilp3.ilp3tme7.interpreter.primitives;

import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.primitive.Primitive;
import com.paracamplus.ilp1.interpreter.primitive.UnaryPrimitive;
import com.paracamplus.ilp3.ilp3tme7.interpreter.CoroutineInstance;


public class Yield extends Primitive {

    public Yield() {
        super("yield");
    }



    @Override
    public Object apply() throws EvaluationException {

        CoroutineInstance coroutineInstance = (CoroutineInstance) Thread.currentThread();

        coroutineInstance.yieldCoroutine();

        return null;
    }

    @Override
    public int getArity() {
        return 0;
    }
}

