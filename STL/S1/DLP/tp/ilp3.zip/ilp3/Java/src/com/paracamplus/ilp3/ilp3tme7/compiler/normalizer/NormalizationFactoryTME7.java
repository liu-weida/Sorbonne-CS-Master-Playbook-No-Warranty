package com.paracamplus.ilp3.ilp3tme7.compiler.normalizer;

import com.paracamplus.ilp1.compiler.interfaces.IASTCglobalVariable;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp3.ilp3tme7.compiler.ast.ASTCglobalCostartTME7;

public class NormalizationFactoryTME7 extends com.paracamplus.ilp3.compiler.normalizer.NormalizationFactory implements INormalizationFactoryTME7 {
    @Override
    public IASTexpression newCostart(IASTCglobalVariable coroutine, IASTexpression[] arguments) {
        return new ASTCglobalCostartTME7(coroutine, arguments);
    }
}
