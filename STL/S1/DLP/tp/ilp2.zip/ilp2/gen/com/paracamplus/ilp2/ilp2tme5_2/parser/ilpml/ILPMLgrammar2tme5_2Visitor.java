// Generated from /home/weida/git/ilp2/Java/src/com/paracamplus/ilp2/ilp2tme5_2/parser/ilpml/ILPMLgrammar2tme5_2.g4 by ANTLR 4.13.1
package com.paracamplus.ilp2.ilp2tme5_2.parser.ilpml;

    package antlr4;

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link ILPMLgrammar2tme5_2Parser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface ILPMLgrammar2tme5_2Visitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link ILPMLgrammar2tme5_2Parser#prog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProg(ILPMLgrammar2tme5_2Parser.ProgContext ctx);
	/**
	 * Visit a parse tree produced by {@link ILPMLgrammar2tme5_2Parser#globalFunDef}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGlobalFunDef(ILPMLgrammar2tme5_2Parser.GlobalFunDefContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Binding}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinding(ILPMLgrammar2tme5_2Parser.BindingContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Loop}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLoop(ILPMLgrammar2tme5_2Parser.LoopContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Variable}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariable(ILPMLgrammar2tme5_2Parser.VariableContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Alternative}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlternative(ILPMLgrammar2tme5_2Parser.AlternativeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Invocation}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInvocation(ILPMLgrammar2tme5_2Parser.InvocationContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ConstFloat}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstFloat(ILPMLgrammar2tme5_2Parser.ConstFloatContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Break}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBreak(ILPMLgrammar2tme5_2Parser.BreakContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Sequence}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSequence(ILPMLgrammar2tme5_2Parser.SequenceContext ctx);
	/**
	 * Visit a parse tree produced by the {@code VariableAssign}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariableAssign(ILPMLgrammar2tme5_2Parser.VariableAssignContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ConstFalse}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstFalse(ILPMLgrammar2tme5_2Parser.ConstFalseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Continue}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContinue(ILPMLgrammar2tme5_2Parser.ContinueContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Unary}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnary(ILPMLgrammar2tme5_2Parser.UnaryContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ConstTrue}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstTrue(ILPMLgrammar2tme5_2Parser.ConstTrueContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ConstInteger}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstInteger(ILPMLgrammar2tme5_2Parser.ConstIntegerContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ConstString}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstString(ILPMLgrammar2tme5_2Parser.ConstStringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Binary}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinary(ILPMLgrammar2tme5_2Parser.BinaryContext ctx);
}