// Generated from /home/weida/git/ilp2/Java/src/com/paracamplus/ilp2/ilp2tme5_2/parser/ilpml/ILPMLgrammar2tme5_2.g4 by ANTLR 4.13.1
package com.paracamplus.ilp2.ilp2tme5_2.parser.ilpml;

    package antlr4;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link ILPMLgrammar2tme5_2Parser}.
 */
public interface ILPMLgrammar2tme5_2Listener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link ILPMLgrammar2tme5_2Parser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(ILPMLgrammar2tme5_2Parser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link ILPMLgrammar2tme5_2Parser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(ILPMLgrammar2tme5_2Parser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link ILPMLgrammar2tme5_2Parser#globalFunDef}.
	 * @param ctx the parse tree
	 */
	void enterGlobalFunDef(ILPMLgrammar2tme5_2Parser.GlobalFunDefContext ctx);
	/**
	 * Exit a parse tree produced by {@link ILPMLgrammar2tme5_2Parser#globalFunDef}.
	 * @param ctx the parse tree
	 */
	void exitGlobalFunDef(ILPMLgrammar2tme5_2Parser.GlobalFunDefContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Binding}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBinding(ILPMLgrammar2tme5_2Parser.BindingContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Binding}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBinding(ILPMLgrammar2tme5_2Parser.BindingContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Loop}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterLoop(ILPMLgrammar2tme5_2Parser.LoopContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Loop}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitLoop(ILPMLgrammar2tme5_2Parser.LoopContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Variable}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterVariable(ILPMLgrammar2tme5_2Parser.VariableContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Variable}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitVariable(ILPMLgrammar2tme5_2Parser.VariableContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Alternative}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterAlternative(ILPMLgrammar2tme5_2Parser.AlternativeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Alternative}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitAlternative(ILPMLgrammar2tme5_2Parser.AlternativeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Invocation}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterInvocation(ILPMLgrammar2tme5_2Parser.InvocationContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Invocation}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitInvocation(ILPMLgrammar2tme5_2Parser.InvocationContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ConstFloat}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConstFloat(ILPMLgrammar2tme5_2Parser.ConstFloatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ConstFloat}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConstFloat(ILPMLgrammar2tme5_2Parser.ConstFloatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Break}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBreak(ILPMLgrammar2tme5_2Parser.BreakContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Break}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBreak(ILPMLgrammar2tme5_2Parser.BreakContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Sequence}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterSequence(ILPMLgrammar2tme5_2Parser.SequenceContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Sequence}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitSequence(ILPMLgrammar2tme5_2Parser.SequenceContext ctx);
	/**
	 * Enter a parse tree produced by the {@code VariableAssign}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterVariableAssign(ILPMLgrammar2tme5_2Parser.VariableAssignContext ctx);
	/**
	 * Exit a parse tree produced by the {@code VariableAssign}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitVariableAssign(ILPMLgrammar2tme5_2Parser.VariableAssignContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ConstFalse}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConstFalse(ILPMLgrammar2tme5_2Parser.ConstFalseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ConstFalse}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConstFalse(ILPMLgrammar2tme5_2Parser.ConstFalseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Continue}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterContinue(ILPMLgrammar2tme5_2Parser.ContinueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Continue}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitContinue(ILPMLgrammar2tme5_2Parser.ContinueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Unary}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterUnary(ILPMLgrammar2tme5_2Parser.UnaryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Unary}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitUnary(ILPMLgrammar2tme5_2Parser.UnaryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ConstTrue}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConstTrue(ILPMLgrammar2tme5_2Parser.ConstTrueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ConstTrue}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConstTrue(ILPMLgrammar2tme5_2Parser.ConstTrueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ConstInteger}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConstInteger(ILPMLgrammar2tme5_2Parser.ConstIntegerContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ConstInteger}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConstInteger(ILPMLgrammar2tme5_2Parser.ConstIntegerContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ConstString}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConstString(ILPMLgrammar2tme5_2Parser.ConstStringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ConstString}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConstString(ILPMLgrammar2tme5_2Parser.ConstStringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Binary}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBinary(ILPMLgrammar2tme5_2Parser.BinaryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Binary}
	 * labeled alternative in {@link ILPMLgrammar2tme5_2Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBinary(ILPMLgrammar2tme5_2Parser.BinaryContext ctx);
}