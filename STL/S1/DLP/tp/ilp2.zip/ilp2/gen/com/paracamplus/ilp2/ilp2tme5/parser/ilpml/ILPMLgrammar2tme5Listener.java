// Generated from /home/weida/git/ilp2/Java/src/com/paracamplus/ilp2/ilp2tme5/parser/ilpml/ILPMLgrammar2tme5_2.g4 by ANTLR 4.13.1
package com.paracamplus.ilp2.ilp2tme5.parser.ilpml;

    package antlr4;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link ILPMLgrammar2tme5Parser}.
 */
public interface ILPMLgrammar2tme5Listener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link ILPMLgrammar2tme5Parser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(ILPMLgrammar2tme5Parser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link ILPMLgrammar2tme5Parser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(ILPMLgrammar2tme5Parser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link ILPMLgrammar2tme5Parser#globalFunDef}.
	 * @param ctx the parse tree
	 */
	void enterGlobalFunDef(ILPMLgrammar2tme5Parser.GlobalFunDefContext ctx);
	/**
	 * Exit a parse tree produced by {@link ILPMLgrammar2tme5Parser#globalFunDef}.
	 * @param ctx the parse tree
	 */
	void exitGlobalFunDef(ILPMLgrammar2tme5Parser.GlobalFunDefContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Binding}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBinding(ILPMLgrammar2tme5Parser.BindingContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Binding}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBinding(ILPMLgrammar2tme5Parser.BindingContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Loop}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterLoop(ILPMLgrammar2tme5Parser.LoopContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Loop}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitLoop(ILPMLgrammar2tme5Parser.LoopContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Variable}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterVariable(ILPMLgrammar2tme5Parser.VariableContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Variable}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitVariable(ILPMLgrammar2tme5Parser.VariableContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Alternative}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterAlternative(ILPMLgrammar2tme5Parser.AlternativeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Alternative}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitAlternative(ILPMLgrammar2tme5Parser.AlternativeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Invocation}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterInvocation(ILPMLgrammar2tme5Parser.InvocationContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Invocation}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitInvocation(ILPMLgrammar2tme5Parser.InvocationContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ConstFloat}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConstFloat(ILPMLgrammar2tme5Parser.ConstFloatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ConstFloat}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConstFloat(ILPMLgrammar2tme5Parser.ConstFloatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Break}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBreak(ILPMLgrammar2tme5Parser.BreakContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Break}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBreak(ILPMLgrammar2tme5Parser.BreakContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Sequence}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterSequence(ILPMLgrammar2tme5Parser.SequenceContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Sequence}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitSequence(ILPMLgrammar2tme5Parser.SequenceContext ctx);
	/**
	 * Enter a parse tree produced by the {@code VariableAssign}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterVariableAssign(ILPMLgrammar2tme5Parser.VariableAssignContext ctx);
	/**
	 * Exit a parse tree produced by the {@code VariableAssign}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitVariableAssign(ILPMLgrammar2tme5Parser.VariableAssignContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ConstFalse}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConstFalse(ILPMLgrammar2tme5Parser.ConstFalseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ConstFalse}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConstFalse(ILPMLgrammar2tme5Parser.ConstFalseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Continue}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterContinue(ILPMLgrammar2tme5Parser.ContinueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Continue}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitContinue(ILPMLgrammar2tme5Parser.ContinueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Unary}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterUnary(ILPMLgrammar2tme5Parser.UnaryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Unary}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitUnary(ILPMLgrammar2tme5Parser.UnaryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ConstTrue}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConstTrue(ILPMLgrammar2tme5Parser.ConstTrueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ConstTrue}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConstTrue(ILPMLgrammar2tme5Parser.ConstTrueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ConstInteger}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConstInteger(ILPMLgrammar2tme5Parser.ConstIntegerContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ConstInteger}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConstInteger(ILPMLgrammar2tme5Parser.ConstIntegerContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ConstString}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConstString(ILPMLgrammar2tme5Parser.ConstStringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ConstString}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConstString(ILPMLgrammar2tme5Parser.ConstStringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Binary}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBinary(ILPMLgrammar2tme5Parser.BinaryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Binary}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBinary(ILPMLgrammar2tme5Parser.BinaryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Unless}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void enterUnless(ILPMLgrammar2tme5Parser.UnlessContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Unless}
	 * labeled alternative in {@link ILPMLgrammar2tme5Parser#expr}.
	 * @param ctx the parse tree
	 */
	void exitUnless(ILPMLgrammar2tme5Parser.UnlessContext ctx);
}