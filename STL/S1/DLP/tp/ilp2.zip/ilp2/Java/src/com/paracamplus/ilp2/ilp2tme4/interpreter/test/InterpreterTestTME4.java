package com.paracamplus.ilp2.ilp2tme4.interpreter.test;

import java.io.File;
import java.io.StringWriter;
import java.util.Collection;

import com.paracamplus.ilp2.ilp2tme4.ast.ASTfactoryTME4;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTfactoryTME4;
import com.paracamplus.ilp2.ilp2tme4.interpreter.InterpreterTME4;
import com.paracamplus.ilp2.ilp2tme4.parser.ilpml.ILPMLParserTME4;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.paracamplus.ilp1.interpreter.GlobalVariableEnvironment;
import com.paracamplus.ilp1.interpreter.GlobalVariableStuff;
import com.paracamplus.ilp1.interpreter.OperatorEnvironment;
import com.paracamplus.ilp1.interpreter.OperatorStuff;
import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.interpreter.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp1.interpreter.test.InterpreterRunner;
import com.paracamplus.ilp1.parser.xml.IXMLParser;
import com.paracamplus.ilp2.parser.xml.XMLParser;

@RunWith(Parameterized.class)
public class InterpreterTestTME4 extends com.paracamplus.ilp1.interpreter.test.InterpreterTest {

    protected static String[] samplesDirName = { "SamplesTME4" };

    public InterpreterTestTME4(final File file) {
        super(file);
    }

    public void configureRunner(InterpreterRunner run) throws EvaluationException {
        // configuration du parseur
        IASTfactoryTME4 factory = new ASTfactoryTME4();
        IXMLParser xmlparser = new XMLParser(factory);
        xmlparser.setGrammar(new File(XMLgrammarFile));
        run.setXMLParser(xmlparser);
        run.setILPMLParser(new ILPMLParserTME4(factory));

        // configuration de l'interprète
        StringWriter stdout = new StringWriter();
        run.setStdout(stdout);
        IGlobalVariableEnvironment gve = new GlobalVariableEnvironment();
        GlobalVariableStuff.fillGlobalVariables(gve, stdout);
        IOperatorEnvironment oe = new OperatorEnvironment();
        OperatorStuff.fillUnaryOperators(oe);
        OperatorStuff.fillBinaryOperators(oe);
        InterpreterTME4 interpreter = new InterpreterTME4(gve, oe);
        run.setInterpreter(interpreter);
    }

    @Parameters(name = "{0}")
    public static Collection<File[]> data() throws Exception {
        return InterpreterRunner.getFileList(samplesDirName, pattern);
    }

}
