package com.paracamplus.ilp2.ilp2tme5_2.interfaces;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.interfaces.IASTfactory;

public interface IASTfactoryTME5_2 extends IASTfactory {

    IASTexpression newBreak(String label);
    IASTexpression newContinue(String label);
    IASTexpression newLoop(String label, IASTexpression condition, IASTexpression body);

}//confirme
