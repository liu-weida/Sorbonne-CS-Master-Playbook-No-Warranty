package com.paracamplus.ilp2.ilp2tme4.compiler.normalization;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.normalizer.INormalizationEnvironment;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.compiler.normalizer.Normalizer;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTunlessTME4;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTvisitorTME4;


public class NormalizerTME4 extends Normalizer implements IASTvisitorTME4<IASTexpression, INormalizationEnvironment, CompilationException>{

	INormalizationFactoryTME4 factory;
	public NormalizerTME4(INormalizationFactoryTME4 factory) {
		super(factory);
		this.factory = factory;
	}


	@Override
	public IASTexpression visit(IASTunlessTME4 iast, INormalizationEnvironment data) throws CompilationException {
		return  factory.newUnless(
				iast.getBody().accept(this, data).accept(this, data),
				iast.getCondition().accept(this, data)
				);
	}
	

}
