package com.paracamplus.ilp2.ilp2tme5_2.interpreter;

import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;

public class BreakExceptionTME5_2 extends EvaluationException {


    public BreakExceptionTME5_2(String msg) {
        super(msg);
    }
}
