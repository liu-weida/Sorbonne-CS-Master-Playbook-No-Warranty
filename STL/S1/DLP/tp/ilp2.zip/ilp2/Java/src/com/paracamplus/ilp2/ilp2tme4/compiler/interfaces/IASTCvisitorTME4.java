package com.paracamplus.ilp2.ilp2tme4.compiler.interfaces;

import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTunlessTME4;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTvisitorTME4;

public interface IASTCvisitorTME4<Result, Data, Anomaly extends Throwable> extends IASTvisitorTME4<Result, Data, Anomaly>{
	Result visit(IASTunlessTME4 iast, Data data) throws Anomaly;
}
