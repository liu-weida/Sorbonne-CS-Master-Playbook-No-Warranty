package com.paracamplus.ilp2.ilp2tme5_2.ast;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.ast.ASTfactory;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTfactoryTME5_2;

public class ASTfactoryTME5_2 extends ASTfactory implements IASTfactoryTME5_2 {
    @Override
    public IASTexpression newBreak(String label) {
        return new ASTbreakTME5_2(label);
    }

    @Override
    public IASTexpression newContinue(String label) {
        return new ASTcontinueTME5_2(label);
    }

    @Override
    public IASTexpression newLoop(String label, IASTexpression condition, IASTexpression body) {
        return new ASTloopTME5_2(label,condition,body);
    }
}
