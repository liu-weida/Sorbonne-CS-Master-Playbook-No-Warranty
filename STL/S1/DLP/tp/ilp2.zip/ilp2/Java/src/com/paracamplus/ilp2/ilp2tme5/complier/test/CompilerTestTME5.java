package com.paracamplus.ilp2.ilp2tme5.complier.test;

import java.io.File;
import java.util.Collection;

import org.junit.runners.Parameterized.Parameters;

import com.paracamplus.ilp1.compiler.*;
import com.paracamplus.ilp1.compiler.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.compiler.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp1.compiler.optimizer.IdentityOptimizer;
import com.paracamplus.ilp1.compiler.test.CompilerRunner;
import com.paracamplus.ilp1.parser.xml.IXMLParser;
import com.paracamplus.ilp2.ilp2tme5.ast.ASTfactoryTME5;
import com.paracamplus.ilp2.ilp2tme5.complier.CompilerTME5;
import com.paracamplus.ilp2.ilp2tme5.parser.ilpml.ILPMLParserTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTfactoryTME5;
import com.paracamplus.ilp2.parser.xml.XMLParser;

public class CompilerTestTME5 extends com.paracamplus.ilp2.compiler.test.CompilerTest{

    protected static String[] samplesDirName = { "SamplesTME5" };
	
    public CompilerTestTME5(final File file) {
    	super(file);
    }
    
    
    @Override
    public void configureRunner(CompilerRunner run) throws CompilationException {
    	// configuration du parseur
        IASTfactoryTME5 factory = new ASTfactoryTME5();
        IXMLParser xMLParser = new XMLParser(factory);
        xMLParser.setGrammar(new File(XMLgrammarFile));
        run.setXMLParser(xMLParser);
        run.setILPMLParser(new ILPMLParserTME5(factory));

        // configuration du compilateur
        IOperatorEnvironment ioe = new OperatorEnvironment();
        OperatorStuff.fillUnaryOperators(ioe);
        OperatorStuff.fillBinaryOperators(ioe);
        IGlobalVariableEnvironment gve = new GlobalVariableEnvironment();
        GlobalVariableStuff.fillGlobalVariables(gve);
        CompilerTME5 compiler = new CompilerTME5(ioe, gve);
        compiler.setOptimizer(new IdentityOptimizer());
        run.setCompiler(compiler);

        // configuration du script de compilation et exécution
        run.setRuntimeScript(scriptCommand);    	
    }
    
    @Parameters(name = "{0}")
    public static Collection<File[]> data() throws Exception {
    	return CompilerRunner.getFileList(samplesDirName, pattern);
    }    	
    
}
