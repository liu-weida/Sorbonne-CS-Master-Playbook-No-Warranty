package com.paracamplus.ilp2.ilp2tme5_2.interfaces;

import com.paracamplus.ilp1.annotation.OrNull;
import com.paracamplus.ilp1.interfaces.IASTexpression;

public interface IASTcontinueTME5_2 extends IASTexpression {

    @OrNull
    String getLabel();

}//confirme
