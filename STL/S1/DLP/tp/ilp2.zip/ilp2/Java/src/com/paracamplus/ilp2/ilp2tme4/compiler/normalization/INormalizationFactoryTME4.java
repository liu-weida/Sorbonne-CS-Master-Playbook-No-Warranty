package com.paracamplus.ilp2.ilp2tme4.compiler.normalization;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.compiler.normalizer.INormalizationFactory;

public interface INormalizationFactoryTME4 extends INormalizationFactory{
	
	IASTexpression newUnless(IASTexpression body, IASTexpression condition);
	
}
