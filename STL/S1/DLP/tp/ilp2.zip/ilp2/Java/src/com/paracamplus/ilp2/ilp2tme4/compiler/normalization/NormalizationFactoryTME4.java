package com.paracamplus.ilp2.ilp2tme4.compiler.normalization;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.compiler.normalizer.NormalizationFactory;
import com.paracamplus.ilp2.ilp2tme4.ast.ASTunlessTME4;

public class NormalizationFactoryTME4 extends NormalizationFactory implements INormalizationFactoryTME4{

	@Override
	public IASTexpression newUnless(IASTexpression body, IASTexpression condition) {
		return new ASTunlessTME4(body,condition);
	}
	
}
