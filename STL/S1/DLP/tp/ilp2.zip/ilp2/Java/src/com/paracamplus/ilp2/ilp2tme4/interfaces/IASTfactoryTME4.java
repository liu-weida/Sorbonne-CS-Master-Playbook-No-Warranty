package com.paracamplus.ilp2.ilp2tme4.interfaces;

import com.paracamplus.ilp1.interfaces.IASTexpression;

public interface IASTfactoryTME4 extends com.paracamplus.ilp2.interfaces.IASTfactory {

	IASTunlessTME4 newUnless(
			IASTexpression body,
			IASTexpression condition
            );
	
}
