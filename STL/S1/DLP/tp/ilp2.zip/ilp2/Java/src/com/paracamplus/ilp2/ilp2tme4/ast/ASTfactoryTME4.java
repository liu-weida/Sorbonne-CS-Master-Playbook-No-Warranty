package com.paracamplus.ilp2.ilp2tme4.ast;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTunlessTME4;

public class ASTfactoryTME4 extends com.paracamplus.ilp2.ast.ASTfactory implements com.paracamplus.ilp2.ilp2tme4.interfaces.IASTfactoryTME4{

	@Override
	public IASTunlessTME4 newUnless(IASTexpression body, IASTexpression condition) {
		// TODO Auto-generated method stub
		return new ASTunlessTME4(body,condition);
	}




}
