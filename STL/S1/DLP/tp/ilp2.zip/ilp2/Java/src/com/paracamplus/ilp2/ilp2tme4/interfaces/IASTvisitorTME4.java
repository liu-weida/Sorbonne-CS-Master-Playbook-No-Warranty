package com.paracamplus.ilp2.ilp2tme4.interfaces;

import com.paracamplus.ilp2.interfaces.IASTvisitor;

public interface IASTvisitorTME4<Result, Data, Anomaly extends Throwable> extends IASTvisitor<Result, Data, Anomaly>{
	Result visit(IASTunlessTME4 iast, Data data) throws Anomaly;
}
