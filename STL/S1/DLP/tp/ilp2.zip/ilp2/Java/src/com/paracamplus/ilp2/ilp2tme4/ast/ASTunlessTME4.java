package com.paracamplus.ilp2.ilp2tme4.ast;

import com.paracamplus.ilp1.ast.ASTexpression;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTunlessTME4;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTvisitableTME4;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTvisitorTME4;


public class ASTunlessTME4 extends ASTexpression implements IASTunlessTME4,IASTvisitableTME4{
	
	
	 public ASTunlessTME4(IASTexpression condition, IASTexpression body) {
	        this.condition = condition;
	        this.body = body;
	    }
	    private final IASTexpression condition;
	    private final IASTexpression body;
	

	@Override
	public IASTexpression getCondition() {
		// TODO Auto-generated method stub
		return this.condition;
	}

	@Override
	public IASTexpression getBody() {
		// TODO Auto-generated method stub
		return this.body;
	}

	@Override
	public <Result, Data, Anomaly extends Throwable> Result accept(
			com.paracamplus.ilp1.interfaces.IASTvisitor<Result, Data, Anomaly> visitor, Data data) throws Anomaly {
		// TODO Auto-generated method stub
		return ((IASTvisitorTME4 <Result, Data, Anomaly>) visitor).visit(this, data);
	}






}
