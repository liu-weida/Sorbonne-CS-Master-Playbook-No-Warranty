package com.paracamplus.ilp2.ilp2tme4.compiler;

import com.paracamplus.ilp1.ast.ASTboolean;
import com.paracamplus.ilp1.compiler.AssignDestination;
import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.NoDestination;
import com.paracamplus.ilp1.compiler.interfaces.IASTCglobalVariable;
import com.paracamplus.ilp1.compiler.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.compiler.interfaces.IOperatorEnvironment;

import com.paracamplus.ilp1.interfaces.IASTvariable;
import com.paracamplus.ilp2.compiler.interfaces.IASTCprogram;


import com.paracamplus.ilp2.ilp2tme4.compiler.interfaces.IASTCvisitorTME4;
import com.paracamplus.ilp2.ilp2tme4.compiler.normalization.INormalizationFactoryTME4;
import com.paracamplus.ilp2.ilp2tme4.compiler.normalization.NormalizationFactoryTME4;
import com.paracamplus.ilp2.ilp2tme4.compiler.normalization.NormalizerTME4;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTunlessTME4;
import com.paracamplus.ilp2.interfaces.IASTprogram;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Set;

public class CompilerTME4 extends com.paracamplus.ilp2.compiler.Compiler
		implements IASTCvisitorTME4<Void, CompilerTME4.Context, CompilationException> {

	public CompilerTME4(IOperatorEnvironment ioe, IGlobalVariableEnvironment igve) {
		super(ioe, igve);
	}

	public IASTCprogram normalize(IASTprogram program)
			throws CompilationException {
		INormalizationFactoryTME4 nf = new NormalizationFactoryTME4();
		NormalizerTME4 normalizer = new NormalizerTME4(nf);
		IASTCprogram newprogram = normalizer.transform(program);
		return newprogram;
	}

	@Override
	public String compile(com.paracamplus.ilp1.interfaces.IASTprogram program) throws CompilationException {
		return compile((IASTprogram)program);
	}

	public String compile(IASTprogram program)
			throws CompilationException {

		IASTCprogram newprogram = normalize(program);
		newprogram = ((IASTCprogram) optimizer.transform(newprogram));

		GlobalVariableCollectorTME4 gvc = new GlobalVariableCollectorTME4();
		Set<IASTCglobalVariable> gvs = gvc.analyze(newprogram);
		newprogram.setGlobalVariables(gvs);

		FreeVariableCollectorTME4 fvc = new FreeVariableCollectorTME4(newprogram);
		newprogram = (fvc.analyze());

		Context context = new Context(NoDestination.NO_DESTINATION);
		StringWriter sw = new StringWriter();
		try {
			out = new BufferedWriter(sw);
			visit(newprogram, context);
			out.flush();
		} catch (IOException exc) {
			throw new CompilationException(exc);
		}
		return sw.toString();
	}

	@Override
	public Void visit(IASTunlessTME4 iast, Context context) throws CompilationException {
		IASTvariable tmp1 = context.newTemporaryVariable();
		emit("{ \n");
		emit("  ILP_Object " + tmp1.getMangledName() + "; \n");
		Context c = context.redirect(new AssignDestination(tmp1));
		iast.getCondition().accept(this, c);
		emit("  if ( ILP_isEquivalentToTrue(");
		emit(tmp1.getMangledName());
		emit(" ) ) {\n");
		new ASTboolean("false").accept(this, context);
		emit("\n  } else {\n");
		iast.getBody().accept(this, context);
		emit("\n  }\n}\n");
		return null;
	}

}
