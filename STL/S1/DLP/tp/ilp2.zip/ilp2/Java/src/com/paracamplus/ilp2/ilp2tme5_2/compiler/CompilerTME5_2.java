package com.paracamplus.ilp2.ilp2tme5_2.compiler;

import com.paracamplus.ilp1.compiler.AssignDestination;
import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.Compiler;
import com.paracamplus.ilp1.compiler.NoDestination;
import com.paracamplus.ilp1.compiler.VoidDestination;
import com.paracamplus.ilp1.compiler.interfaces.IASTCglobalVariable;
import com.paracamplus.ilp1.compiler.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.compiler.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp1.interfaces.IASTvariable;
import com.paracamplus.ilp2.compiler.interfaces.IASTCprogram;
import com.paracamplus.ilp2.ilp2tme5_2.compiler.FreeVariableCollectorTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.compiler.GlobalVariableCollectorTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.compiler.interfaces.IASTCvisitorTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.compiler.normalizber.INormalizationFactoryTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.compiler.normalizber.NormalizationFactoryTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.compiler.normalizber.NormalizerTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTbreakTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTcontinueTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTloopTME5_2;
import com.paracamplus.ilp2.interfaces.IASTprogram;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Set;

public class CompilerTME5_2 extends com.paracamplus.ilp2.compiler.Compiler
        implements IASTCvisitorTME5_2<Void, CompilerTME5_2.Context, CompilationException> {

    protected int nb = 0;

    public CompilerTME5_2(IOperatorEnvironment ioe, IGlobalVariableEnvironment igve) {
        super(ioe, igve);
    }

    public IASTCprogram normalize(IASTprogram program)
            throws CompilationException {
        INormalizationFactoryTME5_2 nf = new NormalizationFactoryTME5_2();
        NormalizerTME5_2 normalizer = new NormalizerTME5_2(nf);
        IASTCprogram newprogram = normalizer.transform(program);
        return newprogram;
    }

    @Override
    public String compile(com.paracamplus.ilp1.interfaces.IASTprogram program) throws CompilationException {
        return compile((IASTprogram)program);
    }

    public String compile(IASTprogram program)
            throws CompilationException {

        IASTCprogram newprogram = normalize(program);
        newprogram = ((IASTCprogram) optimizer.transform(newprogram));

        GlobalVariableCollectorTME5_2 gvc = new GlobalVariableCollectorTME5_2();
        Set<IASTCglobalVariable> gvs = gvc.analyze(newprogram);
        newprogram.setGlobalVariables(gvs);

        FreeVariableCollectorTME5_2 fvc = new FreeVariableCollectorTME5_2(newprogram);
        newprogram = (fvc.analyze());

        Context context = new Context(NoDestination.NO_DESTINATION);
        StringWriter sw = new StringWriter();
        try {
            out = new BufferedWriter(sw);
            visit(newprogram, context);
            out.flush();
        } catch (IOException exc) {
            throw new CompilationException(exc);
        }
        return sw.toString();
    }

    @Override
    public Void visit(IASTbreakTME5_2 iast, Context context) throws CompilationException {
        if(nb < 1){
            throw new CompilationException("Break is not in the loop");
        }else {
            if(iast.getLabel().isBlank()) {
                emit("break;");
            }else{
                emit("goto " + iast.getLabel() +"break;");
            }
        }
        return null;
    }

    @Override
    public Void visit(IASTcontinueTME5_2 iast, Context context) throws CompilationException {
        if(nb < 1){
            throw new CompilationException("Continue is not in the loop");
        }else {
            if(iast.getLabel().isBlank()){
                emit("continue;");
            }else{
                emit("goto " + iast.getLabel() +";");
            }
        }
        return null;
    }

    @Override
    public Void visit(IASTloopTME5_2 iast, Context context) throws CompilationException {
        emit("while ( 1 ) { \n");
        IASTvariable tmp = context.newTemporaryVariable();
        emit("  ILP_Object " + tmp.getMangledName() + "; \n");

        if (!iast.getLabel().isBlank()) {
            emit(iast.getLabel() + ": \n");
        }

        Context c = context.redirect(new AssignDestination(tmp));
        iast.getCondition().accept(this, c);
        emit("  if ( ILP_isEquivalentToTrue(");
        emit(tmp.getMangledName());
        emit(") ) {\n");
        Context cb = context.redirect(VoidDestination.VOID_DESTINATION);

        nb++;

        iast.getBody().accept(this, cb);
        emit("\n} else { \n");
        emit("    break; \n");
        emit("\n}\n}\n");

        if (!iast.getLabel().isBlank()) {
            emit(iast.getLabel() + "break: \n");
        }

        whatever.accept(this, context);

        nb--;

        return null;
    }
}