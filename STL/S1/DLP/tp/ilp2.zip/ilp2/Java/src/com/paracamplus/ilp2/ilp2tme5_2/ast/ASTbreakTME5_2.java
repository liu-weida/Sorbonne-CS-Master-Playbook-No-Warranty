package com.paracamplus.ilp2.ilp2tme5_2.ast;

import com.paracamplus.ilp1.interfaces.IASTvisitor;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTbreakTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTvisitorTME5_2;

import java.awt.*;

public class ASTbreakTME5_2 implements IASTbreakTME5_2 {

    private String Label;

    public ASTbreakTME5_2(String Label){
        this.Label = Label;
    }

    @Override
    public <Result, Data, Anomaly extends Throwable> Result accept(IASTvisitor<Result, Data, Anomaly> visitor, Data data) throws Anomaly {
        return ((IASTvisitorTME5_2 <Result, Data, Anomaly>)visitor).visit(this,data);
    }
    @Override
    public String getLabel() {
        return Label;
    }





}
