package com.paracamplus.ilp2.ilp2tme5_2.compiler.normalizber;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.normalizer.INormalizationEnvironment;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.compiler.normalizer.INormalizationFactory;
import com.paracamplus.ilp2.compiler.normalizer.Normalizer;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTbreakTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTcontinueTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTloopTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTvisitorTME5_2;

public class NormalizerTME5_2 extends Normalizer implements IASTvisitorTME5_2<IASTexpression, INormalizationEnvironment, CompilationException> {
    public NormalizerTME5_2(INormalizationFactory factory) {
        super(factory);
    }

    @Override
    public IASTexpression visit(IASTbreakTME5_2 iast, INormalizationEnvironment iNormalizationEnvironment) throws CompilationException {
        return ((INormalizationFactoryTME5_2)factory).newBreak(iast.getLabel());
    }

    @Override
    public IASTexpression visit(IASTcontinueTME5_2 iast, INormalizationEnvironment iNormalizationEnvironment) throws CompilationException {
        return ((INormalizationFactoryTME5_2)factory).newContinue(iast.getLabel());
    }

    @Override
    public IASTexpression visit(IASTloopTME5_2 iast, INormalizationEnvironment iNormalizationEnvironment) throws CompilationException {


        IASTexpression condition = iast.getCondition().accept(this,iNormalizationEnvironment);
        IASTexpression body = iast.getBody().accept(this,iNormalizationEnvironment);


        return ((INormalizationFactoryTME5_2)factory).newLoop(iast.getLabel(),condition,body);
    }
}
