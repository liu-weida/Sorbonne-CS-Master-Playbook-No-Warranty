package com.paracamplus.ilp2.ilp2tme5.ast;

import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTbreakTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTcontinueTME5;

public class ASTfactoryTME5 extends com.paracamplus.ilp2.ast.ASTfactory implements com.paracamplus.ilp2.ilp2tme5.interfaces.IASTfactoryTME5{

	
	@Override
	public IASTbreakTME5 newBreak() {
		return new ASTbreakTME5();
	}

	@Override
	public IASTcontinueTME5 newContinue() {
		return new ASTcontinueTME5();
	}

	// NOT COMFIRMÉ
}
