package com.paracamplus.ilp2.ilp2tme5.interpreter;

import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.interpreter.interfaces.ILexicalEnvironment;
import com.paracamplus.ilp1.interpreter.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTbreakTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTcontinueTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTvisitorTME5;
import com.paracamplus.ilp2.interfaces.IASTfunctionDefinition;
import com.paracamplus.ilp2.interfaces.IASTloop;
import com.paracamplus.ilp2.interfaces.IASTprogram;
import com.paracamplus.ilp2.interpreter.Interpreter;

public class InterpreterTME5 extends Interpreter implements IASTvisitorTME5<Object, ILexicalEnvironment, EvaluationException>{

	public InterpreterTME5(IGlobalVariableEnvironment globalVariableEnvironment,
			IOperatorEnvironment operatorEnvironment) {
		super(globalVariableEnvironment, operatorEnvironment);
	}

	private int timesWhile = 0;


	    @Override
	    public Object visit(com.paracamplus.ilp1.interfaces.IASTprogram iast, ILexicalEnvironment lexenv) throws EvaluationException  {
	        return visit((IASTprogram)iast, lexenv);
	    }

	    public Object visit(IASTprogram iast, ILexicalEnvironment lexenv)
	            throws EvaluationException {
	        for ( IASTfunctionDefinition fd : iast.getFunctionDefinitions() ) {
	            Object f = this.visit(fd, lexenv);
	            String v = fd.getName();
	            getGlobalVariableEnvironment().addGlobalVariableValue(v, f);
	        }
	        try {
	            return iast.getBody().accept(this, lexenv);
	        } catch (Exception exc) {
	            return exc;
	        }
	    }

	    @Override
	    public Object visit(IASTloop iast, ILexicalEnvironment lexenv) throws EvaluationException {
	        while ( true ) {
	            Object condition = iast.getCondition().accept(this, lexenv);
	            if ( condition instanceof Boolean ) {
	                Boolean c = (Boolean) condition;
	                if ( ! c ) {
	                    break;
	                }
	            }
	            timesWhile++;
	            try {
	                iast.getBody().accept(this, lexenv);
	            } catch (BreakException e){
	                timesWhile--;
	                break;
	            } catch (ContinueException e){
	                timesWhile--;
	                continue;
	            }
	            timesWhile--;
	        }
	        return Boolean.FALSE;
	    }

	    @Override
	    public Object visit(IASTbreakTME5 iast, ILexicalEnvironment iLexicalEnvironment) throws EvaluationException {
	        if (timesWhile < 1) {
	            throw new EvaluationException("The keyword break is not in a loop");
	        }else {
	            throw new BreakException("break");
	        }

	    }

	    @Override
	    public Object visit(IASTcontinueTME5 iast, ILexicalEnvironment iLexicalEnvironment) throws EvaluationException {
	        if (timesWhile < 1) {
	            throw new EvaluationException("The keyword continue is not in a loop");
	        }else {
	            throw new ContinueException("continue");
	        }

	    }


}
