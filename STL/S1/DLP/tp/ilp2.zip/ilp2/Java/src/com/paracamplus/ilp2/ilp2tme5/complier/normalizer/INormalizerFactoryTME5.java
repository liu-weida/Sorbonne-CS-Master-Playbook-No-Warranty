package com.paracamplus.ilp2.ilp2tme5.complier.normalizer;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.compiler.normalizer.INormalizationFactory;

public interface INormalizerFactoryTME5 extends INormalizationFactory{

	IASTexpression newBreak();
	IASTexpression newContinue();
}

// CONFIRMÉ
