package com.paracamplus.ilp2.ilp2tme4.parser.ilpml;

import com.paracamplus.ilp1.ast.ASTblock;
import com.paracamplus.ilp1.interfaces.*;

import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTfactoryTME4;
import com.paracamplus.ilp2.ilp2tme4.ast.ASTfactoryTME4;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTunlessTME4;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTvisitorTME4;
import com.paracamplus.ilp2.interfaces.IASTassignment;
import com.paracamplus.ilp2.interfaces.IASTfunctionDefinition;
import com.paracamplus.ilp2.interfaces.IASTloop;
import com.paracamplus.ilp2.interfaces.IASTprogram;

public class transformationUnlessTME4 implements IASTvisitorTME4<IASTexpression, Void, Exception> {

    IASTfactoryTME4 factory = new ASTfactoryTME4();

    // getVariable, getSequence, getDescription,getOperator n'a jamais besoin de la fonction accept

    @Override
    public IASTexpression visit(IASTvariable iast, Void data) throws Exception {
        return factory.newVariable(
                iast.getName()
        );
    }

    @Override
    public IASTexpression visit(IASTboolean iast, Void data) throws Exception {
        //return factory.newBooleanConstant(iast.getDescription());
        return factory.newBooleanConstant(
                iast.getValue().toString()
        );
    }

    @Override
    public IASTexpression visit(IASTfloat iast, Void data) throws Exception {
        //return factory.newFloatConstant(iast.getDescription());
        return factory.newFloatConstant(
                iast.getValue().toString()
        );
    }

    @Override
    public IASTexpression visit(IASTinteger iast, Void data) throws Exception {
        //return factory.newIntegerConstant(iast.getDescription());
        return factory.newIntegerConstant(
                iast.getValue().toString()
        );
    }

    @Override
    public IASTexpression visit(IASTstring iast, Void data) throws Exception {
//		return factory.newStringConstant(iast.getDescription());
        return factory.newStringConstant(
                iast.getValue()
        );
    }

    @Override
    public IASTexpression visit(IASTassignment iast, Void data) throws Exception {
        return factory.newAssignment(
                iast.getVariable(),
                iast.getExpression().accept(this, data)
        );
    }

    @Override
    public IASTexpression visit(IASTloop iast, Void data) throws Exception {
        return factory.newLoop(
                iast.getCondition().accept(this, data),
                iast.getBody().accept(this, data)
        );
    }

    @Override
    public IASTexpression visit(IASTalternative iast, Void data) throws Exception {
        return factory.newAlternative(
                iast.getCondition().accept(this, data),
                iast.getConsequence().accept(this, data),
                iast.isTernary() ? iast.getAlternant().accept(this, data) : null
        );
    }

    @Override
    public IASTexpression visit(IASTbinaryOperation iast, Void data) throws Exception {
        return factory.newBinaryOperation(
                iast.getOperator(),
                iast.getLeftOperand().accept(this, data),
                iast.getRightOperand().accept(this, data)
        );
    }


    public IASTprogram visit(IASTprogram iast, Void data) throws Exception {

        int length = iast.getFunctionDefinitions().length;
        IASTfunctionDefinition[] functions = new IASTfunctionDefinition[length];

        for(int i = 0; i < length; i++){
            functions[i] = iast.getFunctionDefinitions()[i];
        }

        return factory.newProgram(
                functions,
                iast.getBody().accept(this,null));
    }

    @Override
    public IASTexpression visit(IASTblock iast, Void data) throws Exception {
        int length = iast.getBindings().length;
        IASTblock.IASTbinding[] iastblock = new ASTblock.ASTbinding[length];

        for (int i = 0; i< length; i++){
            iastblock[i] = factory.newBinding(
                    iast.getBindings()[i].getVariable(),
                    iast.getBindings()[i].getInitialisation().accept(this,data)
            );
        }

        return factory.newBlock(
                iastblock,
                iast.getBody().accept(this,data)
        );
    }



    @Override
    public IASTexpression visit(IASTinvocation iast, Void unused) throws Exception {
        int length = iast.getArguments().length;
        IASTexpression[] expression = new IASTexpression[length];

        for (int i = 0; i < length; i++){
            expression[i] = iast.getArguments()[i].accept(this,unused);
        }

        return factory.newInvocation(
                iast.getFunction().accept(this,unused),
                expression
        );
    }

    @Override
    public IASTexpression visit(IASTsequence iast, Void unused) throws Exception {
        int length = iast.getExpressions().length;
        IASTexpression[] expression = new IASTexpression[length];

        for (int i = 0; i < length; i++){
            expression[i] = iast.getExpressions()[i].accept(this,unused);
        }

        return factory.newSequence(expression);
    }



    @Override
    public IASTexpression visit(IASTunaryOperation iast, Void data) throws Exception {
        return factory.newUnaryOperation(
                iast.getOperator(),
                iast.getOperand().accept(this, data)
        );
    }


    @Override
    public IASTexpression visit(IASTunlessTME4 iast, Void data) throws Exception {
        return factory.newUnless(
                iast.getBody().accept(this, data),
                iast.getCondition().accept(this, data)
        );
    }



}
