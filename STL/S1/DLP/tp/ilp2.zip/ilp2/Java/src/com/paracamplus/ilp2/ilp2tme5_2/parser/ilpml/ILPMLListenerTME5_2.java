package com.paracamplus.ilp2.ilp2tme5_2.parser.ilpml;

import antlr4.ILPMLgrammar2tme5_2Parser;
import antlr4.ILPMLgrammar2tme5_2Listener;
import com.paracamplus.ilp1.interfaces.IASTblock;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp1.interfaces.IASTvariable;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTfactoryTME5_2;
import com.paracamplus.ilp2.interfaces.IASTdeclaration;
import com.paracamplus.ilp2.interfaces.IASTfunctionDefinition;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;

import java.util.ArrayList;
import java.util.List;

public class ILPMLListenerTME5_2 implements ILPMLgrammar2tme5_2Listener {

    protected IASTfactoryTME5_2 factory;

    public ILPMLListenerTME5_2(IASTfactoryTME5_2 factory) {
        super();
        this.factory = factory;
    }


    @Override
    public void enterBreak(ILPMLgrammar2tme5_2Parser.BreakContext ctx) {

    }

    @Override
    public void exitBreak(ILPMLgrammar2tme5_2Parser.BreakContext ctx) {
        ctx.node = factory.newBreak(ctx.label == null ? "" : ctx.label.getText());
    }

    @Override
    public void enterContinue(ILPMLgrammar2tme5_2Parser.ContinueContext ctx) {

    }

    @Override
    public void exitContinue(ILPMLgrammar2tme5_2Parser.ContinueContext ctx) {
        ctx.node = factory.newContinue(ctx.label == null ? "" : ctx.label.getText());
    }





    // ILP1

    @Override
    public void exitVariable(ILPMLgrammar2tme5_2Parser.VariableContext ctx) {
        ctx.node = factory.newVariable(ctx.getText());
    }

    @Override
    public void exitInvocation(
            ILPMLgrammar2tme5_2Parser.InvocationContext ctx) {
        ctx.node = factory.newInvocation(
                ctx.fun.node,
                toExpressions(ctx.args));
    }

    @Override
    public void exitConstFloat(
            ILPMLgrammar2tme5_2Parser.ConstFloatContext ctx) {
        ctx.node = factory.newFloatConstant(ctx.floatConst.getText());
    }



    @Override
    public void exitConstInteger(
            ILPMLgrammar2tme5_2Parser.ConstIntegerContext ctx) {
        ctx.node = factory.newIntegerConstant(ctx.intConst.getText());
    }

    @Override
    public void exitBinding(ILPMLgrammar2tme5_2Parser.BindingContext ctx) {
        ctx.node = factory.newBlock(
                toBindings(ctx.vars, ctx.vals),
                ctx.body.node);
    }

    @Override
    public void exitAlternative(
            ILPMLgrammar2tme5_2Parser.AlternativeContext ctx) {
        ctx.node = factory.newAlternative(
                ctx.condition.node,
                ctx.consequence.node,
                (ctx.alternant == null ? null : ctx.alternant.node));
    }

    @Override
    public void exitSequence(
            ILPMLgrammar2tme5_2Parser.SequenceContext ctx) {
        ctx.node = factory.newSequence(toExpressions(ctx.exprs));
    }

    @Override
    public void exitConstFalse(
            ILPMLgrammar2tme5_2Parser.ConstFalseContext ctx) {
        ctx.node = factory.newBooleanConstant("false");
    }


    @Override
    public void exitUnary(ILPMLgrammar2tme5_2Parser.UnaryContext ctx) {
        ctx.node = factory.newUnaryOperation(
                factory.newOperator(ctx.op.getText()),
                ctx.arg.node);
    }

    @Override
    public void exitConstTrue(
            ILPMLgrammar2tme5_2Parser.ConstTrueContext ctx) {
        ctx.node = factory.newBooleanConstant("true");
    }

    @Override
    public void exitConstString(
            ILPMLgrammar2tme5_2Parser.ConstStringContext ctx) {
        /*
         * On enlève le " initial et final, et on interprète les codes
         * d'échapement \n, \r, \t, \"
         */
        String s = ctx.getText();
        StringBuilder buf = new StringBuilder();
        for (int i = 1; i < s.length() - 1; i++) {
            if (s.charAt(i) == '\\' && i < s.length() - 2) {
                switch (s.charAt(i + 1)) {
                    case 'n':
                        buf.append('\n');
                        i++;
                        break;
                    case 'r':
                        buf.append('\r');
                        i++;
                        break;
                    case 't':
                        buf.append('\t');
                        i++;
                        break;
                    case '"':
                        buf.append('\"');
                        i++;
                        break;
                    default:
                        buf.append(s.charAt(i));
                }
            } else buf.append(s.charAt(i));
        }
        ctx.node = factory.newStringConstant(buf.toString());
    }

    @Override
    public void exitBinary(ILPMLgrammar2tme5_2Parser.BinaryContext ctx) {
        ctx.node = factory.newBinaryOperation(
                factory.newOperator(ctx.op.getText()),
                ctx.arg1.node,
                ctx.arg2.node);
    }





    /* Utilitaires de conversion ANTLR vers AST */

    protected IASTexpression[] toExpressions(
            List<ILPMLgrammar2tme5_2Parser.ExprContext> ctxs) {
        if (ctxs == null) return new IASTexpression[0];
        IASTexpression[] r = new IASTexpression[ctxs.size()];
        int pos = 0;
        for (ILPMLgrammar2tme5_2Parser.ExprContext e : ctxs) {
            r[pos++] = e.node;
        }
        return r;
    }

    protected IASTvariable[] toVariables(
            List<Token> vars, boolean addSelf) {
        if (vars == null) return new IASTvariable[0];
        IASTvariable[] r = new IASTvariable[vars.size() + (addSelf ? 1 : 0)];
        int pos = 0;
        if (addSelf) {
            // Les déclarations de méthodes ont une variable "self" implicite
            r[pos++] = factory.newVariable("self");
        }
        for (Token v : vars) {
            r[pos++] = factory.newVariable(v.getText());
        }
        return r;
    }

    protected String[] toStrings(List<Token> vars) {
        if (vars == null) return new String[0];
        String[] r = new String[vars.size()];
        int pos = 0;
        for (Token v : vars) {
            r[pos++] = v.getText();
        }
        return r;
    }

    protected IASTblock.IASTbinding[] toBindings(
            List<Token> vars,
            List<ILPMLgrammar2tme5_2Parser.ExprContext> exprs) {
        if (vars == null) return new IASTblock.IASTbinding[0];
        /* par construction, vars et ctxs ont la même taille */
        assert (vars.size() == exprs.size());
        IASTblock.IASTbinding[] r = new IASTblock.IASTbinding[exprs.size()];
        int pos = 0;
        for (Token v : vars) {
            r[pos] = factory.newBinding(
                    factory.newVariable(v.getText()),
                    exprs.get(pos).node
            );
            pos++;
        }
        return r;
    }

    @Override
    public void enterEveryRule(ParserRuleContext arg0) {
    }

    @Override
    public void exitEveryRule(ParserRuleContext arg0) {
    }

    @Override
    public void visitErrorNode(ErrorNode arg0) {
    }

    @Override
    public void visitTerminal(TerminalNode arg0) {
    }

    @Override
    public void enterConstInteger(ILPMLgrammar2tme5_2Parser.ConstIntegerContext ctx) {
    }

    @Override
    public void enterProg(ILPMLgrammar2tme5_2Parser.ProgContext ctx) {
    }

    @Override
    public void enterConstFloat(ILPMLgrammar2tme5_2Parser.ConstFloatContext ctx) {
    }

    @Override
    public void enterVariable(ILPMLgrammar2tme5_2Parser.VariableContext ctx) {
    }

    @Override
    public void enterBinary(ILPMLgrammar2tme5_2Parser.BinaryContext ctx) {
    }

    @Override
    public void enterAlternative(ILPMLgrammar2tme5_2Parser.AlternativeContext ctx) {
    }

    @Override
    public void enterConstFalse(ILPMLgrammar2tme5_2Parser.ConstFalseContext ctx) {
    }

    @Override
    public void enterSequence(ILPMLgrammar2tme5_2Parser.SequenceContext ctx) {
    }

    @Override
    public void enterConstTrue(ILPMLgrammar2tme5_2Parser.ConstTrueContext ctx) {
    }

    @Override
    public void enterBinding(ILPMLgrammar2tme5_2Parser.BindingContext ctx) {
    }

    @Override
    public void enterConstString(ILPMLgrammar2tme5_2Parser.ConstStringContext ctx) {
    }

    @Override
    public void enterUnary(ILPMLgrammar2tme5_2Parser.UnaryContext ctx) {
    }

    @Override
    public void enterInvocation(ILPMLgrammar2tme5_2Parser.InvocationContext ctx) {
    }


    // ILP2

    @Override
    public void exitProg(ILPMLgrammar2tme5_2Parser.ProgContext ctx) {
        List<IASTfunctionDefinition> f = new ArrayList<>();
        for (ILPMLgrammar2tme5_2Parser.GlobalFunDefContext d : ctx.defs) {
            IASTdeclaration x = d.node;
            f.add((IASTfunctionDefinition) x);
        }
        IASTexpression e = factory.newSequence(toExpressions(ctx.exprs));
        ctx.node = factory.newProgram(
                f.toArray(new IASTfunctionDefinition[0]),
                e);
    }

    @Override
    public void exitGlobalFunDef(ILPMLgrammar2tme5_2Parser.GlobalFunDefContext ctx) {
        ctx.node = factory.newFunctionDefinition(
                factory.newVariable(ctx.name.getText()),
                toVariables(ctx.vars, false),
                ctx.body.node);
    }

    @Override
    public void exitVariableAssign(ILPMLgrammar2tme5_2Parser.VariableAssignContext ctx) {
        ctx.node = factory.newAssignment(
                factory.newVariable(ctx.var.getText()),
                ctx.val.node);
    }

    @Override
    public void exitLoop(ILPMLgrammar2tme5_2Parser.LoopContext ctx) {
        ctx.node = factory.newLoop((ctx.label == null ? "" : ctx.label.getText()), ctx.condition.node, ctx.body.node);
    }

    @Override
    public void enterGlobalFunDef(ILPMLgrammar2tme5_2Parser.GlobalFunDefContext ctx) {
    }

    @Override
    public void enterVariableAssign(ILPMLgrammar2tme5_2Parser.VariableAssignContext ctx) {
    }

    @Override
    public void enterLoop(ILPMLgrammar2tme5_2Parser.LoopContext ctx) {
    }
}