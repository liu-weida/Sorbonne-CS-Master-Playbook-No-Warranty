package com.paracamplus.ilp2.ilp2tme5_2.interpreter;

import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;

public class ContinueExceptionTME5_2 extends EvaluationException
{
    public ContinueExceptionTME5_2(String msg) {
        super(msg);
    }
}
