package com.paracamplus.ilp2.ilp2tme4.interfaces;
import com.paracamplus.ilp1.interfaces.IASTexpression;


public interface IASTunlessTME4 extends IASTexpression {
	IASTexpression getCondition();
	IASTexpression getBody();
}

