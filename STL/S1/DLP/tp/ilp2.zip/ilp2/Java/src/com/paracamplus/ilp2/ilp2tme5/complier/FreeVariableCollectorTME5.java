package com.paracamplus.ilp2.ilp2tme5.complier;

import java.util.Set;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.interfaces.IASTClocalVariable;
import com.paracamplus.ilp2.compiler.FreeVariableCollector;
import com.paracamplus.ilp2.compiler.interfaces.IASTCprogram;
import com.paracamplus.ilp2.ilp2tme5.complier.interfaces.IASTCvisitorTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTbreakTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTcontinueTME5;

public class FreeVariableCollectorTME5 extends FreeVariableCollector implements IASTCvisitorTME5<Void, Set<IASTClocalVariable>, CompilationException> {

	public FreeVariableCollectorTME5(IASTCprogram program) {
		super(program);
	}

	@Override
	public Void visit(IASTbreakTME5 iast, Set<IASTClocalVariable> data) throws CompilationException {
		return null;
	}

	@Override
	public Void visit(IASTcontinueTME5 iast, Set<IASTClocalVariable> data) throws CompilationException {
		return null;
	}

}

// CONFIRMÉ
