package com.paracamplus.ilp2.ilp2tme5.interfaces;

import com.paracamplus.ilp2.interfaces.IASTvisitor;

public interface IASTvisitorTME5<Result, Data, Anomaly extends Throwable> extends IASTvisitor<Result, Data, Anomaly>{
	
	Result visit(IASTbreakTME5 iast, Data data) throws Anomaly;
	Result visit(IASTcontinueTME5 iast, Data data) throws Anomaly;
	
	// CONFIRMÉ
}

