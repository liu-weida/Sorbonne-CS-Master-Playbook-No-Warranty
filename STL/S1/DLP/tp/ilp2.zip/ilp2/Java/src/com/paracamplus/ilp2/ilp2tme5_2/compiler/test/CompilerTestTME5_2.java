package com.paracamplus.ilp2.ilp2tme5_2.compiler.test;

import com.paracamplus.ilp1.compiler.*;
import com.paracamplus.ilp1.compiler.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.compiler.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp1.compiler.optimizer.IdentityOptimizer;
import com.paracamplus.ilp1.compiler.test.CompilerRunner;
import com.paracamplus.ilp1.parser.xml.IXMLParser;
//import com.paracamplus.ilp2.ast.ASTfactory;
//import com.paracamplus.ilp2.compiler.Compiler;
import com.paracamplus.ilp2.compiler.test.CompilerTest;
//import com.paracamplus.ilp2.interfaces.IASTfactory;
//import com.paracamplus.ilp2.parser.ilpml.ILPMLParser;
import com.paracamplus.ilp2.ilp2tme5_2.ast.ASTfactoryTME5_2;
//import com.paracamplus.ilp2.ilp2tme5_2.compiler.CompilerTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.compiler.CompilerTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTfactoryTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.parser.ilpml.ILPMLParserTME5_2;
import com.paracamplus.ilp2.parser.xml.XMLParser;
import org.junit.runners.Parameterized;

import java.io.File;
import java.util.Collection;

public class CompilerTestTME5_2 extends CompilerTest {
    public CompilerTestTME5_2(File file) {
        super(file);
    }
    protected static String[] samplesDirName = {"SamplesTME5_2"};

    @Override
    public void configureRunner(CompilerRunner run) throws CompilationException {
        // configuration du parseur
        IASTfactoryTME5_2 factory = new ASTfactoryTME5_2();
        IXMLParser xMLParser = new XMLParser(factory);
        xMLParser.setGrammar(new File(XMLgrammarFile));
        run.setXMLParser(xMLParser);
        run.setILPMLParser(new ILPMLParserTME5_2(factory));

        // configuration du compilateur
        IOperatorEnvironment ioe = new OperatorEnvironment();
        OperatorStuff.fillUnaryOperators(ioe);
        OperatorStuff.fillBinaryOperators(ioe);
        IGlobalVariableEnvironment gve = new GlobalVariableEnvironment();
        GlobalVariableStuff.fillGlobalVariables(gve);
        com.paracamplus.ilp2.compiler.Compiler compiler = new CompilerTME5_2(ioe, gve);
        compiler.setOptimizer(new IdentityOptimizer());
        run.setCompiler(compiler);

        // configuration du script de compilation et exécution
        run.setRuntimeScript(scriptCommand);
    }

    @Parameterized.Parameters(name = "{0}")
    public static Collection<File[]> data() throws Exception {
        return CompilerRunner.getFileList(samplesDirName, pattern);
    }

}
