package com.paracamplus.ilp2.ilp2tme5.ast;

import com.paracamplus.ilp1.ast.ASTexpression;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTcontinueTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTvisitorTME5;

public class ASTcontinueTME5 extends ASTexpression implements IASTcontinueTME5{
	
	@Override
	public <Result, Data, Anomaly extends Throwable> Result accept(
			com.paracamplus.ilp1.interfaces.IASTvisitor<Result, Data, Anomaly> visitor, Data data) throws Anomaly {
		return ((IASTvisitorTME5 <Result, Data, Anomaly>) visitor).visit(this, data);
	}
	
	// CONFIRMÉ

}
