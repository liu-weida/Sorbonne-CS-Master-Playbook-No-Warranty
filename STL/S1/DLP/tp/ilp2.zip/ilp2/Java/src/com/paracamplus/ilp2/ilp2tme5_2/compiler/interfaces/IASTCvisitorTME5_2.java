package com.paracamplus.ilp2.ilp2tme5_2.compiler.interfaces;

import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTbreakTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTcontinueTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTloopTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTvisitorTME5_2;

public interface IASTCvisitorTME5_2<Result, Data, Anomaly extends Throwable> extends IASTvisitorTME5_2<Result, Data, Anomaly> {
	Result visit(IASTbreakTME5_2 iast, Data data) throws Anomaly;
	Result visit(IASTcontinueTME5_2 iast, Data data) throws Anomaly;
	Result visit(IASTloopTME5_2 iast, Data data) throws Anomaly;
}
