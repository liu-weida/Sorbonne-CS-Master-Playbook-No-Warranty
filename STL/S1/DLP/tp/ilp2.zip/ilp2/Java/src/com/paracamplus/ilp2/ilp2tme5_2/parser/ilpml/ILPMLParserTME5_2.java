package com.paracamplus.ilp2.ilp2tme5_2.parser.ilpml;

import antlr4.ILPMLgrammar2tme5_2Lexer;
import antlr4.ILPMLgrammar2tme5_2Parser;
import com.paracamplus.ilp1.parser.ParseException;
//import com.paracamplus.ilp2.interfaces.IASTfactory;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTfactoryTME5_2;
import com.paracamplus.ilp2.interfaces.IASTprogram;
//import com.paracamplus.ilp2.parser.ilpml.ILPMLListener;
import com.paracamplus.ilp2.parser.ilpml.ILPMLParser;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

public class ILPMLParserTME5_2 extends ILPMLParser {
    public ILPMLParserTME5_2(IASTfactoryTME5_2 factory) {
        super(factory);
    }
    @Override
    public IASTprogram getProgram() throws ParseException {
        try {
            ANTLRInputStream in = new ANTLRInputStream(input.getText());
            // flux de caractères -> analyseur lexical
            ILPMLgrammar2tme5_2Lexer lexer = new ILPMLgrammar2tme5_2Lexer(in);
            // analyseur lexical -> flux de tokens
            CommonTokenStream tokens =	new CommonTokenStream(lexer);
            // flux tokens -> analyseur syntaxique
            ILPMLgrammar2tme5_2Parser parser = new ILPMLgrammar2tme5_2Parser(tokens);
            // démarage de l'analyse syntaxique
            ILPMLgrammar2tme5_2Parser.ProgContext tree = parser.prog();
            // parcours de l'arbre syntaxique et appels du Listener
            ParseTreeWalker walker = new ParseTreeWalker();
            ILPMLListenerTME5_2 extractor = new ILPMLListenerTME5_2((IASTfactoryTME5_2)factory);
            walker.walk(extractor, tree);
            return tree.node;
        } catch (Exception e) {
            throw new ParseException(e);
        }
    }
}
