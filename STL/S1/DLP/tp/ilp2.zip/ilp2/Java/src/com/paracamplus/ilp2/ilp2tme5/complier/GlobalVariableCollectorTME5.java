package com.paracamplus.ilp2.ilp2tme5.complier;

import java.util.Set;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.interfaces.IASTCglobalVariable;
import com.paracamplus.ilp2.compiler.GlobalVariableCollector;
import com.paracamplus.ilp2.ilp2tme5.complier.interfaces.IASTCvisitorTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTbreakTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTcontinueTME5;

public class GlobalVariableCollectorTME5 extends GlobalVariableCollector implements IASTCvisitorTME5<Set<IASTCglobalVariable>, Set<IASTCglobalVariable>, CompilationException>{

	@Override
	public Set<IASTCglobalVariable> visit(IASTbreakTME5 iast, Set<IASTCglobalVariable> data)
			throws CompilationException {
		return data;
	}

	@Override
	public Set<IASTCglobalVariable> visit(IASTcontinueTME5 iast, Set<IASTCglobalVariable> data)
			throws CompilationException {
		return data;
	}

}


// CONFIRMÉ
