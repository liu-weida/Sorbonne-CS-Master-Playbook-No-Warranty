package com.paracamplus.ilp2.ilp2tme5_2.interpreter;

import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.interpreter.interfaces.ILexicalEnvironment;
import com.paracamplus.ilp1.interpreter.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp2.ilp2tme5.interpreter.BreakException;
import com.paracamplus.ilp2.ilp2tme5.interpreter.ContinueException;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTbreakTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTcontinueTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTloopTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTvisitorTME5_2;
import com.paracamplus.ilp2.interfaces.IASTfunctionDefinition;
import com.paracamplus.ilp2.interfaces.IASTprogram;
import com.paracamplus.ilp2.interpreter.Interpreter;

import java.util.ArrayList;

public class InterpreterTME5_2 extends Interpreter implements IASTvisitorTME5_2<Object, ILexicalEnvironment, EvaluationException> {

    private ArrayList<String> labels;
    protected int nb = 0;

    public InterpreterTME5_2(IGlobalVariableEnvironment globalVariableEnvironment, IOperatorEnvironment operatorEnvironment) {
        super(globalVariableEnvironment, operatorEnvironment);
        labels = new ArrayList<>();
    }

    @Override
    public Object visit(com.paracamplus.ilp1.interfaces.IASTprogram iast, ILexicalEnvironment lexenv) throws EvaluationException  {
        return visit((IASTprogram)iast, lexenv);
    }

    public Object visit(IASTprogram iast, ILexicalEnvironment lexenv)
            throws EvaluationException {
        for ( IASTfunctionDefinition fd : iast.getFunctionDefinitions() ) {
            Object f = this.visit(fd, lexenv);
            String v = fd.getName();
            getGlobalVariableEnvironment().addGlobalVariableValue(v, f);
        }
        try {
            return iast.getBody().accept(this, lexenv);
        } catch (Exception exc) {
            return exc;
        }
    }

    @Override
    public Object visit(IASTloopTME5_2 iast, ILexicalEnvironment lexenv) throws EvaluationException {
        if (!iast.getLabel().isBlank()){
            labels.add(iast.getLabel());
        }
        while ( true ) {
            Object condition = iast.getCondition().accept(this, lexenv);
            if ( condition instanceof Boolean ) {
                Boolean c = (Boolean) condition;
                if ( ! c ) {
                    break;
                }
            }
            nb++;
            try {
                iast.getBody().accept(this, lexenv);

            } catch (BreakException e){
                String message = e.getMessage();
                if(message.equals(iast.getLabel()) || message.equals("break")){
                    labels.remove(labels.lastIndexOf(iast.getLabel()));
                    nb--;
                    break;
                }
                int index = labels.lastIndexOf(message);
                if (index == -1) throw new EvaluationException("The label is not defined");
                labels.remove(labels.lastIndexOf(iast.getLabel()));
                nb--;
                throw new BreakException(message);

            } catch (ContinueException e){
                String message = e.getMessage();
                if(message.equals(iast.getLabel()) || message.equals("continue")){
                    //labels.remove(labels.lastIndexOf(iast.getLabel()));
                    nb--;
                    continue;
                }
                int index = labels.lastIndexOf(message);
                if (index == -1) throw new EvaluationException("The label is not defined");
                labels.remove(labels.lastIndexOf(iast.getLabel()));
                nb--;
                throw new ContinueException(message);
            }
            nb--;
        }
        return Boolean.FALSE;
    }

    @Override
    public Object visit(IASTbreakTME5_2 iast, ILexicalEnvironment iLexicalEnvironment) throws EvaluationException {
        if (nb < 1){
            throw new EvaluationException("The keyword break is not in a loop");
        }else{
            if (iast.getLabel().isBlank()){
                throw new BreakException("break");
            }else {
                throw new BreakException(iast.getLabel());
            }
        }


    }

    @Override
    public Object visit(IASTcontinueTME5_2 iast, ILexicalEnvironment iLexicalEnvironment) throws EvaluationException {
        if (nb < 1){
            throw new EvaluationException("The keyword continue is not in a loop");
        }
        if (iast.getLabel().isBlank()){
            throw new ContinueException("continue");
        }else {
            throw new ContinueException(iast.getLabel());
        }
    }
}
