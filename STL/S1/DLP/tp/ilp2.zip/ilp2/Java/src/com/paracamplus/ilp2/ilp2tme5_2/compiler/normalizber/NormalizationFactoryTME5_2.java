package com.paracamplus.ilp2.ilp2tme5_2.compiler.normalizber;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.compiler.normalizer.NormalizationFactory;
import com.paracamplus.ilp2.ilp2tme5_2.ast.ASTbreakTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.ast.ASTcontinueTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.ast.ASTloopTME5_2;

public class NormalizationFactoryTME5_2 extends NormalizationFactory implements INormalizationFactoryTME5_2 {
    @Override
    public IASTexpression newBreak(String label) {
        return new ASTbreakTME5_2(label);
    }

    @Override
    public IASTexpression newContinue(String label) {
        return new ASTcontinueTME5_2(label);
    }

    @Override
    public IASTexpression newLoop(String label, IASTexpression condition, IASTexpression body) {
        return new ASTloopTME5_2(label,condition,body);
    }
}
