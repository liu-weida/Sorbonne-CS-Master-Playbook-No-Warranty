package com.paracamplus.ilp2.ilp2tme5.complier.normalizer;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.compiler.normalizer.NormalizationFactory;
import com.paracamplus.ilp2.ilp2tme5.ast.ASTbreakTME5;
import com.paracamplus.ilp2.ilp2tme5.ast.ASTcontinueTME5;

public class NormalizeFactoryTME5 extends NormalizationFactory implements INormalizerFactoryTME5{

	@Override
	public IASTexpression newBreak() {
		return new ASTbreakTME5();
	}

	@Override
	public IASTexpression newContinue() {
		return new ASTcontinueTME5();
	}

}


// CONFIRMÉ