package com.paracamplus.ilp2.ilp2tme4.interpreter;

import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.interpreter.interfaces.ILexicalEnvironment;
import com.paracamplus.ilp1.interpreter.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTunlessTME4;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTvisitorTME4;
import com.paracamplus.ilp2.interpreter.Interpreter;

public class InterpreterTME4 extends Interpreter implements IASTvisitorTME4<Object, ILexicalEnvironment, EvaluationException> {

	public InterpreterTME4(IGlobalVariableEnvironment globalVariableEnvironment,
			IOperatorEnvironment operatorEnvironment) {
		super(globalVariableEnvironment, operatorEnvironment);
	}


	public Object visit(IASTunlessTME4 iast, ILexicalEnvironment lexenv)
            throws EvaluationException {
		Object condition = iast.getCondition().accept(this, lexenv);
		if(condition instanceof Boolean) {
			Boolean c = (Boolean) condition;
			if(!(c.booleanValue())) {
				return iast.getBody().accept(this, lexenv);
			}
		}
        return Boolean.FALSE;
    }





}
