package com.paracamplus.ilp2.ilp2tme4.compiler;

import java.util.Set;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.interfaces.IASTCglobalVariable;
import com.paracamplus.ilp2.compiler.GlobalVariableCollector;
import com.paracamplus.ilp2.ilp2tme4.compiler.interfaces.IASTCvisitorTME4;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTunlessTME4;

public class GlobalVariableCollectorTME4 extends GlobalVariableCollector implements IASTCvisitorTME4<Set<IASTCglobalVariable>, Set<IASTCglobalVariable>, CompilationException>{

	@Override
	public Set<IASTCglobalVariable> visit(IASTunlessTME4 iast, Set<IASTCglobalVariable> ret) throws CompilationException {
		// TODO Auto-generated method stub
		ret = iast.getCondition().accept(this, ret);
		return ret;
	}

}
