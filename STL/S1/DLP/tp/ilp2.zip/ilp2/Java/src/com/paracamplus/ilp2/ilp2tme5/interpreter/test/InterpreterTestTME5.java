package com.paracamplus.ilp2.ilp2tme5.interpreter.test;

import java.io.File;
import java.io.StringWriter;
import java.util.Collection;

import org.junit.runners.Parameterized.Parameters;

import com.paracamplus.ilp1.interpreter.GlobalVariableEnvironment;
import com.paracamplus.ilp1.interpreter.GlobalVariableStuff;
import com.paracamplus.ilp1.interpreter.OperatorEnvironment;
import com.paracamplus.ilp1.interpreter.OperatorStuff;
import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.interpreter.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp1.interpreter.test.InterpreterRunner;
import com.paracamplus.ilp1.parser.xml.IXMLParser;
import com.paracamplus.ilp2.ilp2tme5.interpreter.InterpreterTME5;
import com.paracamplus.ilp2.ilp2tme5.parser.ilpml.ILPMLParserTME5;
import com.paracamplus.ilp2.ilp2tme5.ast.ASTfactoryTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTfactoryTME5;
import com.paracamplus.ilp2.parser.xml.XMLParser;

public class InterpreterTestTME5 extends com.paracamplus.ilp1.interpreter.test.InterpreterTest{

	
    protected static String[] samplesDirName = { "SamplesTME5" };

    public InterpreterTestTME5(final File file) {
        super(file);
    }
	
    
    public void configureRunner(InterpreterRunner run) throws EvaluationException {
        // configuration du parseur
        IASTfactoryTME5 factory = new ASTfactoryTME5();
        IXMLParser xmlparser = new XMLParser(factory);
        xmlparser.setGrammar(new File(XMLgrammarFile));
        run.setXMLParser(xmlparser);
        run.setILPMLParser(new ILPMLParserTME5(factory));

        // configuration de l'interprète
        StringWriter stdout = new StringWriter();
        run.setStdout(stdout);
        IGlobalVariableEnvironment gve = new GlobalVariableEnvironment();
        GlobalVariableStuff.fillGlobalVariables(gve, stdout);
        IOperatorEnvironment oe = new OperatorEnvironment();
        OperatorStuff.fillUnaryOperators(oe);
        OperatorStuff.fillBinaryOperators(oe);
        InterpreterTME5 interpreter = new InterpreterTME5(gve, oe);
        run.setInterpreter(interpreter);
    }

    @Parameters(name = "{0}")
    public static Collection<File[]> data() throws Exception {
        return InterpreterRunner.getFileList(samplesDirName, pattern);
    }
	
}
