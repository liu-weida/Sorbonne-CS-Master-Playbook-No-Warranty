package com.paracamplus.ilp2.ilp2tme5.complier.normalizer;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.normalizer.INormalizationEnvironment;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.compiler.normalizer.Normalizer;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTbreakTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTcontinueTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTvisitorTME5;

public class NormalizerTME5 extends Normalizer implements IASTvisitorTME5<IASTexpression, INormalizationEnvironment, CompilationException> {

	INormalizerFactoryTME5 factory;
	public NormalizerTME5(INormalizerFactoryTME5 factory) {
		super(factory);
		this.factory = factory;
	}

	@Override
	public IASTexpression visit(IASTbreakTME5 iast, INormalizationEnvironment data) throws CompilationException {
//		return  factory.newBreak();
		return ((INormalizerFactoryTME5)factory).newBreak();
	}

	@Override
	public IASTexpression visit(IASTcontinueTME5 iast, INormalizationEnvironment data) throws CompilationException {
//		return factory.newContinue();
		return ((INormalizerFactoryTME5)factory).newContinue();
	}

}
