package com.paracamplus.ilp2.ilp2tme5.complier.interfaces;

import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTbreakTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTcontinueTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTvisitorTME5;

public interface IASTCvisitorTME5<Result, Data, Anomaly extends Throwable> extends IASTvisitorTME5<Result, Data, Anomaly>{

	Result visit(IASTbreakTME5 iast, Data data) throws Anomaly;
	Result visit(IASTcontinueTME5 iast, Data data) throws Anomaly;
}


// CONFIRMÉ