package com.paracamplus.ilp2.ilp2tme5.complier;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Set;

import com.paracamplus.ilp1.compiler.AssignDestination;
import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.NoDestination;
import com.paracamplus.ilp1.compiler.VoidDestination;
import com.paracamplus.ilp1.compiler.interfaces.IASTCglobalVariable;
import com.paracamplus.ilp1.compiler.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.compiler.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp1.interfaces.IASTvariable;
import com.paracamplus.ilp2.compiler.interfaces.IASTCprogram;
import com.paracamplus.ilp2.ilp2tme5.complier.normalizer.*;
import com.paracamplus.ilp2.ilp2tme5.complier.interfaces.IASTCvisitorTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTbreakTME5;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTcontinueTME5;
import com.paracamplus.ilp2.interfaces.IASTloop;
import com.paracamplus.ilp2.interfaces.IASTprogram;




public class CompilerTME5 extends com.paracamplus.ilp2.compiler.Compiler
implements IASTCvisitorTME5<Void, CompilerTME5.Context, CompilationException> {

    protected int timesWhile = 0;

    public CompilerTME5(IOperatorEnvironment ioe, IGlobalVariableEnvironment igve) {
        super(ioe, igve);
    }

    public IASTCprogram normalize(IASTprogram program)
            throws CompilationException {
        INormalizerFactoryTME5 nf = new NormalizeFactoryTME5();
        NormalizerTME5 normalizer = new NormalizerTME5(nf);
        IASTCprogram newprogram = normalizer.transform(program);
        return newprogram;
    }

    @Override
    public String compile(com.paracamplus.ilp1.interfaces.IASTprogram program) throws CompilationException {
        return compile((IASTprogram)program);
    }

    public String compile(IASTprogram program)
            throws CompilationException {

        IASTCprogram newprogram = normalize(program);
        newprogram = ((IASTCprogram) optimizer.transform(newprogram));

        GlobalVariableCollectorTME5 gvc = new GlobalVariableCollectorTME5();
        Set<IASTCglobalVariable> gvs = gvc.analyze(newprogram);
        newprogram.setGlobalVariables(gvs);

        FreeVariableCollectorTME5 fvc = new FreeVariableCollectorTME5(newprogram);
        newprogram = (fvc.analyze());

        Context context = new Context(NoDestination.NO_DESTINATION);
        StringWriter sw = new StringWriter();
        try {
            out = new BufferedWriter(sw);
            visit(newprogram, context);
            out.flush();
        } catch (IOException exc) {
            throw new CompilationException(exc);
        }
        return sw.toString();
    }

    @Override
    public Void visit(IASTloop iast, Context context)
            throws CompilationException {
        emit("while ( 1 ) { \n");
        IASTvariable tmp = context.newTemporaryVariable();
        emit("  ILP_Object " + tmp.getMangledName() + "; \n");
        Context c = context.redirect(new AssignDestination(tmp));
        iast.getCondition().accept(this, c);
        emit("  if ( ILP_isEquivalentToTrue(");
        emit(tmp.getMangledName());
        emit(") ) {\n");
        Context cb = context.redirect(VoidDestination.VOID_DESTINATION);
        timesWhile++;
        iast.getBody().accept(this, cb);
        emit("\n} else { \n");
        emit("    break; \n");
        emit("\n}\n}\n");
        whatever.accept(this, context);
        timesWhile--;
        return null;
    }

    @Override
    public Void visit(IASTbreakTME5 iast, Context context) throws CompilationException {
        emit("break; \n");
        if (timesWhile <= 0)
            throw new CompilationException("break n'est pas dans la boucle");
        return null;
    }

    @Override
    public Void visit(IASTcontinueTME5 iast, Context context) throws CompilationException {
        emit("continue; \n");
        if (timesWhile <= 0)
            throw new CompilationException("continue n'est pas dans la boucle");
        return null;
    }
}



