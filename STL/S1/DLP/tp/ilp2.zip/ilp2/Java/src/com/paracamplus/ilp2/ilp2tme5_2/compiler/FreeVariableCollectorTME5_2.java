package com.paracamplus.ilp2.ilp2tme5_2.compiler;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.interfaces.IASTClocalVariable;
import com.paracamplus.ilp2.compiler.FreeVariableCollector;
import com.paracamplus.ilp2.compiler.interfaces.IASTCprogram;
import com.paracamplus.ilp2.ilp2tme5_2.compiler.interfaces.IASTCvisitorTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTbreakTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTcontinueTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTloopTME5_2;

import java.util.Set;

public class FreeVariableCollectorTME5_2 extends FreeVariableCollector implements IASTCvisitorTME5_2<Void, Set<IASTClocalVariable>, CompilationException> {

    public FreeVariableCollectorTME5_2(IASTCprogram program) {
        super(program);
    }

    @Override
    public Void visit(IASTbreakTME5_2 iast, Set<IASTClocalVariable> iastClocalVariables) throws CompilationException {
        return null;
    }

    @Override
    public Void visit(IASTcontinueTME5_2 iast, Set<IASTClocalVariable> iastClocalVariables) throws CompilationException {
        return null;
    }

    @Override
    public Void visit(IASTloopTME5_2 iast, Set<IASTClocalVariable> iastClocalVariables) throws CompilationException {

        iast.getCondition().accept(this,iastClocalVariables);
        iast.getBody().accept(this,iastClocalVariables);

        return null;
    }
}
