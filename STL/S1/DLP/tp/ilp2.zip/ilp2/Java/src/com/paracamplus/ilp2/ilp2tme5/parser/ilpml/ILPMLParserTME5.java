package com.paracamplus.ilp2.ilp2tme5.parser.ilpml;

import org.antlr.v4.runtime.ANTLRInputStream;
import antlr4.ILPMLgrammar2tme5Lexer;
import antlr4.ILPMLgrammar2tme5Parser;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import com.paracamplus.ilp1.parser.ParseException;
import com.paracamplus.ilp2.ilp2tme5.interfaces.IASTfactoryTME5;
import com.paracamplus.ilp2.interfaces.IASTprogram;

public class ILPMLParserTME5 extends com.paracamplus.ilp2.parser.ilpml.ILPMLParser{

	
    public ILPMLParserTME5(IASTfactoryTME5 factory) {
		super(factory);
	}

    @Override
    public IASTprogram getProgram() throws ParseException {
        try {
            ANTLRInputStream in = new ANTLRInputStream(input.getText());
            // flux de caractères -> analyseur lexical
            ILPMLgrammar2tme5Lexer lexer = new ILPMLgrammar2tme5Lexer(in);
            // analyseur lexical -> flux de tokens
            CommonTokenStream tokens =	new CommonTokenStream(lexer);
            // flux tokens -> analyseur syntaxique
            ILPMLgrammar2tme5Parser parser = new ILPMLgrammar2tme5Parser(tokens);
            // démarage de l'analyse syntaxique
            ILPMLgrammar2tme5Parser.ProgContext tree = parser.prog();
            // parcours de l'arbre syntaxique et appels du Listener
            ParseTreeWalker walker = new ParseTreeWalker();
            ILPMLListenerTME5 extractor = new ILPMLListenerTME5((IASTfactoryTME5) factory);
            walker.walk(extractor, tree);
            return tree.node;
        } catch (Exception e) {
            throw new ParseException(e);
        }
    }
}

// CONFIRMÉ


