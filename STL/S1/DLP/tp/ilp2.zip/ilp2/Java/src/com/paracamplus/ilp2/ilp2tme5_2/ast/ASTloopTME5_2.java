package com.paracamplus.ilp2.ilp2tme5_2.ast;

import com.paracamplus.ilp1.annotation.OrNull;
import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTloopTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTvisitorTME5_2;


public class ASTloopTME5_2 implements IASTloopTME5_2 {

    private final IASTexpression condition;
    private final IASTexpression body;
    private final String label;

    public ASTloopTME5_2 (String label, IASTexpression condition, IASTexpression body) {
        this.condition = condition;
        this.body = body;
        this.label=label;
    }

    @Override
    public <Result, Data, Anomaly extends Throwable> Result accept(
            com.paracamplus.ilp1.interfaces.IASTvisitor<Result, Data, Anomaly> visitor, Data data) throws Anomaly {
        return ((IASTvisitorTME5_2<Result, Data, Anomaly>) visitor).visit(this,data);	}


    @Override
    public IASTexpression getCondition() {
        return condition;
    }

    @Override
    public IASTexpression getBody() {
        return body;
    }

    @Override @OrNull
    public String getLabel() {
        return label;
    }



}
