package com.paracamplus.ilp2.ilp2tme5.interfaces;

import com.paracamplus.ilp1.interfaces.IASTexpression;

public interface IASTcontinueTME5 extends IASTexpression {

}


// CONFIMÉ