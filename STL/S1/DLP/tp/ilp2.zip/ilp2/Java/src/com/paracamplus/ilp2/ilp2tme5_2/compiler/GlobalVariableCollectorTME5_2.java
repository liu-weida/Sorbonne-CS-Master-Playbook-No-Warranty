package com.paracamplus.ilp2.ilp2tme5_2.compiler;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.interfaces.IASTCglobalVariable;
import com.paracamplus.ilp2.compiler.GlobalVariableCollector;
import com.paracamplus.ilp2.ilp2tme5.complier.interfaces.IASTCvisitorTME5;
import com.paracamplus.ilp2.ilp2tme5_2.compiler.interfaces.IASTCvisitorTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTbreakTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTcontinueTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTloopTME5_2;

import java.util.Set;

public class GlobalVariableCollectorTME5_2 extends GlobalVariableCollector implements IASTCvisitorTME5_2<Set<IASTCglobalVariable>, Set<IASTCglobalVariable>, CompilationException> {

    @Override
    public Set<IASTCglobalVariable> visit(IASTbreakTME5_2 iast, Set<IASTCglobalVariable> iastCglobalVariables) throws CompilationException {
        return iastCglobalVariables;
    }

    @Override
    public Set<IASTCglobalVariable> visit(IASTcontinueTME5_2 iast, Set<IASTCglobalVariable> iastCglobalVariables) throws CompilationException {
        return iastCglobalVariables;
    }

    @Override
    public Set<IASTCglobalVariable> visit(IASTloopTME5_2 iast, Set<IASTCglobalVariable> iastCglobalVariables) throws CompilationException {

        result = iast.getCondition().accept(this,result);
        result = iast.getBody().accept(this,result);

        return result;
    }
}
