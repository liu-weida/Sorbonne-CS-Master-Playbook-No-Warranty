package com.paracamplus.ilp2.ilp2tme4.parser.ilpml;

import antlr4.ILPMLgrammar2tme4Lexer;
import antlr4.ILPMLgrammar2tme4Parser;
import com.paracamplus.ilp1.parser.ParseException;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTfactoryTME4;
//import com.paracamplus.ilp2.interfaces.IASTfactory;
import com.paracamplus.ilp2.interfaces.IASTprogram;
//import com.paracamplus.ilp2.parser.ilpml.ILPMLListener;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

public class ILPMLParserTME4 extends com.paracamplus.ilp2.parser.ilpml.ILPMLParser {
    public ILPMLParserTME4(IASTfactoryTME4 factory) {
        super(factory);
    }

    @Override
    public IASTprogram getProgram() throws ParseException {
        try {
            ANTLRInputStream in = new ANTLRInputStream(input.getText());
            // flux de caractères -> analyseur lexical
            ILPMLgrammar2tme4Lexer lexer = new ILPMLgrammar2tme4Lexer(in);
            // analyseur lexical -> flux de tokens
            CommonTokenStream tokens =	new CommonTokenStream(lexer);
            // flux tokens -> analyseur syntaxique
            ILPMLgrammar2tme4Parser parser = new ILPMLgrammar2tme4Parser(tokens);
            // démarage de l'analyse syntaxique
            ILPMLgrammar2tme4Parser.ProgContext tree = parser.prog();
            // parcours de l'arbre syntaxique et appels du Listener
            ParseTreeWalker walker = new ParseTreeWalker();
            ILPMLListenerTME4 extractor = new ILPMLListenerTME4((IASTfactoryTME4) factory);
            walker.walk(extractor, tree);
            return tree.node;
        } catch (Exception e) {
            throw new ParseException(e);
        }
    }
}
