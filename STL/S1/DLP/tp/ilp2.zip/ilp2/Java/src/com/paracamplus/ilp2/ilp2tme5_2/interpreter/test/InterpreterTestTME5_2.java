package com.paracamplus.ilp2.ilp2tme5_2.interpreter.test;

import com.paracamplus.ilp1.interpreter.GlobalVariableEnvironment;
import com.paracamplus.ilp1.interpreter.GlobalVariableStuff;
import com.paracamplus.ilp1.interpreter.OperatorEnvironment;
import com.paracamplus.ilp1.interpreter.OperatorStuff;
import com.paracamplus.ilp1.interpreter.interfaces.EvaluationException;
import com.paracamplus.ilp1.interpreter.interfaces.IGlobalVariableEnvironment;
import com.paracamplus.ilp1.interpreter.interfaces.IOperatorEnvironment;
import com.paracamplus.ilp1.interpreter.test.InterpreterRunner;
import com.paracamplus.ilp1.parser.xml.IXMLParser;
//import com.paracamplus.ilp2.ast.ASTfactory;
//import com.paracamplus.ilp2.interfaces.IASTfactory;
//import com.paracamplus.ilp2.interpreter.Interpreter;
import com.paracamplus.ilp2.ilp2tme5_2.ast.ASTfactoryTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interfaces.IASTfactoryTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.interpreter.InterpreterTME5_2;
import com.paracamplus.ilp2.ilp2tme5_2.parser.ilpml.ILPMLParserTME5_2;
import com.paracamplus.ilp2.interpreter.test.InterpreterTest;
//import com.paracamplus.ilp2.parser.ilpml.ILPMLParser;
import com.paracamplus.ilp2.parser.xml.XMLParser;
import org.junit.runners.Parameterized;

import java.io.File;
import java.io.StringWriter;
import java.util.Collection;

public class InterpreterTestTME5_2 extends InterpreterTest {
    public InterpreterTestTME5_2(File file) {
        super(file);
    }

    protected static String[] samplesDirName = { "SamplesTME5_2" };

    public void configureRunner(InterpreterRunner run) throws EvaluationException {
        // configuration du parseur
        IASTfactoryTME5_2 factory = new ASTfactoryTME5_2();
        IXMLParser xmlparser = new XMLParser(factory);
        xmlparser.setGrammar(new File(XMLgrammarFile));
        run.setXMLParser(xmlparser);
        run.setILPMLParser(new ILPMLParserTME5_2(factory));

        // configuration de l'interprète
        StringWriter stdout = new StringWriter();
        run.setStdout(stdout);
        IGlobalVariableEnvironment gve = new GlobalVariableEnvironment();
        GlobalVariableStuff.fillGlobalVariables(gve, stdout);
        IOperatorEnvironment oe = new OperatorEnvironment();
        OperatorStuff.fillUnaryOperators(oe);
        OperatorStuff.fillBinaryOperators(oe);
        InterpreterTME5_2 interpreter = new InterpreterTME5_2(gve, oe);
        run.setInterpreter(interpreter);
    }

    @Parameterized.Parameters(name = "{0}")
    public static Collection<File[]> data() throws Exception {
        return InterpreterRunner.getFileList(samplesDirName, pattern);
    }
}
