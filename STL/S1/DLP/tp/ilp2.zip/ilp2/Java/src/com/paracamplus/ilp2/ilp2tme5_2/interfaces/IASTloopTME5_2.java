package com.paracamplus.ilp2.ilp2tme5_2.interfaces;

import com.paracamplus.ilp1.annotation.OrNull;
import com.paracamplus.ilp2.interfaces.IASTloop;

public interface IASTloopTME5_2 extends IASTloop {


    @OrNull
    String getLabel();

}//confirme
