package com.paracamplus.ilp2.ilp2tme5_2.compiler.normalizber;

import com.paracamplus.ilp1.interfaces.IASTexpression;
import com.paracamplus.ilp2.compiler.normalizer.INormalizationFactory;

public interface INormalizationFactoryTME5_2 extends INormalizationFactory {
    IASTexpression newBreak (String label);

    IASTexpression newContinue (String label);

    IASTexpression newLoop (String label, IASTexpression condition, IASTexpression body);
}
