package com.paracamplus.ilp2.ilp2tme4.compiler;

import java.util.Set;

import com.paracamplus.ilp1.compiler.CompilationException;
import com.paracamplus.ilp1.compiler.interfaces.IASTClocalVariable;
import com.paracamplus.ilp2.compiler.FreeVariableCollector;
import com.paracamplus.ilp2.compiler.interfaces.IASTCprogram;
import com.paracamplus.ilp2.ilp2tme4.compiler.interfaces.IASTCvisitorTME4;
import com.paracamplus.ilp2.ilp2tme4.interfaces.IASTunlessTME4;



public class FreeVariableCollectorTME4 extends FreeVariableCollector implements IASTCvisitorTME4<Void, Set<IASTClocalVariable>, CompilationException> {

	public FreeVariableCollectorTME4(IASTCprogram program) {
		super(program);
	}

	@Override
	public Void visit(IASTunlessTME4 iast, Set<IASTClocalVariable> ret) throws CompilationException {
		// TODO Auto-generated method stub
        iast.getCondition().accept(this, ret);
        iast.getBody().accept(this, ret);
        return null;
	}

}
