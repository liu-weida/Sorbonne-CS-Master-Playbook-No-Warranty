package com.paracamplus.ilp2.ilp2tme5_2.interfaces;

import com.paracamplus.ilp1.interfaces.IASTvisitable;
import com.paracamplus.ilp2.interfaces.IASTvisitor;

public interface IASTvisitorTME5_2<Result, Data, Anomaly extends Throwable>
        extends com.paracamplus.ilp2.interfaces.IASTvisitor<Result, Data, Anomaly> {

    Result visit(IASTbreakTME5_2 iast, Data data) throws Anomaly;
    Result visit(IASTcontinueTME5_2 iast, Data data) throws Anomaly;
    Result visit(IASTloopTME5_2 iast, Data data) throws Anomaly;

}//confirme

